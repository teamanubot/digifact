# DigiFact

Aplikasi Flutter pendeteksi hoaks berbasis AI (Random Forest + penjelasan SHAP & LIME).
Backend: `hoax-detector-api` (FastAPI).

## Dokumentasi

- [`docs/ARSITEKTUR.md`](docs/ARSITEKTUR.md): keputusan arsitektur, diagram alur, pengujian, pengukuran sebelum/sesudah, perbandingan pendekatan, keterbatasan.
- [`../hda/README.md`](../hda/README.md): pipeline machine learning, temuan kebocoran data, hasil, dan keterbatasan.

## Arsitektur

Clean Architecture dengan **GetX** untuk state management, dependency injection, dan routing.

```
lib/
├── main.dart                     # Bootstrap: DI, orientasi, runApp
├── app/                          # Konfigurasi aplikasi
│   ├── bindings/                 # InitialBinding (DI global)
│   ├── routes/                   # Routes, AppPages, ResultArguments
│   ├── theme/                    # AppTheme, AppColors, AppRadius
│   └── transitions/
├── core/                         # Kode lintas-fitur, tanpa dependensi UI
│   ├── constants/                # ApiConstants, StorageKeys, AppConstants
│   ├── error/                    # Exception (data) & Failure (domain)
│   └── usecase/                  # Kontrak UseCase
├── domain/                       # Aturan bisnis — Dart murni
│   ├── entities/                 # DetectionResult, WordWeight
│   ├── repositories/             # Kontrak (abstract)
│   └── usecases/                 # Satu use case = satu aksi bisnis
├── data/                         # Implementasi sumber data
│   ├── datasources/{remote,local}
│   ├── models/                   # Entity + fromJson/toJson
│   └── repositories/             # Implementasi kontrak domain, map Exception -> Failure
└── presentation/
    ├── bindings/                 # DI per halaman (lazyPut controller)
    ├── controllers/              # GetxController: state reaktif + orkestrasi use case
    ├── pages/                    # Screen (UI + animasi lokal)
    └── widgets/                  # Widget bersama (AppSnackbar, ErrorDialog)
```

### Aturan dependensi

`presentation → domain ← data`. `domain` tidak mengimpor Flutter, `http`, maupun
`shared_preferences`. Controller hanya bergantung pada use case, bukan repository
atau data source.

### Alur data (contoh: deteksi berita)

`HomeScreen` → `HomeController.detect()` → `DetectHoax` → `DetectionRepository`
→ `DetectionRemoteDataSource` (HTTP). Kegagalan dipetakan `Exception → Failure`
di repository, lalu ditampilkan controller lewat `ErrorDialog`.

### Konvensi

- State bisnis (loading, riwayat, status simpan) ada di controller (`Rx`/`Obx`).
  `AnimationController` tetap di `State` widget karena murni urusan tampilan.
- Navigasi memakai named route (`Routes`); data antar halaman lewat `ResultArguments`.
- Dependensi baru didaftarkan di `InitialBinding` (global) atau `*Binding` halaman.

## Menjalankan

```bash
flutter pub get
flutter run
flutter analyze
flutter test
```

Base URL API diatur di `lib/core/constants/api_constants.dart`.

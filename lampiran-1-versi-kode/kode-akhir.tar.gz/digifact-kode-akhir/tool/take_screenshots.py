"""Ambil screenshot tiap layar aplikasi DigiFact yang berjalan sungguhan.

Alur: Xvfb (layar virtual) + openbox + binary Linux hasil `flutter build linux`
+ xdotool (klik/ketik) + scrot (tangkap layar). Aplikasi memanggil API produksi
sungguhan, jadi layar Hasil berisi prediksi model yang sebenarnya.

Prasyarat:
    export PATH=/root/flutter/bin:$PATH
    flutter build linux --debug
    apt: xvfb openbox xdotool scrot

Pemakaian (dari folder digifact):
    python3 tool/take_screenshots.py [folder_keluaran]
"""
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "docs", "screenshots")
BIN = os.path.join(ROOT, "build/linux/x64/debug/bundle/digifact")
DISPLAY = ":99"
W, H = 1080, 1920

# Teks uji: berita Fakta bergaya kantor berita dan klaim Hoaks bergaya pesan berantai.
TEXT_HOAKS = ("Segera klaim saldo DANA gratis Rp2 juta dari pemerintah untuk semua warga "
              "yang mendaftar hari ini melalui tautan berikut sebelum kuota habis")


def sh(cmd, **kw):
    return subprocess.run(cmd, shell=True, env={**os.environ, "DISPLAY": DISPLAY}, **kw)


def bg(cmd):
    return subprocess.Popen(cmd, shell=True, env={**os.environ, "DISPLAY": DISPLAY,
            "GDK_BACKEND": "x11", "LIBGL_ALWAYS_SOFTWARE": "1", "GBM_ALWAYS_SOFTWARE": "1"},
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def shot(name):
    path = os.path.join(OUT, name)
    sh(f"scrot -z '{path}'")
    print("  ->", path, os.path.getsize(path), "bytes")


def click(x, y, wait=1.5):
    sh(f"xdotool mousemove {x} {y} click 1")
    time.sleep(wait)


os.makedirs(OUT, exist_ok=True)
for f in os.listdir(OUT):
    if f.endswith(".png"):
        os.remove(os.path.join(OUT, f))
if not os.path.exists(BIN):
    sys.exit(f"Binary tidak ada: {BIN}. Jalankan `flutter build linux --debug` dulu.")

sh("killall -9 Xvfb openbox digifact 2>/dev/null; rm -f /tmp/.X99-lock")
xvfb = bg(f"Xvfb {DISPLAY} -screen 0 {W}x{H}x24")
time.sleep(2)
openbox = bg("openbox")
time.sleep(2)
# Onboarding dipaksa tampil: hapus data lokal aplikasi (SharedPreferences) agar alurnya bersih.
sh("rm -rf ~/.local/share/com.example.digifact ~/.local/share/digifact 2>/dev/null")
app = bg(f"'{BIN}' --tablet-10")

try:
    win = None
    for _ in range(60):
        r = sh("xdotool search --class digifact", capture_output=True, text=True)
        if r.stdout.strip():
            win = r.stdout.split()[0]
            break
        time.sleep(0.5)
    if not win:
        sys.exit("Jendela aplikasi tidak muncul")
    sh(f"xdotool windowsize {win} {W} {H}; xdotool windowmove {win} 0 0")
    time.sleep(1.2)

    print("1. Splash"); shot("1_splash.png")
    time.sleep(4.5)
    print("2. Onboarding 1"); shot("2_onboarding_1.png")
    click(540, 1850); print("3. Onboarding 2"); shot("3_onboarding_2.png")
    click(540, 1850); print("4. Onboarding 3"); shot("4_onboarding_3.png")
    click(540, 1850, wait=3.5)
    print("5. Beranda"); shot("5_beranda.png")

    click(540, 325, wait=0.8)
    sh(f'xdotool type --delay 15 "{TEXT_HOAKS}"')
    time.sleep(1.0)
    print("6. Beranda dengan input"); shot("6_beranda_input.png")
    click(540, 440, wait=9.0)
    print("7. Hasil (bagian atas)"); shot("7_hasil_atas.png")
    click(793, 1397, wait=1.2)  # tab LIME
    print("8. Hasil (XAI LIME)"); shot("8_hasil_lime.png")

    click(28, 28, wait=2.0)  # tombol kembali di app bar
    click(270, 550, wait=2.0)
    print("9. Panduan literasi"); shot("9_edukasi.png")
    click(28, 28, wait=2.0)  # tombol kembali di app bar
    click(810, 550, wait=2.0)
    print("10. Riwayat"); shot("10_riwayat.png")
finally:
    for p in (app, openbox, xvfb):
        p.terminate()
    sh("killall -9 Xvfb openbox digifact 2>/dev/null")
print("Selesai.")

"""Ukuran kode tiga pendekatan state management pada fitur riwayat yang sama.

Jalankan dari folder digifact:  python3 tool/compare_state_management.py
Menghitung baris non-kosong dan non-komentar, jumlah kelas, dan jumlah berkas.
"""
import re
from pathlib import Path

FILES = {
    "GetX": ["test/comparison/history_getx.dart"],
    "Cubit (bloc)": ["test/comparison/history_cubit.dart"],
    "ChangeNotifier": ["test/comparison/history_notifier.dart"],
}


def analyse(path):
    lines = Path(path).read_text().splitlines()
    code = [l for l in lines if l.strip() and not l.strip().startswith(("//", "///"))]
    body = [l for l in code if not l.startswith("import ")]
    classes = sum(1 for l in code if re.match(r"\s*class\s+\w+", l))
    return len(body), len(code) - len(body), classes


print(f"{'Pendekatan':16} {'baris logika':>13} {'import':>7} {'kelas':>6} {'berkas':>7}")
for name, files in FILES.items():
    body = imp = cls = 0
    for f in files:
        b, i, c = analyse(f)
        body += b; imp += i; cls += c
    print(f"{name:16} {body:13d} {imp:7d} {cls:6d} {len(files):7d}")

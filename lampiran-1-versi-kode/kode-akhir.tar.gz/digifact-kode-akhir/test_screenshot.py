import subprocess
import time
import os

def run_command(cmd, shell=True):
    print(f"Executing: {cmd}")
    return subprocess.Popen(cmd, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Bersihkan sisa proses
subprocess.run("killall -9 Xvfb openbox digifact 2>/dev/null || true", shell=True)
subprocess.run("rm -f /tmp/.X*-lock", shell=True)

# Path screenshot
os.makedirs("/root/mat/digifact/test_screenshots", exist_ok=True)

print("Starting Xvfb...")
xvfb_proc = run_command("Xvfb :99 -screen 0 1080x1920x24")
time.sleep(2)

os.environ["DISPLAY"] = ":99"
os.environ["LIBGL_ALWAYS_SOFTWARE"] = "1"
os.environ["GBM_ALWAYS_SOFTWARE"] = "1"

print("Starting Openbox...")
openbox_proc = run_command("openbox")
time.sleep(2)

print("Launching digifact...")
app_proc = run_command("/root/mat/digifact/build/linux/x64/debug/bundle/digifact --tablet-10")
time.sleep(8) # Beri waktu 8 detik agar engine memuat halaman

print("Taking test screenshot...")
subprocess.run("scrot -z /root/mat/digifact/test_screenshots/test.png", shell=True)

print("Cleaning up...")
app_proc.terminate()
openbox_proc.terminate()
xvfb_proc.terminate()
time.sleep(1)

print("Done. Let's analyze colors of the screenshot.")

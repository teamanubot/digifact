import 'package:flutter/material.dart';

import '../../app/theme/app_colors.dart';
import '../../domain/entities/verdict.dart';

/// Gaya visual (warna, ikon, teks) untuk setiap [Verdict].
///
/// Satu-satunya tempat pemetaan verdict ke tampilan, dipakai halaman hasil,
/// riwayat, dan beranda supaya konsisten dan mudah diuji.
class VerdictStyle {
  final Color color;
  final IconData icon;
  final String headerLabel;
  final String subtitle;
  final List<Color> gaugeGradient;

  const VerdictStyle._({
    required this.color,
    required this.icon,
    required this.headerLabel,
    required this.subtitle,
    required this.gaugeGradient,
  });

  static const _fakta = VerdictStyle._(
    color: AppColors.neonGreen,
    icon: Icons.verified_rounded,
    headerLabel: 'INFORMASI FAKTA',
    subtitle:
        'Sesuai dengan struktur jurnalisme valid dan sumber berita yang dapat diverifikasi.',
    gaugeGradient: [Color(0xFF00FF88), AppColors.neonGreen],
  );

  static const _hoaks = VerdictStyle._(
    color: AppColors.neonRed,
    icon: Icons.gpp_bad_rounded,
    headerLabel: 'INDIKASI HOAKS',
    subtitle:
        'Memiliki kemiripan tinggi dengan pola penyebaran informasi yang tidak valid.',
    gaugeGradient: [Color(0xFFFF6B6B), AppColors.neonRed],
  );

  static const _netral = VerdictStyle._(
    color: Color(0xFFFFAA00),
    icon: Icons.help_outline_rounded,
    headerLabel: 'PERLU VERIFIKASI',
    subtitle:
        'Tingkat keyakinan model rendah. Disarankan verifikasi manual dari sumber terpercaya.',
    gaugeGradient: [Color(0xFFFFD700), Color(0xFFFFAA00)],
  );

  static VerdictStyle of(Verdict verdict) {
    switch (verdict) {
      case Verdict.fakta:
        return _fakta;
      case Verdict.hoaks:
        return _hoaks;
      case Verdict.netral:
        return _netral;
    }
  }
}

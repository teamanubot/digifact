import 'package:flutter/material.dart';

/// Mengubah teks berformat `**tebal**` menjadi span Flutter.
///
/// Backend mengirim analisis dengan penanda markdown tebal. Tanpa ini, tanda
/// bintang tampil mentah di layar. Penanda tanpa pasangan dibiarkan apa adanya.
List<InlineSpan> boldSpans(String text, TextStyle base) {
  final parts = text.split('**');
  if (parts.length.isEven) return [TextSpan(text: text, style: base)]; // bintang ganjil
  return [
    for (var i = 0; i < parts.length; i++)
      if (parts[i].isNotEmpty)
        TextSpan(
          text: parts[i],
          style: i.isOdd ? base.copyWith(fontWeight: FontWeight.w700, color: Colors.white) : base,
        ),
  ];
}

/// Teks dengan dukungan `**tebal**`.
class BoldText extends StatelessWidget {
  final String text;
  final TextStyle style;

  const BoldText(this.text, {super.key, required this.style});

  @override
  Widget build(BuildContext context) =>
      Text.rich(TextSpan(children: boldSpans(text, style)));
}

import 'package:get/get.dart';

import '../controllers/home_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(
      () => HomeController(
        checkServerStatus: Get.find(),
        detectHoax: Get.find(),
        getHistory: Get.find(),
        saveResult: Get.find(),
        resetOnboarding: Get.find(),
      ),
    );
  }
}

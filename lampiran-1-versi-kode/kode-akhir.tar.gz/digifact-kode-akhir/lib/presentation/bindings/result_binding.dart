import 'package:get/get.dart';

import '../controllers/result_controller.dart';

class ResultBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(
      () => ResultController(saveResult: Get.find(), deleteResult: Get.find()),
    );
  }
}

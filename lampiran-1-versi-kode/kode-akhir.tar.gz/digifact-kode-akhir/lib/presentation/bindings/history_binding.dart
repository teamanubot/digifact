import 'package:get/get.dart';

import '../controllers/history_controller.dart';

class HistoryBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(
      () => HistoryController(
        getHistory: Get.find(),
        deleteResult: Get.find(),
        clearHistory: Get.find(),
      ),
    );
  }
}

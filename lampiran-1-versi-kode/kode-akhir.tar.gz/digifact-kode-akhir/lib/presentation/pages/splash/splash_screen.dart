import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/splash_controller.dart';
import 'widgets/orbit_particles.dart';
import 'widgets/orbit_rings.dart';
import 'widgets/splash_background.dart';
import 'widgets/splash_bottom_text.dart';
import 'widgets/splash_logo.dart';
import 'widgets/splash_version_badge.dart';

// =============================================================
// SPLASH SCREEN – Animasi intro premium DigiFact
// =============================================================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  // ── Controllers ──────────────────────────────────────────────
  late AnimationController _logoController;
  late AnimationController _ringController;
  late AnimationController _particleController;
  late AnimationController _textController;
  late AnimationController _taglineController;
  late AnimationController _exitController;

  // ── Animations ───────────────────────────────────────────────
  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  late Animation<double> _ringScale;
  late Animation<double> _ringOpacity;
  late Animation<double> _textFade;
  late Animation<Offset> _textSlide;
  late Animation<double> _taglineFade;
  late Animation<double> _exitFade;

  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _startSequence();

    // Failsafe: paksa navigasi setelah 5 detik jika animasi macet
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted && !_navigated) {
        _navigated = true;
        Get.find<SplashController>().navigateNext();
      }
    });
  }

  void _initAnimations() {
    // Logo scale + fade in (elasticOut agar terasa "pop")
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _logoScale = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.elasticOut),
    );
    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );

    // Ring expand dari tengah
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _ringScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _ringController, curve: Curves.easeOutCubic),
    );
    _ringOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _ringController,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
      ),
    );

    // Partikel orbit (looping sepanjang splash)
    _particleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    // Teks nama aplikasi slide up + fade
    _textController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _textFade = CurvedAnimation(
      parent: _textController,
      curve: Curves.easeOut,
    );
    _textSlide = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _textController, curve: Curves.easeOutCubic),
    );

    // Tagline fade in
    _taglineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _taglineFade = CurvedAnimation(
      parent: _taglineController,
      curve: Curves.easeOut,
    );

    // Exit fade out keseluruhan layar
    _exitController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _exitFade = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _exitController, curve: Curves.easeIn),
    );
  }

  Future<void> _startSequence() async {
    try {
      // Tahap 1: Ring + logo muncul bersamaan
      if (!mounted) return;
      await Future.wait([
        _ringController.forward(),
        _logoController.forward(),
      ]);

      // Tahap 2: Nama aplikasi slide up
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 80));
      if (!mounted) return;
      await _textController.forward();

      // Tahap 3: Tagline fade in
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;
      await _taglineController.forward();

      // Tahap 4: Tahan sebentar lalu fade out
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 1500));
      if (!mounted) return;
      await _exitController.forward();
    } catch (_) {
      // Jika animasi diputus karena dispose, abaikan
    }

    if (mounted && !_navigated) {
      _navigated = true;
      Get.find<SplashController>().navigateNext();
    }
  }


  @override
  void dispose() {
    _logoController.dispose();
    _ringController.dispose();
    _particleController.dispose();
    _textController.dispose();
    _taglineController.dispose();
    _exitController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(0xFF050D1A),
      body: FadeTransition(
        opacity: _exitFade,
        child: Stack(
          children: [
            // ── Layer 1: Background ──────────────────────────────
            SplashBackground(size: size, particle: _particleController),

            // ── Layer 2: Orbit rings ─────────────────────────────
            Center(
              child: OrbitRings(
                ring: _ringController,
                particle: _particleController,
                ringScale: _ringScale,
                ringOpacity: _ringOpacity,
              ),
            ),

            // ── Layer 3: Orbit particles ─────────────────────────
            Center(child: OrbitParticles(particle: _particleController)),

            // ── Layer 4: Logo center ─────────────────────────────
            Center(
              child: SplashLogo(
                logo: _logoController,
                logoScale: _logoScale,
                logoFade: _logoFade,
              ),
            ),

            // ── Layer 5: Bottom text block ───────────────────────
            SplashBottomText(
              size: size,
              textSlide: _textSlide,
              textFade: _textFade,
              taglineFade: _taglineFade,
            ),

            // ── Layer 6: Version + loading dots ─────────────────
            SplashVersionBadge(taglineFade: _taglineFade, particle: _particleController),
          ],
        ),
      ),
    );
  }
}

// =============================================================
// CUSTOM PAINTERS untuk Splash
// =============================================================

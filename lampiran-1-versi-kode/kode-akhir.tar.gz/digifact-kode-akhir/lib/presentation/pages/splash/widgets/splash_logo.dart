import 'package:flutter/material.dart';
import '../../../../app/theme/app_colors.dart';

/// Logo pusat dengan animasi muncul.
class SplashLogo extends StatelessWidget {
  final Animation<double> logo;
  final Animation<double> logoScale;
  final Animation<double> logoFade;

  const SplashLogo({super.key, required this.logo, required this.logoScale, required this.logoFade});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: logo,
      builder: (context, _) {
        return FadeTransition(
          opacity: logoFade,
          child: ScaleTransition(
            scale: logoScale,
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFF0D3580), Color(0xFF0A2050)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: AppColors.neonCyan.withValues(alpha: 0.35),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.neonCyan.withValues(alpha: 0.28),
                    blurRadius: 36,
                    spreadRadius: 6,
                  ),
                  BoxShadow(
                    color: AppColors.neonGreen.withValues(alpha: 0.12),
                    blurRadius: 52,
                    spreadRadius: 10,
                  ),
                ],
              ),
              child: Center(
                child: ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [AppColors.neonCyan, AppColors.neonGreen],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ).createShader(bounds),
                  child: const Icon(
                    Icons.fact_check_rounded,
                    size: 46,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

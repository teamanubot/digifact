import 'package:flutter/material.dart';
import 'splash_painters.dart';

/// Cincin orbit di sekeliling logo.
class OrbitRings extends StatelessWidget {
  final Animation<double> ring;
  final Animation<double> particle;
  final Animation<double> ringScale;
  final Animation<double> ringOpacity;

  const OrbitRings({super.key, required this.ring, required this.particle, required this.ringScale, required this.ringOpacity});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([ring, particle]),
      builder: (context, _) {
        return ScaleTransition(
          scale: ringScale,
          child: FadeTransition(
            opacity: ringOpacity,
            child: SizedBox(
              width: 280,
              height: 280,
              child: CustomPaint(
                painter: SplashRingPainter(
                  progress: particle.value,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../../app/theme/app_colors.dart';

/// Latar gelap dengan blob cahaya bergerak.
class SplashBackground extends StatelessWidget {
  final Size size;
  final Animation<double> particle;

  const SplashBackground({super.key, required this.size, required this.particle});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: particle,
      builder: (context, _) {
        final t = particle.value * 2 * math.pi;
        return Stack(
          children: [
            // Radial gradient biru gelap ke hitam
            Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0, -0.2),
                  radius: 1.2,
                  colors: [Color(0xFF0A2550), Color(0xFF050D1A)],
                ),
              ),
            ),
            // Orb hijau
            Positioned(
              top: size.height * 0.08 + 20 * math.sin(t * 0.55),
              right: size.width * 0.08 + 10 * math.cos(t * 0.4),
              child: _glowBlob(180, AppColors.neonGreen, 0.06),
            ),
            // Orb cyan
            Positioned(
              bottom: size.height * 0.1 + 15 * math.sin(t * 0.5),
              left: size.width * 0.04 + 10 * math.cos(t * 0.65),
              child: _glowBlob(200, AppColors.neonCyan, 0.05),
            ),
          ],
        );
      },
    );
  }

  Widget _glowBlob(double s, Color color, double alpha) {
    return Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withValues(alpha: alpha), Colors.transparent],
        ),
      ),
    );
  }

}

import 'package:flutter/material.dart';
import 'splash_painters.dart';

/// Partikel kecil yang mengorbit logo.
class OrbitParticles extends StatelessWidget {
  final Animation<double> particle;

  const OrbitParticles({super.key, required this.particle});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: particle,
      builder: (context, _) {
        return SizedBox(
          width: 280,
          height: 280,
          child: CustomPaint(
            painter: SplashParticlePainter(
              progress: particle.value,
              count: splashParticleCount,
            ),
          ),
        );
      },
    );
  }
}

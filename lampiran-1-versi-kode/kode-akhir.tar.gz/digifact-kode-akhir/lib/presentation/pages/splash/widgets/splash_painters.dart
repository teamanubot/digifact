import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../../app/theme/app_colors.dart';

/// Jumlah partikel yang mengorbit logo.
const int splashParticleCount = 8;

class SplashRingPainter extends CustomPainter {
  final double progress;
  SplashRingPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);

    void drawRing(double radius, Color color, double alpha, double strokeW) {
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..color = color.withValues(alpha: alpha)
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeW,
      );
    }

    // Tiga ring statis
    drawRing(size.width / 2 - 4, AppColors.neonCyan, 0.12, 1.0);
    drawRing(size.width / 2 - 28, AppColors.neonCyan, 0.08, 0.8);
    drawRing(size.width / 2 - 54, AppColors.neonGreen, 0.07, 0.6);

    // Arc aktif berputar – outer (cyan)
    final outerPaint = Paint()
      ..color = AppColors.neonCyan.withValues(alpha: 0.7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: size.width / 2 - 4),
      progress * 2 * math.pi,
      math.pi * 0.6,
      false,
      outerPaint,
    );

    // Arc aktif berputar – inner (green, berlawanan arah)
    final innerPaint = Paint()
      ..color = AppColors.neonGreen.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: size.width / 2 - 54),
      -progress * 1.5 * 2 * math.pi,
      math.pi * 0.5,
      false,
      innerPaint,
    );
  }

  @override
  bool shouldRepaint(SplashRingPainter old) => old.progress != progress;
}

class SplashParticlePainter extends CustomPainter {
  final double progress;
  final int count;
  SplashParticlePainter({required this.progress, required this.count});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final outerR = size.width / 2 - 4;
    final innerR = size.width / 2 - 54;

    for (int i = 0; i < count; i++) {
      final frac = i / count;
      final brightness =
          (math.sin((progress + frac * 2) * 2 * math.pi) * 0.4 + 0.6)
              .clamp(0.2, 1.0);

      // Outer dot (cyan)
      final outerAngle = (progress + frac) * 2 * math.pi;
      final ox = center.dx + outerR * math.cos(outerAngle);
      final oy = center.dy + outerR * math.sin(outerAngle);
      canvas.drawCircle(
        Offset(ox, oy),
        5,
        Paint()
          ..color = AppColors.neonCyan.withValues(alpha: 0.18 * brightness)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
        Offset(ox, oy),
        2.5,
        Paint()..color = AppColors.neonCyan.withValues(alpha: brightness),
      );

      // Inner dot (green, separuh partikel, arah terbalik)
      if (i % 2 == 0) {
        final innerAngle = (-progress * 1.4 + frac * 1.5) * 2 * math.pi;
        final ix = center.dx + innerR * math.cos(innerAngle);
        final iy = center.dy + innerR * math.sin(innerAngle);
        canvas.drawCircle(
          Offset(ix, iy),
          3,
          Paint()
            ..color = AppColors.neonGreen.withValues(alpha: 0.15 * brightness)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
        );
        canvas.drawCircle(
          Offset(ix, iy),
          1.8,
          Paint()
            ..color = AppColors.neonGreen.withValues(alpha: brightness * 0.75),
        );
      }
    }
  }

  @override
  bool shouldRepaint(SplashParticlePainter old) => old.progress != progress;
}

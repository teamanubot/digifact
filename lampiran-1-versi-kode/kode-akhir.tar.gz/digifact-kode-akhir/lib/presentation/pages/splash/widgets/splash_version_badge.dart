import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';

/// Lencana versi dan titik loading.
class SplashVersionBadge extends StatelessWidget {
  final Animation<double> taglineFade;
  final Animation<double> particle;

  const SplashVersionBadge({super.key, required this.taglineFade, required this.particle});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 36,
      left: 0,
      right: 0,
      child: FadeTransition(
        opacity: taglineFade,
        child: Column(
          children: [
            _buildLoadingDots(),
            const SizedBox(height: 14),
            Text(
              'v1.2.0 · Random Forest + SHAP/LIME',
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(
                fontSize: 10.5,
                color: AppColors.textMuted,
                letterSpacing: 0.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingDots() {
    return AnimatedBuilder(
      animation: particle,
      builder: (context, _) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(3, (i) {
            final phase = (particle.value + i * 0.25) % 1.0;
            final opacity =
                (math.sin(phase * 2 * math.pi) * 0.45 + 0.55).clamp(0.15, 1.0);
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 3.5),
              width: 5,
              height: 5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.neonCyan.withValues(alpha: opacity),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.neonCyan.withValues(alpha: opacity * 0.4),
                    blurRadius: 6,
                  ),
                ],
              ),
            );
          }),
        );
      },
    );
  }

}

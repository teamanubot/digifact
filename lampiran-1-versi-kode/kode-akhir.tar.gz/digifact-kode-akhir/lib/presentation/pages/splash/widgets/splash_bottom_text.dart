import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';

/// Nama aplikasi dan tagline.
class SplashBottomText extends StatelessWidget {
  final Size size;
  final Animation<Offset> textSlide;
  final Animation<double> textFade;
  final Animation<double> taglineFade;

  const SplashBottomText({super.key, required this.size, required this.textSlide, required this.textFade, required this.taglineFade});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: size.height * 0.24,
      left: 0,
      right: 0,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Nama "DigiFact"
          SlideTransition(
            position: textSlide,
            child: FadeTransition(
              opacity: textFade,
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'Digi',
                      style: GoogleFonts.dmSans(
                        fontSize: 42,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        letterSpacing: -1.5,
                      ),
                    ),
                    TextSpan(
                      text: 'Fact',
                      style: GoogleFonts.dmSans(
                        fontSize: 42,
                        fontWeight: FontWeight.w800,
                        color: AppColors.neonCyan,
                        letterSpacing: -1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Tagline
          FadeTransition(
            opacity: taglineFade,
            child: Text(
              'Deteksi Kebenaran Informasi\nberbasis Kecerdasan Buatan',
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(
                fontSize: 14,
                color: AppColors.textSecondary,
                height: 1.6,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_colors.dart';
import '../../controllers/home_controller.dart';
import 'widgets/ai_badge.dart';
import 'widgets/animated_background.dart';
import 'widgets/home_header.dart';
import 'widgets/input_card.dart';
import 'widgets/nav_menu_row.dart';
import 'widgets/recent_history_header.dart';
import 'widgets/recent_history_list.dart';

// =============================================================
// HOME SCREEN
// =============================================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin {
  final HomeController _controller = Get.find<HomeController>();

  // Controllers animasi
  late AnimationController _pulseController;
  late AnimationController _bgOrbitController;

  @override
  void initState() {
    super.initState();
    // Denyut nadi indikator server
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    // Shimmer background orbit
    _bgOrbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _bgOrbitController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: Stack(
        children: [
          // ── Animated background orbs ──────────────────────────
          AnimatedBackground(orbit: _bgOrbitController),

          // ── Main content ──────────────────────────────────────
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        HomeHeader(controller: _controller, pulse: _pulseController),
                        const SizedBox(height: 28),
                        AiBadge(pulse: _pulseController),
                        const SizedBox(height: 24),
                        InputCard(controller: _controller),
                        const SizedBox(height: 20),
                        NavMenuRow(controller: _controller),
                        const SizedBox(height: 32),
                        RecentHistoryHeader(controller: _controller),
                        const SizedBox(height: 14),
                        RecentHistoryList(controller: _controller),
                        const SizedBox(height: 32),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

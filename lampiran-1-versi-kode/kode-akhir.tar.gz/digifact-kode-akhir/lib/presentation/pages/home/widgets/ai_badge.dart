import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';

/// Lencana teknologi (Random Forest, SHAP, LIME).
class AiBadge extends StatelessWidget {
  final Animation<double> pulse;

  const AiBadge({super.key, required this.pulse});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Row(
        children: [
          // Animasi grid dot
          _buildAiDotGrid(),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Machine Learning · Random Forest',
                  style: GoogleFonts.dmSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.neonCyan,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Didukung SHAP & LIME untuk Explainable AI yang transparan.',
                  style: GoogleFonts.dmSans(
                    fontSize: 11.5,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAiDotGrid() {
    return AnimatedBuilder(
      animation: pulse,
      builder: (_, _) {
        return SizedBox(
          width: 36,
          height: 36,
          child: GridView.count(
            crossAxisCount: 3,
            mainAxisSpacing: 3,
            crossAxisSpacing: 3,
            physics: const NeverScrollableScrollPhysics(),
            children: List.generate(9, (i) {
              final delay = (i * 0.11) % 1.0;
              final v = (pulse.value + delay) % 1.0;
              return Container(
                decoration: BoxDecoration(
                  color: AppColors.neonCyan.withValues(
                    alpha: 0.15 + 0.6 * (math.sin(v * math.pi)).clamp(0.0, 1.0),
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            }),
          ),
        );
      },
    );
  }

}

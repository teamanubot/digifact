import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../controllers/home_controller.dart';

/// Kartu input teks/URL beserta tombol analisis.
///
/// Memiliki animasi sendiri (skala tombol dan shimmer loading) sehingga
/// halaman beranda tidak perlu mengelolanya.
class InputCard extends StatefulWidget {
  final HomeController controller;

  const InputCard({super.key, required this.controller});

  @override
  State<InputCard> createState() => _InputCardState();
}

class _InputCardState extends State<InputCard> with TickerProviderStateMixin {
  late final AnimationController _shimmerController;
  late final AnimationController _buttonScaleController;
  late final Animation<double> _buttonScaleAnim;
  bool _isInputFocused = false;

  @override
  void initState() {
    super.initState();
    // Shimmer untuk loading state
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    // Scale animasi tombol
    _buttonScaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _buttonScaleAnim = Tween<double>(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _buttonScaleController, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    _buttonScaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.xl),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: AppColors.navyCard.withValues(alpha: 0.85),
            borderRadius: BorderRadius.circular(AppRadius.xl),
            border: Border.all(
              color: _isInputFocused
                  ? AppColors.neonCyan.withValues(alpha: 0.35)
                  : AppColors.borderSubtle,
              width: 1.5,
            ),
            boxShadow: [
              if (_isInputFocused)
                BoxShadow(
                  color: AppColors.neonCyan.withValues(alpha: 0.08),
                  blurRadius: 24,
                  spreadRadius: 2,
                ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Label + clear button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.document_scanner_outlined,
                        color: AppColors.neonCyan.withValues(alpha: 0.8),
                        size: 16,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Verifikasi Berita / URL',
                        style: GoogleFonts.dmSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  Obx(() => widget.controller.hasInput.value ?
                    GestureDetector(
                      onTap: () {
                        widget.controller.clearInput();
                        HapticFeedback.selectionClick();
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.neonRed.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.neonRed.withValues(alpha: 0.2)),
                        ),
                        child: Text(
                          'Bersihkan',
                          style: GoogleFonts.dmSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: AppColors.neonRed,
                          ),
                        ),
                      ),
                    )
                      : const SizedBox.shrink()),
                ],
              ),
              const SizedBox(height: 14),

              // Text field
              Focus(
                onFocusChange: (focused) => setState(() => _isInputFocused = focused),
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.navyDeep.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    border: Border.all(
                      color: _isInputFocused
                          ? AppColors.neonCyan.withValues(alpha: 0.2)
                          : AppColors.borderSubtle.withValues(alpha: 0.5),
                    ),
                  ),
                  child: TextField(
                    controller: widget.controller.textController,
                    maxLines: 7,
                    minLines: 5,
                    style: GoogleFonts.dmSans(
                      fontSize: 14,
                      color: Colors.white,
                      height: 1.6,
                    ),
                    decoration: InputDecoration(
                      hintText:
                          'Tuliskan artikel atau tempel link URL berita\n(contoh: Kompas, Antara, Tempo) di sini...',
                      hintStyle: GoogleFonts.dmSans(
                        fontSize: 13.5,
                        color: AppColors.textMuted,
                        height: 1.6,
                      ),
                      contentPadding: const EdgeInsets.all(18),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),

              // Tombol Analisis dengan animasi press
              GestureDetector(
                onTapDown: (_) => _buttonScaleController.forward(),
                onTapUp: (_) {
                  _buttonScaleController.reverse();
                  widget.controller.detect();
                },
                onTapCancel: () => _buttonScaleController.reverse(),
                child: ScaleTransition(
                  scale: _buttonScaleAnim,
                  child: _buildAnalyzeButton(),
                ),
              ),
              const SizedBox(height: 12),

              // Pemberitahuan privasi: teks dikirim ke server, riwayat hanya lokal.
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.lock_outline_rounded,
                    size: 13,
                    color: AppColors.textMuted,
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Teks atau tautan yang diperiksa dikirim ke server untuk dianalisis. Riwayat hanya disimpan di perangkat ini dan dapat dihapus kapan saja.',
                      style: GoogleFonts.dmSans(
                        fontSize: 11,
                        color: AppColors.textMuted,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAnalyzeButton() {
    return Obx(() => _buildAnalyzeButtonBody(widget.controller.isLoading.value));
  }

  Widget _buildAnalyzeButtonBody(bool isLoading) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: double.infinity,
      height: 54,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.md),
        gradient: isLoading
            ? LinearGradient(
                colors: [
                  AppColors.neonCyan.withValues(alpha: 0.3),
                  AppColors.neonBlue.withValues(alpha: 0.3),
                ],
              )
            : const LinearGradient(
                colors: [Color(0xFF0077FF), Color(0xFF00D4FF)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
        boxShadow: isLoading
            ? []
            : [
                BoxShadow(
                  color: AppColors.neonCyan.withValues(alpha: 0.30),
                  blurRadius: 18,
                  spreadRadius: -2,
                  offset: const Offset(0, 6),
                ),
              ],
      ),
      child: isLoading
          ? Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SpinKitPulse(
                  color: AppColors.neonCyan,
                  size: 22,
                  controller: _shimmerController,
                ),
                const SizedBox(width: 14),
                Text(
                  'MENGANALISIS DATA...',
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.0,
                    color: AppColors.neonCyan,
                  ),
                ),
              ],
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.bolt_rounded, color: Colors.white, size: 20),
                const SizedBox(width: 8),
                Text(
                  'ANALISIS BERITA SEKARANG',
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
    );
  }
}

import 'package:flutter/material.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../controllers/home_controller.dart';
import 'glass_menu_card.dart';

/// Dua menu pintas: panduan literasi dan riwayat.
class NavMenuRow extends StatelessWidget {
  final HomeController controller;

  const NavMenuRow({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: GlassMenuCard(
            onTap: controller.openEducation,
            icon: Icons.menu_book_rounded,
            accentColor: AppColors.neonCyan,
            title: 'Panduan Cek',
            subtitle: 'Tips Literasi Digital',
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: GlassMenuCard(
            onTap: controller.openHistory,
            icon: Icons.manage_search_rounded,
            accentColor: AppColors.neonGreen,
            title: 'Riwayat Cek',
            subtitle: 'Lihat aktivitas lalu',
          ),
        ),
      ],
    );
  }
}

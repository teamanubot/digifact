import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../controllers/home_controller.dart';

/// Judul aplikasi, status server, dan tombol reset onboarding.
class HomeHeader extends StatelessWidget {
  final HomeController controller;
  final Animation<double> pulse;

  const HomeHeader({super.key, required this.controller, required this.pulse});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'Digi',
                      style: GoogleFonts.dmSans(
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        letterSpacing: -1.2,
                      ),
                    ),
                    TextSpan(
                      text: 'Fact',
                      style: GoogleFonts.dmSans(
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        color: AppColors.neonCyan,
                        letterSpacing: -1.2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'Deteksi Kebenaran Informasi · AI-Powered',
                style: GoogleFonts.dmSans(
                  fontSize: 11.5,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w400,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),

        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Server status badge
            GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                controller.checkServer();
              },
              child: Obx(() {
                final isOn = controller.isServerActive.value;
                return AnimatedBuilder(
                animation: pulse,
                builder: (_, _) {
                  final dotColor = isOn ? AppColors.neonGreen : AppColors.neonRed;
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: dotColor.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: dotColor.withValues(alpha: 0.25),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: dotColor,
                            boxShadow: [
                              BoxShadow(
                                color: dotColor.withValues(alpha: pulse.value * 0.9),
                                blurRadius: 8 * pulse.value,
                                spreadRadius: 2 * pulse.value,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 7),
                        Text(
                          isOn ? 'Server Online' : 'Offline',
                          style: GoogleFonts.dmSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: dotColor,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
              }),
            ),
            const SizedBox(width: 8),
            // Tombol Reset Onboarding untuk debugging / pengujian
            GestureDetector(
              onTap: controller.resetOnboarding,
              child: Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.04),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.1),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.restart_alt_rounded,
                  color: Colors.white70,
                  size: 16,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../controllers/home_controller.dart';
import 'empty_history.dart';
import 'recent_history_card.dart';

/// Daftar riwayat terbaru (reaktif terhadap controller).
class RecentHistoryList extends StatelessWidget {
  final HomeController controller;

  const RecentHistoryList({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final recent = controller.recentHistory;
      if (recent.isEmpty) {
        return const EmptyHistory();
      }
      return Column(
        children: recent.asMap().entries.map((entry) {
          return RecentHistoryCard(item: entry.value, onTap: () => controller.openResult(entry.value));
        }).toList(),
      );
    });
  }
}

import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../../app/theme/app_colors.dart';

/// Orb cahaya latar yang bergerak perlahan.
class AnimatedBackground extends StatelessWidget {
  final Animation<double> orbit;

  const AnimatedBackground({super.key, required this.orbit});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: orbit,
      builder: (context, _) {
        final t = orbit.value * 2 * math.pi;
        return Stack(
          children: [
            // Orb kiri atas – cyan
            Positioned(
              top: -60 + 20 * math.sin(t * 0.7),
              left: -80 + 10 * math.cos(t * 0.5),
              child: _glowOrb(260, AppColors.neonCyan, 0.08),
            ),
            // Orb kanan bawah – blue
            Positioned(
              bottom: -80 + 15 * math.sin(t * 0.4),
              right: -60 + 10 * math.cos(t * 0.6),
              child: _glowOrb(240, AppColors.neonBlue, 0.10),
            ),
            // Orb tengah mikro – green
            Positioned(
              top: 300 + 30 * math.sin(t),
              right: 60 + 20 * math.cos(t * 0.8),
              child: _glowOrb(120, AppColors.neonGreen, 0.05),
            ),
          ],
        );
      },
    );
  }

  Widget _glowOrb(double size, Color color, double alpha) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            color.withValues(alpha: alpha),
            color.withValues(alpha: 0),
          ],
        ),
      ),
    );
  }

}

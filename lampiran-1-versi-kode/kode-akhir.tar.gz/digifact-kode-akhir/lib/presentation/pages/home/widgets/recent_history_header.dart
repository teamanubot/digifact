import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../controllers/home_controller.dart';

/// Judul "Pengecekan Terbaru" dan tautan lihat semua.
class RecentHistoryHeader extends StatelessWidget {
  final HomeController controller;

  const RecentHistoryHeader({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Obx(() => Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Pengecekan Terbaru',
          style: GoogleFonts.dmSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        if (controller.recentHistory.isNotEmpty)
          GestureDetector(
            onTap: controller.openHistory,
            child: Row(
              children: [
                Text(
                  'Lihat Semua',
                  style: GoogleFonts.dmSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.neonCyan,
                  ),
                ),
                const SizedBox(width: 3),
                const Icon(Icons.arrow_forward_ios_rounded, size: 10, color: AppColors.neonCyan),
              ],
            ),
          ),
      ],
    ));
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';

/// Baris statistik singkat.
class StatsRow extends StatelessWidget {


  const StatsRow({super.key});

  @override
  Widget build(BuildContext context) {
    final stats = [
      {'val': '60%', 'label': 'Konten di media\nsosial adalah hoaks', 'color': AppColors.neonRed},
      {'val': '6×', 'label': 'Hoaks menyebar lebih\ncepat dari fakta', 'color': const Color(0xFFFFAA00)},
      {'val': '1 min', 'label': 'Waktu verifikasi\nyang Anda butuhkan', 'color': AppColors.neonGreen},
    ];

    return Row(
      children: stats.map((s) {
        final color = s['color'] as Color;
        return Expanded(
          child: Container(
            margin: EdgeInsets.only(
              left: stats.indexOf(s) == 0 ? 0 : 7,
              right: stats.indexOf(s) == stats.length - 1 ? 0 : 7,
            ),
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: color.withValues(alpha: 0.15)),
            ),
            child: Column(
              children: [
                Text(
                  s['val'] as String,
                  style: GoogleFonts.dmSans(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  s['label'] as String,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.dmSans(
                    fontSize: 10,
                    color: AppColors.textSecondary,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

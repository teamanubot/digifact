import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';

/// Kutipan penutup.
class QuoteBlock extends StatelessWidget {


  const QuoteBlock({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        children: [
          Icon(
            Icons.format_quote_rounded,
            color: AppColors.neonCyan.withValues(alpha: 0.4),
            size: 32,
          ),
          const SizedBox(height: 12),
          Text(
            '"Kebenaran tidak akan pernah merugikan tujuan yang adil."',
            textAlign: TextAlign.center,
            style: GoogleFonts.dmSans(
              fontSize: 14.5,
              fontStyle: FontStyle.italic,
              color: Colors.white,
              height: 1.6,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            '— Mahatma Gandhi',
            style: GoogleFonts.dmSans(
              fontSize: 12,
              color: AppColors.neonCyan,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

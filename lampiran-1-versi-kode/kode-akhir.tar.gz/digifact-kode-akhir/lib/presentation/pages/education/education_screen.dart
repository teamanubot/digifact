import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../app/theme/app_colors.dart';
import '../../../app/theme/app_radius.dart';
import 'data/literacy_tips.dart';
import 'widgets/hero_banner.dart';
import 'widgets/quote_block.dart';
import 'widgets/stats_row.dart';
import 'widgets/step_card.dart';

// =============================================================
// EDUCATION SCREEN – Literasi Digital
// =============================================================
class EducationScreen extends StatelessWidget {
  const EducationScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navyDeep,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(AppRadius.sm),
              border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
          ),
          onPressed: Get.back,
        ),
        title: Text(
          'Literasi Digital',
          style: GoogleFonts.dmSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: AppColors.borderSubtle.withValues(alpha: 0.5),
          ),
        ),
      ),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                20,
                22,
                20,
                22 + MediaQuery.viewPaddingOf(context).bottom,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Hero Banner ──────────────────────────────
                  const HeroBanner(),
                  const SizedBox(height: 28),

                  // ── Stats Row ────────────────────────────────
                  const StatsRow(),
                  const SizedBox(height: 28),

                  // ── Steps header ─────────────────────────────
                  Text(
                    'Panduan 5 Langkah Cek Fakta',
                    style: GoogleFonts.dmSans(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Ikuti langkah-langkah ini sebelum menyebarkan informasi.',
                    style: GoogleFonts.dmSans(
                      fontSize: 12.5,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 18),

                  // ── Step cards ───────────────────────────────
                  ...literacyTips.asMap().entries.map(
                    (entry) => StepCard(
                      tip: entry.value,
                      isLast: entry.key == literacyTips.length - 1,
                    ),
                  ),

                  const SizedBox(height: 24),

                  // ── Quote block ──────────────────────────────
                  const QuoteBlock(),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../../../app/theme/app_colors.dart';

/// Satu langkah panduan literasi digital.
class LiteracyTip {
  final String step;
  final String title;
  final String desc;
  final IconData icon;
  final Color color;

  const LiteracyTip({
    required this.step,
    required this.title,
    required this.desc,
    required this.icon,
    required this.color,
  });
}

/// Panduan 5 langkah cek fakta.
const List<LiteracyTip> literacyTips = [
  LiteracyTip(
    step: '01',
    title: 'Cermati Alamat URL Situs',
    desc:
        'Informasi dari situs resmi media massa nasional atau lembaga kredibel umumnya terpercaya. Waspadai domain tidak lazim (.blogspot, .wordpress, atau nama aneh).',
    icon: Icons.language_rounded,
    color: AppColors.neonCyan,
  ),
  LiteracyTip(
    step: '02',
    title: 'Periksa Beberapa Sumber',
    desc:
        'Jika berita benar, media arus utama lain juga memberitakannya. Bandingkan di situs tepercaya atau cek di Mafindo (turnbackhoax.id) dan cekfakta.com.',
    icon: Icons.compare_arrows_rounded,
    color: Color(0xFF818CF8),
  ),
  LiteracyTip(
    step: '03',
    title: 'Waspadai Judul Provokatif',
    desc:
        'Hoaks sering menggunakan judul bombastis dan sensasional untuk memicu emosi. Kalimatnya cenderung subjektif, menuding pihak tertentu, dan tidak netral.',
    icon: Icons.warning_amber_rounded,
    color: Color(0xFFFFAA00),
  ),
  LiteracyTip(
    step: '04',
    title: 'Periksa Keaslian Foto & Video',
    desc:
        'Hoaks sering menggunakan media lama yang dipotong atau dimanipulasi. Gunakan Google Reverse Image Search untuk memeriksa asal-usul foto.',
    icon: Icons.image_search_rounded,
    color: AppColors.neonGreen,
  ),
  LiteracyTip(
    step: '05',
    title: 'Perhatikan Tanggal & Konteks',
    desc:
        'Banyak hoaks adalah berita lama yang didaur ulang. Kejadian nyata di masa lalu disebarkan kembali dengan konteks berbeda seolah terjadi hari ini.',
    icon: Icons.calendar_today_rounded,
    color: Color(0xFF94A3B8),
  ),
];

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_colors.dart';
import '../../controllers/history_controller.dart';
import 'widgets/clear_history_dialog.dart';
import 'widgets/empty_history_state.dart';
import 'widgets/history_app_bar.dart';
import 'widgets/history_list.dart';

// =============================================================
// HISTORY SCREEN
// =============================================================
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen>
    with SingleTickerProviderStateMixin {
  final HistoryController _controller = Get.find<HistoryController>();
  late AnimationController _entryController;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  void _showClearDialog() {
    showDialog(
      context: context,
      builder: (_) => ClearHistoryDialog(onConfirm: _controller.clearAll),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Scaffold(
        backgroundColor: AppColors.navy,
        appBar: HistoryAppBar(
          count: _controller.history.length,
          onClear: _showClearDialog,
        ),
        body: _controller.history.isEmpty
            ? EmptyHistoryState(fade: _entryController)
            : HistoryList(
                items: _controller.history,
                onDelete: _controller.deleteItem,
                onOpen: _controller.openResult,
              ),
      ),
    );
  }
}

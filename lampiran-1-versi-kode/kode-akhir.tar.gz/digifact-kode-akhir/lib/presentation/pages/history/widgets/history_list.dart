import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../../domain/entities/detection_result.dart';
import '../../../widgets/verdict_style.dart';

/// Daftar riwayat; geser ke kiri untuk menghapus.
class HistoryList extends StatelessWidget {
  final List<DetectionResult> items;
  final void Function(String id) onDelete;
  final void Function(DetectionResult item) onOpen;

  const HistoryList({super.key, required this.items, required this.onDelete, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        16 + MediaQuery.viewPaddingOf(context).bottom,
      ),
      itemCount: items.length,
      itemBuilder: (_, index) {
        final item = items[index];
        final statusColor = VerdictStyle.of(item.verdict).color;

        final textSnippet = item.teksAsli.length > 90
            ? '${item.teksAsli.substring(0, 90).replaceAll('\n', ' ')}...'
            : item.teksAsli.replaceAll('\n', ' ');

        return Dismissible(
          key: Key(item.id),
          direction: DismissDirection.endToStart,
          onDismissed: (_) => onDelete(item.id),
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              color: AppColors.neonRed.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(AppRadius.lg),
              border: Border.all(color: AppColors.neonRed.withValues(alpha: 0.25)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.delete_outline_rounded, color: AppColors.neonRed, size: 24),
                const SizedBox(height: 4),
                Text(
                  'Hapus',
                  style: GoogleFonts.dmSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: AppColors.neonRed,
                  ),
                ),
              ],
            ),
          ),
          child: Container(
            margin: const EdgeInsets.only(bottom: 14),
            decoration: BoxDecoration(
              color: AppColors.navyCard,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              border: Border.all(color: AppColors.borderSubtle),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.lg),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => onOpen(item),
                  splashColor: statusColor.withValues(alpha: 0.05),
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Baris atas: tanggal + badge
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.access_time_rounded, size: 12, color: AppColors.textSecondary),
                                const SizedBox(width: 5),
                                Text(
                                  DateFormat('dd MMM yyyy · HH:mm').format(item.tanggalDeteksi),
                                  style: GoogleFonts.dmSans(
                                    fontSize: 11,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: statusColor.withValues(alpha: 0.10),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: statusColor.withValues(alpha: 0.25)),
                              ),
                              child: Text(
                                item.prediksiAkhir,
                                style: GoogleFonts.dmSans(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700,
                                  color: statusColor,
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        // Cuplikan teks
                        Text(
                          textSnippet,
                          style: GoogleFonts.dmSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                            height: 1.45,
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Progress bar duo
                        Row(
                          children: [
                            Expanded(
                              child: _buildMiniBar(
                                'Fakta',
                                item.probabilitasFakta,
                                AppColors.neonGreen,
                              ),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: _buildMiniBar(
                                'Hoaks',
                                item.probabilitasHoaks,
                                AppColors.neonRed,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildMiniBar(String label, double value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: GoogleFonts.dmSans(fontSize: 10.5, color: AppColors.textSecondary)),
            Text(
              '${(value * 100).toStringAsFixed(1)}%',
              style: GoogleFonts.dmSans(fontSize: 11, fontWeight: FontWeight.w700, color: color),
            ),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: value,
            backgroundColor: AppColors.navyElevated,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 5,
          ),
        ),
      ],
    );
  }
}

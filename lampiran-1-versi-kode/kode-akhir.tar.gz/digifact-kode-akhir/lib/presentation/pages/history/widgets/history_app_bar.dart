import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';

/// AppBar riwayat dengan jumlah item dan tombol hapus semua.
class HistoryAppBar extends StatelessWidget implements PreferredSizeWidget {
  final int count;
  final VoidCallback onClear;

  const HistoryAppBar({super.key, required this.count, required this.onClear});

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 1);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.navyDeep,
      elevation: 0,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(AppRadius.sm),
            border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
          ),
          child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
        ),
        onPressed: Get.back,
      ),
      title: Column(
        children: [
          Text(
            'Riwayat Pengecekan',
            style: GoogleFonts.dmSans(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          if (count > 0)
            Text(
              '$count pencarian tersimpan',
              style: GoogleFonts.dmSans(
                fontSize: 11,
                color: AppColors.textSecondary,
              ),
            ),
        ],
      ),
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          color: AppColors.borderSubtle.withValues(alpha: 0.5),
        ),
      ),
      actions: [
        if (count > 0)
          IconButton(
            icon: const Icon(Icons.delete_sweep_rounded, color: AppColors.neonRed, size: 22),
            onPressed: onClear,
            tooltip: 'Hapus semua',
          ),
        const SizedBox(width: 4),
      ],
    );
  }
}

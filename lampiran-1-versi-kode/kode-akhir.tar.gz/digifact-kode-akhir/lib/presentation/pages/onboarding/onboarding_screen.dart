import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_colors.dart';
import '../../controllers/onboarding_controller.dart';
import 'data/onboarding_slides.dart';
import 'widgets/onboarding_background.dart';
import 'widgets/onboarding_bottom_nav.dart';
import 'widgets/onboarding_top_bar.dart';
import 'widgets/slide_page.dart';

// =============================================================
// ONBOARDING SCREEN
// =============================================================
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  // Animasi per slide
  late AnimationController _slideEntryController;
  late Animation<double> _slideEntryFade;
  late Animation<Offset> _slideEntryOffset;

  // Animasi illustration float
  late AnimationController _floatController;
  late Animation<double> _floatAnim;

  // Animasi orbit background
  late AnimationController _orbitController;


  @override
  void initState() {
    super.initState();

    // Float animation untuk ilustrasi
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: -10, end: 10).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOut),
    );

    // Orbit background
    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    // Entry anim per slide
    _slideEntryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _slideEntryFade = CurvedAnimation(
      parent: _slideEntryController,
      curve: Curves.easeOut,
    );
    _slideEntryOffset = Tween<Offset>(
      begin: const Offset(0.08, 0),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideEntryController, curve: Curves.easeOutCubic),
    );
    _slideEntryController.forward();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _floatController.dispose();
    _orbitController.dispose();
    _slideEntryController.dispose();
    super.dispose();
  }

  void _goToNext() {
    HapticFeedback.selectionClick();
    if (_currentPage < onboardingSlides.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _finishOnboarding();
    }
  }

  void _skipOnboarding() {
    HapticFeedback.lightImpact();
    _finishOnboarding();
  }

  Future<void> _finishOnboarding() =>
      Get.find<OnboardingController>().finish();

  @override
  Widget build(BuildContext context) {
    final slide = onboardingSlides[_currentPage];

    return Scaffold(
      backgroundColor: AppColors.navyDeep,
      body: Stack(
        children: [
          // ── Background orbit animasi ─────────────────────────
          OnboardingBackground(accentColor: slide.accentColor, orbit: _orbitController),

          // ── Konten utama ─────────────────────────────────────
          SafeArea(
            child: Column(
              children: [
                // Skip button atas kanan
                OnboardingTopBar(accentColor: slide.accentColor, onSkip: _skipOnboarding),

                // PageView slides
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: (page) {
                      setState(() => _currentPage = page);
                      _slideEntryController.forward(from: 0);
                      HapticFeedback.selectionClick();
                    },
                    itemCount: onboardingSlides.length,
                    itemBuilder: (_, index) => SlidePage(
                      slide: onboardingSlides[index],
                      entryOffset: _slideEntryOffset,
                      entryFade: _slideEntryFade,
                      floatAnim: _floatAnim,
                      orbit: _orbitController,
                    ),
                  ),
                ),

                // Bottom navigation
                OnboardingBottomNav(
                  slide: slide,
                  slideCount: onboardingSlides.length,
                  currentPage: _currentPage,
                  onNext: _goToNext,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================
// CUSTOM PAINTERS
// =============================================================

/// Grid titik-titik dekoratif di background
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../data/onboarding_slide.dart';
import 'dot_indicators.dart';

/// Indikator titik dan tombol lanjut / mulai.
class OnboardingBottomNav extends StatelessWidget {
  final OnboardSlide slide;
  final int slideCount;
  final int currentPage;
  final VoidCallback onNext;

  const OnboardingBottomNav({super.key, required this.slide, required this.slideCount, required this.currentPage, required this.onNext});

  @override
  Widget build(BuildContext context) {
    final isLast = currentPage == slideCount - 1;

    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 0, 28, 36),
      child: Column(
        children: [
          // Dot indicators
          DotIndicators(accentColor: slide.accentColor, count: slideCount, currentPage: currentPage),
          const SizedBox(height: 28),

          // Tombol utama
          GestureDetector(
            onTap: onNext,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: double.infinity,
              height: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppRadius.md),
                gradient: LinearGradient(
                  colors: isLast
                      ? [AppColors.neonGreen, const Color(0xFF00AA22)]
                      : [const Color(0xFF0077FF), AppColors.neonCyan],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: (isLast ? AppColors.neonGreen : AppColors.neonCyan)
                        .withValues(alpha: 0.30),
                    blurRadius: 18,
                    spreadRadius: -2,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    isLast ? 'Mulai Menggunakan DigiFact' : 'Lanjutkan',
                    style: GoogleFonts.dmSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: isLast ? AppColors.navyDeep : Colors.white,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    isLast ? Icons.rocket_launch_rounded : Icons.arrow_forward_rounded,
                    color: isLast ? AppColors.navyDeep : Colors.white,
                    size: 18,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../../../app/theme/app_colors.dart';
import 'onboarding_painters.dart';

/// Orb latar bergerak dengan warna aksen slide aktif.
class OnboardingBackground extends StatelessWidget {
  final Color accentColor;
  final Animation<double> orbit;

  const OnboardingBackground({super.key, required this.accentColor, required this.orbit});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: orbit,
      builder: (context, _) {
        final t = orbit.value * 2 * math.pi;
        return Stack(
          children: [
            // Gradient base
            AnimatedContainer(
              duration: const Duration(milliseconds: 600),
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -0.3),
                  radius: 1.0,
                  colors: [
                    accentColor.withValues(alpha: 0.07),
                    AppColors.navyDeep,
                  ],
                ),
              ),
            ),
            // Orb floating kiri
            Positioned(
              top: 80 + 25 * math.sin(t * 0.5),
              left: -60 + 15 * math.cos(t * 0.4),
              child: _bgOrb(220, accentColor, 0.06),
            ),
            // Orb floating kanan bawah
            Positioned(
              bottom: 100 + 20 * math.sin(t * 0.6),
              right: -40 + 12 * math.cos(t * 0.5),
              child: _bgOrb(200, accentColor, 0.04),
            ),
            // Grid dots dekoratif
            Positioned.fill(child: _buildDotGrid(accentColor)),
          ],
        );
      },
    );
  }

  Widget _bgOrb(double size, Color color, double alpha) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withValues(alpha: alpha), Colors.transparent],
        ),
      ),
    );
  }

  Widget _buildDotGrid(Color accentColor) {
    return CustomPaint(
      painter: DotGridPainter(color: accentColor.withValues(alpha: 0.025)),
    );
  }

}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../data/onboarding_slide.dart';
import 'slide_illustration.dart';

/// Satu halaman slide onboarding.
class SlidePage extends StatelessWidget {
  final OnboardSlide slide;
  final Animation<Offset> entryOffset;
  final Animation<double> entryFade;
  final Animation<double> floatAnim;
  final Animation<double> orbit;

  const SlidePage({
    super.key,
    required this.slide,
    required this.entryOffset,
    required this.entryFade,
    required this.floatAnim,
    required this.orbit,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: SlideTransition(
        position: entryOffset,
        child: FadeTransition(
          opacity: entryFade,
          // Dapat digulir agar tidak meluap pada layar yang kurang tinggi.
          child: LayoutBuilder(
            builder: (context, constraints) => SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Ilustrasi
                    SlideIllustration(
                      slide: slide,
                      floatAnim: floatAnim,
                      orbit: orbit,
                    ),
                    const SizedBox(height: 36),

                    // Tag step
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: slide.accentColor.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: slide.accentColor.withValues(alpha: 0.25),
                        ),
                      ),
                      child: Text(
                        slide.tag,
                        style: GoogleFonts.dmSans(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: slide.accentColor,
                          letterSpacing: 1.0,
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),

                    // Judul
                    Text(
                      slide.title,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.dmSans(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1.2,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 14),

                    // Deskripsi
                    Text(
                      slide.description,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.dmSans(
                        fontSize: 14,
                        color: AppColors.textSecondary,
                        height: 1.65,
                      ),
                    ),
                    const SizedBox(height: 28),

                    // Feature pills
                    Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 8,
                      runSpacing: 8,
                      children: slide.pills.map((pill) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            color: slide.accentColor.withValues(alpha: 0.07),
                            borderRadius: BorderRadius.circular(30),
                            border: Border.all(
                              color: slide.accentColor.withValues(alpha: 0.18),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                pill.icon,
                                color: slide.accentColor,
                                size: 13,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                pill.label,
                                style: GoogleFonts.dmSans(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: slide.accentColor.withValues(
                                    alpha: 0.9,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

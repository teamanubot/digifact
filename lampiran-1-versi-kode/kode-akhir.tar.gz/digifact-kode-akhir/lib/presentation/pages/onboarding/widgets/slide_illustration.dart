import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../data/onboarding_slide.dart';
import 'onboarding_painters.dart';

/// Ilustrasi melayang dengan cincin orbit.
class SlideIllustration extends StatelessWidget {
  final OnboardSlide slide;
  final Animation<double> floatAnim;
  final Animation<double> orbit;

  const SlideIllustration({super.key, required this.slide, required this.floatAnim, required this.orbit});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: floatAnim,
      builder: (context, _) {
        return Transform.translate(
          offset: Offset(0, floatAnim.value),
          child: SizedBox(
            height: 200,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer decorative ring
                AnimatedBuilder(
                  animation: orbit,
                  builder: (context, _) {
                    return Transform.rotate(
                      angle: orbit.value * 2 * math.pi,
                      child: SizedBox(
                        width: 190,
                        height: 190,
                        child: CustomPaint(
                          painter: DashedRingPainter(
                            color: slide.accentColor.withValues(alpha: 0.15),
                          ),
                        ),
                      ),
                    );
                  },
                ),

                // Glow background circle
                Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        slide.accentColor.withValues(alpha: 0.15),
                        slide.accentColor.withValues(alpha: 0),
                      ],
                    ),
                  ),
                ),

                // Main icon container
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: slide.gradientColors,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(
                      color: slide.accentColor.withValues(alpha: 0.30),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: slide.accentColor.withValues(alpha: 0.25),
                        blurRadius: 32,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: Center(
                    child: ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [slide.accentColor, Colors.white],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: Icon(slide.icon, size: 46, color: Colors.white),
                    ),
                  ),
                ),

                // Orbit mini-dots
                AnimatedBuilder(
                  animation: orbit,
                  builder: (context, _) {
                    return SizedBox(
                      width: 190,
                      height: 190,
                      child: CustomPaint(
                        painter: MiniOrbitDotsPainter(
                          progress: orbit.value,
                          color: slide.accentColor,
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

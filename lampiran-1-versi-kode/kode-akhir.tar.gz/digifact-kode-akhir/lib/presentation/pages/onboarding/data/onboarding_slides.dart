import 'package:flutter/material.dart';

import '../../../../app/theme/app_colors.dart';
import 'onboarding_slide.dart';

/// Konten tiga slide onboarding.
final List<OnboardSlide> onboardingSlides = [
  OnboardSlide(
    tag: 'STEP 01 / 03',
    title: 'Deteksi Hoaks\ndengan AI Cerdas',
    description:
        'DigiFact menggunakan model Machine Learning Random Forest yang dilatih pada ribuan data berita untuk mengklasifikasi informasi secara akurat dan cepat.',
    icon: Icons.psychology_rounded,
    accentColor: AppColors.neonCyan,
    gradientColors: [Color(0xFF003D66), Color(0xFF001A33)],
    pills: [
      FeaturePill('Random Forest', Icons.account_tree_rounded),
      FeaturePill('±88% Akurasi Dataset', Icons.verified_rounded),
      FeaturePill('Analisis Real-time', Icons.bolt_rounded),
    ],
  ),
  OnboardSlide(
    tag: 'STEP 02 / 03',
    title: 'Hasil Transparan\n& Dapat Dipercaya',
    description:
        'Setiap keputusan AI dijelaskan menggunakan SHAP dan LIME — teknologi Explainable AI yang memetakan kata-kata kunci yang paling berpengaruh pada prediksi.',
    icon: Icons.analytics_rounded,
    accentColor: AppColors.neonGreen,
    gradientColors: [Color(0xFF003322), Color(0xFF001A11)],
    pills: [
      FeaturePill('Explainable AI', Icons.auto_awesome_rounded),
      FeaturePill('Analisis SHAP', Icons.bar_chart_rounded),
      FeaturePill('Interpretasi LIME', Icons.science_rounded),
    ],
  ),
  OnboardSlide(
    tag: 'STEP 03 / 03',
    title: 'Tingkatkan\nLiterasi Digitalmu',
    description:
        'Simpan riwayat pengecekan, pelajari panduan 5 langkah cek fakta, dan jadilah konsumen informasi yang lebih kritis dan bertanggung jawab.',
    icon: Icons.shield_rounded,
    accentColor: const Color(0xFFFFAA00),
    gradientColors: [Color(0xFF332200), Color(0xFF1A1100)],
    pills: [
      FeaturePill('Riwayat Tersimpan', Icons.history_rounded),
      FeaturePill('Panduan Cek Fakta', Icons.menu_book_rounded),
      FeaturePill('Bagikan Hasil', Icons.ios_share_rounded),
    ],
  ),
];

import 'package:flutter/material.dart';

class OnboardSlide {
  final String tag;
  final String title;
  final String description;
  final IconData icon;
  final Color accentColor;
  final List<Color> gradientColors;
  final List<FeaturePill> pills;

  const OnboardSlide({
    required this.tag,
    required this.title,
    required this.description,
    required this.icon,
    required this.accentColor,
    required this.gradientColors,
    required this.pills,
  });
}

class FeaturePill {
  final String label;
  final IconData icon;

  const FeaturePill(this.label, this.icon);
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../../../app/theme/app_colors.dart';
import '../../../domain/entities/detection_result.dart';
import '../../../domain/entities/verdict.dart';
import '../../controllers/result_controller.dart';
import '../../widgets/verdict_style.dart';
import 'widgets/ai_analysis_card.dart';
import 'widgets/confidence_gauge_card.dart';
import 'widgets/radial_glow.dart';
import 'widgets/result_app_bar.dart';
import 'widgets/source_text_card.dart';
import 'widgets/verdict_card.dart';
import 'widgets/xai_section_header.dart';
import 'widgets/xai_tabs.dart';

// =============================================================
// RESULT SCREEN – Design Sistem Premium
// =============================================================
class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen>
    with TickerProviderStateMixin {
  final ResultController _controller = Get.find<ResultController>();

  DetectionResult get _result => _controller.result;

  // Animasi gauge
  late AnimationController _gaugeController;
  late Animation<double> _gaugeAnimation;

  // Animasi entry
  late AnimationController _entryController;
  late Animation<double> _entryFade;
  late Animation<Offset> _entrySlide;

  // Animasi pulse badge
  late AnimationController _badgePulse;

  @override
  void initState() {
    super.initState();
    // Gauge animasi masuk – dari 0 ke nilai aktual
    _gaugeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    final double targetScore = _result.confidence;
    _gaugeAnimation = Tween<double>(begin: 0, end: targetScore).animate(
      CurvedAnimation(parent: _gaugeController, curve: Curves.easeOutCubic),
    );

    // Entry fade + slide
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _entryFade = CurvedAnimation(parent: _entryController, curve: Curves.easeOut);
    _entrySlide = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryController, curve: Curves.easeOut));

    // Badge pulse
    _badgePulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    // Mulai semua animasi
    _entryController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _gaugeController.forward();
    });

    // Haptic feedback berdasarkan hasil
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) {
        if (_result.verdict == Verdict.fakta) {
          HapticFeedback.lightImpact();
        } else if (_result.verdict == Verdict.hoaks) {
          HapticFeedback.heavyImpact();
        }
      }
    });
  }

  @override
  void dispose() {
    _gaugeController.dispose();
    _entryController.dispose();
    _badgePulse.dispose();
    super.dispose();
  }

  VerdictStyle get _style => VerdictStyle.of(_result.verdict);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      extendBodyBehindAppBar: true,
      appBar: ResultAppBar(controller: _controller, style: _style),
      body: Stack(
        children: [
          // Glow radial berdasarkan status
          RadialGlow(style: _style),

          FadeTransition(
            opacity: _entryFade,
            child: SlideTransition(
              position: _entrySlide,
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(
                        20,
                        100,
                        20,
                        40 + MediaQuery.viewPaddingOf(context).bottom,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 1. Hero verdict card
                          VerdictCard(style: _style, badgePulse: _badgePulse),
                          const SizedBox(height: 22),

                          // 2. Confidence circular gauge
                          ConfidenceGaugeCard(
                            result: _result,
                            style: _style,
                            gaugeAnimation: _gaugeAnimation,
                          ),
                          const SizedBox(height: 22),

                          // 3. Teks sumber
                          SourceTextCard(result: _result),
                          const SizedBox(height: 22),

                          // 4. Interpretasi AI
                          AiAnalysisCard(result: _result),
                          const SizedBox(height: 22),

                          // 5. XAI – SHAP & LIME
                          const XaiSectionHeader(),
                          const SizedBox(height: 14),
                          XaiTabs(result: _result),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================
// CUSTOM PAINTER – Advanced Circular Gauge
// =============================================================
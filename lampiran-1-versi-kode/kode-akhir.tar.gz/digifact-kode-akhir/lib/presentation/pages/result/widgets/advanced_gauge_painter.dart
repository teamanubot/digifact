import 'dart:math' as math;
import 'package:flutter/material.dart';

class AdvancedGaugePainter extends CustomPainter {
  final double value;
  final List<Color> gradientColors;
  final Color statusColor;
  final Color trackColor;

  AdvancedGaugePainter({
    required this.value,
    required this.gradientColors,
    required this.statusColor,
    required this.trackColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final outerRadius = math.min(size.width / 2, size.height / 2) - 4;
    const strokeW = 16.0;
    final radius = outerRadius - strokeW / 2;

    // Track (latar belakang arc)
    final trackPaint = Paint()
      ..color = trackColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeW
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2,
      2 * math.pi,
      false,
      trackPaint,
    );

    // Tick marks halus
    final tickPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.06)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    for (int i = 0; i < 20; i++) {
      final angle = -math.pi / 2 + (i / 20) * 2 * math.pi;
      final start = Offset(
        center.dx + (radius - 9) * math.cos(angle),
        center.dy + (radius - 9) * math.sin(angle),
      );
      final end = Offset(
        center.dx + (radius + 9) * math.cos(angle),
        center.dy + (radius + 9) * math.sin(angle),
      );
      canvas.drawLine(start, end, tickPaint);
    }

    if (value <= 0) return;

    final sweepAngle = 2 * math.pi * value;
    final rect = Rect.fromCircle(center: center, radius: radius);

    // Active arc gradient
    final activePaint = Paint()
      ..shader = SweepGradient(
        colors: [
          ...gradientColors,
          gradientColors.last,
        ],
        startAngle: 0,
        endAngle: 2 * math.pi,
      ).createShader(rect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeW
      ..strokeCap = StrokeCap.round;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(-math.pi / 2);
    canvas.translate(-center.dx, -center.dy);
    canvas.drawArc(rect, 0, sweepAngle, false, activePaint);
    canvas.restore();

    // Glow tip dot
    final tipAngle = -math.pi / 2 + sweepAngle;
    final tipX = center.dx + radius * math.cos(tipAngle);
    final tipY = center.dy + radius * math.sin(tipAngle);

    final glowPaint = Paint()
      ..color = statusColor.withValues(alpha: 0.35)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawCircle(Offset(tipX, tipY), 10, glowPaint);

    final tipPaint = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(tipX, tipY), 6, tipPaint);

    final tipInnerPaint = Paint()..color = statusColor;
    canvas.drawCircle(Offset(tipX, tipY), 4, tipInnerPaint);
  }

  @override
  bool shouldRepaint(AdvancedGaugePainter old) =>
      old.value != value || old.statusColor != statusColor;
}

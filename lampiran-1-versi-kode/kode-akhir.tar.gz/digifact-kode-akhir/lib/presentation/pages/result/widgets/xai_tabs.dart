import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../../domain/entities/detection_result.dart';
import '../../../../domain/entities/word_weight.dart';

/// Tab penjelasan kata kunci: SHAP dan LIME.
class XaiTabs extends StatefulWidget {
  final DetectionResult result;

  const XaiTabs({super.key, required this.result});

  @override
  State<XaiTabs> createState() => _XaiTabsState();
}

class _XaiTabsState extends State<XaiTabs> with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 2, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Container(
              height: 52,
              decoration: BoxDecoration(
                color: AppColors.navy.withValues(alpha: 0.6),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: AppColors.borderSubtle.withValues(alpha: 0.5)),
              ),
              child: AnimatedBuilder(
                animation: _tabController.animation!,
                builder: (context, _) {
                  final progress = _tabController.animation!.value;
                  return Stack(
                    children: [
                      // Indikator geser (Sliding Indicator)
                      AnimatedAlign(
                        duration: const Duration(milliseconds: 100),
                        alignment: Alignment(progress * 2.0 - 1.0, 0.0),
                        child: FractionallySizedBox(
                          widthFactor: 0.5,
                          child: Container(
                            margin: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [AppColors.neonCyan, AppColors.neonBlue],
                              ),
                              borderRadius: BorderRadius.circular(26),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.neonCyan.withValues(alpha: 0.35),
                                  blurRadius: 10,
                                  spreadRadius: -2,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      // Tombol Segment
                      Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () {
                                HapticFeedback.selectionClick();
                                _tabController.animateTo(0);
                              },
                              child: Center(
                                child: Text(
                                  'Kata Kunci Utama\n(SHAP)',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2,
                                    color: progress < 0.5 ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () {
                                HapticFeedback.selectionClick();
                                _tabController.animateTo(1);
                              },
                              child: Center(
                                child: Text(
                                  'Kata Kunci Spesifik\n(LIME)',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2,
                                    color: progress >= 0.5 ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
          SizedBox(
            height: 300,
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildXaiList(widget.result.penjelasanShap),
                _buildXaiList(widget.result.penjelasanLime),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildXaiList(List<WordWeight> words) {
    if (words.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.data_array_rounded, color: AppColors.textMuted, size: 30),
            const SizedBox(height: 10),
            Text(
              'Tidak ada data kata kunci.',
              style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.textSecondary),
            ),
          ],
        ),
      );
    }

    double sumVal = 0.0;
    for (var w in words) {
      sumVal += w.bobot.abs();
    }
    if (sumVal == 0.0) sumVal = 1.0;

    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      itemCount: words.length,
      itemBuilder: (_, i) {
        final item = words[i];
        final isHoaxDriver = item.bobot > 0;
        final barColor = isHoaxDriver ? AppColors.neonRed : AppColors.neonGreen;
        final contribution = item.bobot.abs() / sumVal;
        final percent = (contribution * 100).toStringAsFixed(0);

        String strengthText;
        if (contribution >= 0.40) {
          strengthText = 'Sangat Kuat ($percent%)';
        } else if (contribution >= 0.20) {
          strengthText = 'Kuat ($percent%)';
        } else if (contribution >= 0.10) {
          strengthText = 'Sedang ($percent%)';
        } else {
          strengthText = 'Lemah ($percent%)';
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '"${item.kata}"',
                    style: GoogleFonts.dmSans(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: barColor.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      isHoaxDriver ? 'Cenderung Hoaks' : 'Cenderung Fakta',
                      style: GoogleFonts.dmSans(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        color: barColor,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 10,
                      decoration: BoxDecoration(
                        color: AppColors.navyElevated,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: contribution.clamp(0.05, 1.0),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [barColor.withValues(alpha: 0.6), barColor],
                            ),
                            borderRadius: BorderRadius.circular(5),
                            boxShadow: [
                              BoxShadow(
                                color: barColor.withValues(alpha: 0.3),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    strengthText,
                    style: GoogleFonts.dmSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: barColor.withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

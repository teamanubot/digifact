import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../controllers/result_controller.dart';
import '../../../widgets/verdict_style.dart';

/// AppBar transparan dengan aksi simpan dan bagikan.
class ResultAppBar extends StatelessWidget implements PreferredSizeWidget {
  final ResultController controller;
  final VerdictStyle style;

  const ResultAppBar({super.key, required this.controller, required this.style});

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.navyDeep.withValues(alpha: 0.6),
              border: Border(
                bottom: BorderSide(color: AppColors.borderSubtle.withValues(alpha: 0.5)),
              ),
            ),
          ),
        ),
      ),
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(AppRadius.sm),
            border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
          ),
          child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
        ),
        onPressed: Get.back,
      ),
      title: Text(
        'Hasil Analisis AI',
        style: GoogleFonts.dmSans(
          fontSize: 17,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
      ),
      centerTitle: true,
      actions: [
        Obx(() {
          final isSaved = controller.isSaved.value;
          return IconButton(
            icon: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
              child: Icon(
                isSaved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                key: ValueKey(isSaved),
                color: isSaved ? style.color : Colors.white,
                size: 22,
              ),
            ),
            onPressed: controller.toggleSave,
          );
        }),
        IconButton(
          icon: const Icon(Icons.ios_share_rounded, color: Colors.white, size: 20),
          onPressed: controller.share,
        ),
        const SizedBox(width: 4),
      ],
    );
  }
}

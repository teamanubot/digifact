import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../../domain/entities/detection_result.dart';
import '../../../widgets/bold_text.dart';

/// Interpretasi logika AI dalam bentuk teks.
class AiAnalysisCard extends StatelessWidget {
  final DetectionResult result;

  const AiAnalysisCard({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.neonCyan.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(AppRadius.xs),
                  border: Border.all(color: AppColors.neonCyan.withValues(alpha: 0.2)),
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: AppColors.neonCyan, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                'Interpretasi Logika AI',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.neonCyan.withValues(alpha: 0.04),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.neonCyan.withValues(alpha: 0.10)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.format_quote_rounded,
                  color: AppColors.neonCyan.withValues(alpha: 0.4),
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: BoldText(
                    result.analisisDetail,
                    style: GoogleFonts.dmSans(
                      fontSize: 13.5,
                      color: const Color(0xFFCDD5E0),
                      height: 1.65,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

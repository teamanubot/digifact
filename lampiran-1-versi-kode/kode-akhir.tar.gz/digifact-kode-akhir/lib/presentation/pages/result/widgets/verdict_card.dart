import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../widgets/verdict_style.dart';

/// Kartu vonis utama: ikon berdenyut, label, dan penjelasan singkat.
class VerdictCard extends StatelessWidget {
  final VerdictStyle style;
  final Animation<double> badgePulse;

  const VerdictCard({super.key, required this.style, required this.badgePulse});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.xl),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
          decoration: BoxDecoration(
            color: style.color.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(AppRadius.xl),
            border: Border.all(
              color: style.color.withValues(alpha: 0.25),
              width: 1.5,
            ),
          ),
          child: Column(
            children: [
              // Icon dengan pulse ring
              AnimatedBuilder(
                animation: badgePulse,
                builder: (_, child) {
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      // Outer pulse ring
                      Container(
                        width: 80 + 8 * badgePulse.value,
                        height: 80 + 8 * badgePulse.value,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: style.color.withValues(
                            alpha: 0.06 * (1 - badgePulse.value),
                          ),
                        ),
                      ),
                      // Inner icon container
                      Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: style.color.withValues(alpha: 0.10),
                          border: Border.all(
                            color: style.color.withValues(alpha: 0.30),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: style.color.withValues(alpha: 0.25 * badgePulse.value),
                              blurRadius: 20,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: Icon(style.icon, color: style.color, size: 32),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),

              // Label FAKTA / HOAKS
              Text(
                style.headerLabel,
                style: GoogleFonts.dmSans(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: style.color,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 10),

              // Divider tipis
              Container(
                width: 60,
                height: 1.5,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      style.color.withValues(alpha: 0.5),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),

              Text(
                style.subtitle,
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  color: AppColors.textSecondary,
                  height: 1.55,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

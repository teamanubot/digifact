import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_radius.dart';
import '../../../../domain/entities/detection_result.dart';
import '../../../widgets/verdict_style.dart';
import 'advanced_gauge_painter.dart';

/// Gauge lingkaran tingkat keyakinan dan dua bar probabilitas.
class ConfidenceGaugeCard extends StatelessWidget {
  final DetectionResult result;
  final VerdictStyle style;
  final Animation<double> gaugeAnimation;

  const ConfidenceGaugeCard({super.key, required this.result, required this.style, required this.gaugeAnimation});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.radar_rounded, color: AppColors.neonCyan, size: 16),
              const SizedBox(width: 8),
              Text(
                'Confidence Score',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),

          // Animated Circular Gauge
          AnimatedBuilder(
            animation: gaugeAnimation,
            builder: (_, _) {
              return Center(
                child: SizedBox(
                  width: 200,
                  height: 200,
                  child: CustomPaint(
                    painter: AdvancedGaugePainter(
                      value: gaugeAnimation.value,
                      gradientColors: style.gaugeGradient,
                      statusColor: style.color,
                      trackColor: AppColors.navyElevated,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${(gaugeAnimation.value * 100).toStringAsFixed(1)}%',
                          style: GoogleFonts.dmSans(
                            fontSize: 36,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            letterSpacing: -1.0,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          result.prediksiAkhir.toUpperCase(),
                          style: GoogleFonts.dmSans(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: style.color,
                            letterSpacing: 2.0,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: style.color.withValues(alpha: 0.10),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            _getConfidenceLabelText(gaugeAnimation.value),
                            style: GoogleFonts.dmSans(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: style.color.withValues(alpha: 0.85),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 28),

          // Dua bar indikator bawah
          Row(
            children: [
              Expanded(
                child: _buildProbBar(
                  label: 'Probabilitas Fakta',
                  value: result.probabilitasFakta,
                  color: AppColors.neonGreen,
                  icon: Icons.check_circle_outline_rounded,
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: _buildProbBar(
                  label: 'Probabilitas Hoaks',
                  value: result.probabilitasHoaks,
                  color: AppColors.neonRed,
                  icon: Icons.cancel_outlined,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getConfidenceLabelText(double val) {
    if (val >= 0.85) return 'Sangat Yakin';
    if (val >= 0.70) return 'Cukup Yakin';
    if (val >= 0.55) return 'Sedikit Yakin';
    return 'Tidak Pasti';
  }

  Widget _buildProbBar({
    required String label,
    required double value,
    required Color color,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 5),
            Expanded(
              child: Text(
                label,
                style: GoogleFonts.dmSans(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w500,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: value,
                  backgroundColor: AppColors.navyElevated,
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                  minHeight: 6,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '${(value * 100).toStringAsFixed(1)}%',
              style: GoogleFonts.dmSans(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

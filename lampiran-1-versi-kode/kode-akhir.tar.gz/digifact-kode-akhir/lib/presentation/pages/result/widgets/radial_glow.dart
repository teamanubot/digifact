import 'package:flutter/material.dart';
import '../../../widgets/verdict_style.dart';

/// Cahaya radial di belakang kartu vonis, berwarna sesuai verdict.
class RadialGlow extends StatelessWidget {
  final VerdictStyle style;

  const RadialGlow({super.key, required this.style});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 20,
      left: MediaQuery.of(context).size.width / 2 - 180,
      child: Container(
        width: 360,
        height: 360,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              style.color.withValues(alpha: 0.12),
              style.color.withValues(alpha: 0),
            ],
          ),
        ),
      ),
    );
  }
}

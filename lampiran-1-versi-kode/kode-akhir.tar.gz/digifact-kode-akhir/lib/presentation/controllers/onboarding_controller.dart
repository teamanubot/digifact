import 'package:get/get.dart';

import '../../app/routes/app_routes.dart';
import '../../core/usecase/usecase.dart';
import '../../domain/usecases/mark_onboarding_done.dart';

class OnboardingController extends GetxController {
  final MarkOnboardingDone _markOnboardingDone;

  OnboardingController(this._markOnboardingDone);

  Future<void> finish() async {
    await _markOnboardingDone(const NoParams());
    Get.offNamed(Routes.home);
  }
}

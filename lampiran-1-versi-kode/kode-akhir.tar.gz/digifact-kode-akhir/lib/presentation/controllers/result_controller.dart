import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../app/routes/route_arguments.dart';
import '../../app/theme/app_colors.dart';
import '../../domain/entities/detection_result.dart';
import '../../domain/usecases/delete_result.dart';
import '../../domain/usecases/save_result.dart';
import '../widgets/app_snackbar.dart';

class ResultController extends GetxController {
  final SaveResult _saveResult;
  final DeleteResult _deleteResult;

  ResultController({
    required this._saveResult,
    required this._deleteResult,
  });

  late final DetectionResult result;
  final isSaved = false.obs;

  @override
  void onInit() {
    super.onInit();
    final args = Get.arguments as ResultArguments;
    result = args.result;
    isSaved.value = args.isSaved;
  }

  Future<void> toggleSave() async {
    HapticFeedback.selectionClick();
    if (isSaved.value) {
      await _deleteResult(result.id);
      isSaved.value = false;
      AppSnackbar.show(
        message: 'Dihapus dari riwayat',
        icon: Icons.bookmark_remove_outlined,
        iconColor: AppColors.neonRed,
      );
    } else {
      await _saveResult(result);
      isSaved.value = true;
      AppSnackbar.show(
        message: 'Berhasil disimpan ke riwayat',
        icon: Icons.bookmark_added_rounded,
        iconColor: AppColors.neonGreen,
      );
    }
  }

  /// Menyalin laporan hasil deteksi ke clipboard.
  void share() {
    final probFakta = (result.probabilitasFakta * 100).toStringAsFixed(1);
    final probHoaks = (result.probabilitasHoaks * 100).toStringAsFixed(1);
    final text =
        '🕵️ *DigiFact – Deteksi Berita AI*\n\n'
        '🏷️ Klasifikasi: *${result.prediksiAkhir}*\n'
        '✅ Probabilitas Fakta: $probFakta%\n'
        '❌ Probabilitas Hoaks: $probHoaks%\n\n'
        '🤖 *Analisis AI:*\n${result.analisisDetail}\n\n'
        '—\nDeteksi berita menggunakan *DigiFact* sekarang!';
    Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.lightImpact();
    AppSnackbar.show(
      message: 'Laporan disalin ke clipboard!',
      icon: Icons.copy_rounded,
      iconColor: AppColors.neonCyan,
    );
  }
}

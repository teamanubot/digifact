import 'package:get/get.dart';

import '../../app/routes/app_routes.dart';
import '../../core/usecase/usecase.dart';
import '../../domain/usecases/has_seen_onboarding.dart';

class SplashController extends GetxController {
  final HasSeenOnboarding _hasSeenOnboarding;

  SplashController(this._hasSeenOnboarding);

  bool _navigated = false;

  /// Pindah ke onboarding (pengguna baru) atau beranda. Aman dipanggil berulang.
  void navigateNext() {
    if (_navigated) return;
    _navigated = true;
    Get.offNamed(
      _hasSeenOnboarding(const NoParams()) ? Routes.home : Routes.onboarding,
    );
  }
}

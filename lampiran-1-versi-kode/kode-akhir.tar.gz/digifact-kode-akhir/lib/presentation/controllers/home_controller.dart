import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../app/routes/app_routes.dart';
import '../../app/routes/route_arguments.dart';
import '../../app/theme/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../core/error/failures.dart';
import '../../core/usecase/usecase.dart';
import '../../domain/entities/detection_result.dart';
import '../../domain/usecases/check_server_status.dart';
import '../../domain/usecases/detect_hoax.dart';
import '../../domain/usecases/get_history.dart';
import '../../domain/usecases/reset_onboarding.dart';
import '../../domain/usecases/save_result.dart';
import '../widgets/app_snackbar.dart';
import '../widgets/error_dialog.dart';

class HomeController extends GetxController {
  final CheckServerStatus _checkServerStatus;
  final DetectHoax _detectHoax;
  final GetHistory _getHistory;
  final SaveResult _saveResult;
  final ResetOnboarding _resetOnboarding;

  HomeController({
    required this._checkServerStatus,
    required this._detectHoax,
    required this._getHistory,
    required this._saveResult,
    required this._resetOnboarding,
  });

  final textController = TextEditingController();

  final isLoading = false.obs;
  final isServerActive = false.obs;
  final hasInput = false.obs;
  final recentHistory = <DetectionResult>[].obs;

  @override
  void onInit() {
    super.onInit();
    textController.addListener(
      () => hasInput.value = textController.text.isNotEmpty,
    );
    checkServer();
    loadRecentHistory();
  }

  @override
  void onClose() {
    textController.dispose();
    super.onClose();
  }

  Future<void> checkServer() async {
    isServerActive.value = await _checkServerStatus(const NoParams());
  }

  void loadRecentHistory() {
    recentHistory.assignAll(
      _getHistory(const NoParams()).take(AppConstants.recentHistoryCount),
    );
  }

  void clearInput() => textController.clear();

  Future<void> detect() async {
    if (isLoading.value) return;

    HapticFeedback.mediumImpact();
    isLoading.value = true;

    final DetectionResult result;
    var saved = true;
    try {
      result = await _detectHoax(textController.text);
      try {
        await _saveResult(result);
      } on CacheFailure catch (e) {
        // Vonis sudah berhasil; kegagalan menyimpan tidak boleh menyembunyikannya.
        saved = false;
        AppSnackbar.show(
          message: e.message,
          icon: Icons.error_outline_rounded,
          iconColor: AppColors.neonRed,
        );
      }
    } on ValidationFailure catch (e) {
      AppSnackbar.show(
        message: e.message,
        icon: Icons.info_outline_rounded,
        iconColor: AppColors.neonRed,
      );
      return;
    } catch (e) {
      HapticFeedback.heavyImpact();
      Get.dialog(ErrorDialog(message: e.toString()));
      return;
    } finally {
      // Berhenti loading sebelum berpindah halaman; openResult menunggu
      // sampai halaman hasil ditutup.
      isLoading.value = false;
    }

    loadRecentHistory();
    await openResult(result, isSaved: saved);
  }

  Future<void> openResult(DetectionResult result, {bool isSaved = true}) async {
    await Get.toNamed(
      Routes.result,
      arguments: ResultArguments(result: result, isSaved: isSaved),
    );
    loadRecentHistory();
  }

  Future<void> openHistory() async {
    await Get.toNamed(Routes.history);
    loadRecentHistory();
  }

  void openEducation() => Get.toNamed(Routes.education);

  Future<void> resetOnboarding() async {
    HapticFeedback.mediumImpact();
    await _resetOnboarding(const NoParams());
    AppSnackbar.show(
      message: 'Status Onboarding berhasil direset!',
      icon: Icons.check_circle_rounded,
      iconColor: AppColors.neonGreen,
      iconSize: 18,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../app/routes/app_routes.dart';
import '../../app/routes/route_arguments.dart';
import '../../app/theme/app_colors.dart';
import '../../core/usecase/usecase.dart';
import '../../domain/entities/detection_result.dart';
import '../../domain/usecases/clear_history.dart';
import '../../domain/usecases/delete_result.dart';
import '../../domain/usecases/get_history.dart';
import '../widgets/app_snackbar.dart';

class HistoryController extends GetxController {
  final GetHistory _getHistory;
  final DeleteResult _deleteResult;
  final ClearHistory _clearHistory;

  HistoryController({
    required this._getHistory,
    required this._deleteResult,
    required this._clearHistory,
  });

  final history = <DetectionResult>[].obs;

  @override
  void onInit() {
    super.onInit();
    loadHistory();
  }

  void loadHistory() => history.assignAll(_getHistory(const NoParams()));

  Future<void> deleteItem(String id) async {
    HapticFeedback.mediumImpact();
    await _deleteResult(id);
    loadHistory();
    AppSnackbar.show(
      message: 'Riwayat berhasil dihapus',
      icon: Icons.delete_outline_rounded,
      iconColor: AppColors.neonRed,
    );
  }

  Future<void> clearAll() async {
    HapticFeedback.heavyImpact();
    await _clearHistory(const NoParams());
    loadHistory();
    AppSnackbar.show(
      message: 'Semua riwayat telah dibersihkan',
      icon: Icons.delete_sweep_rounded,
      iconColor: AppColors.neonRed,
    );
  }

  Future<void> openResult(DetectionResult item) async {
    await Get.toNamed(
      Routes.result,
      arguments: ResultArguments(result: item, isSaved: true),
    );
    loadHistory();
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app/bindings/initial_binding.dart';
import 'app/routes/app_pages.dart';
import 'app/theme/app_theme.dart';
import 'core/usecase/usecase.dart';
import 'domain/usecases/check_onboarding_expiry.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Tata letak layar penuh (edge-to-edge), wajib pada Android 15 (SDK 35).
  // Konten digambar di belakang status bar dan navigation bar; inset
  // ditangani oleh SafeArea/MediaQuery di tiap layar.
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      systemNavigationBarContrastEnforced: false,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Kunci orientasi ke portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  final prefs = await SharedPreferences.getInstance();
  InitialBinding(prefs: prefs).dependencies();
  await Get.find<CheckOnboardingExpiry>()(const NoParams());

  runApp(const DigiFactApp());
}

class DigiFactApp extends StatelessWidget {
  const DigiFactApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'DigiFact',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      initialRoute: AppPages.initial,
      getPages: AppPages.pages,
    );
  }
}

import '../../domain/entities/detection_result.dart';
import 'word_weight_model.dart';

class DetectionResultModel extends DetectionResult {
  const DetectionResultModel({
    required super.id,
    required super.teksAsli,
    required super.probabilitasFakta,
    required super.probabilitasHoaks,
    required super.prediksiAkhir,
    required super.penjelasanShap,
    required super.penjelasanLime,
    required super.analisisDetail,
    required super.tanggalDeteksi,
  });

  factory DetectionResultModel.fromJson(Map<String, dynamic> json) {
    List<WordWeightModel> parseWeights(dynamic raw) =>
        (raw as List?)
            ?.map((e) => WordWeightModel.fromJson(e as Map<String, dynamic>))
            .toList() ??
        [];

    return DetectionResultModel(
      id: json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
      teksAsli: json['teks_asli'] ?? '',
      probabilitasFakta: (json['probabilitas_fakta'] as num).toDouble(),
      probabilitasHoaks: (json['probabilitas_hoaks'] as num).toDouble(),
      prediksiAkhir: json['prediksi_akhir'] ?? '',
      penjelasanShap: parseWeights(json['penjelasan_shap']),
      penjelasanLime: parseWeights(json['penjelasan_lime']),
      analisisDetail: json['analisis_detail'] ?? '',
      tanggalDeteksi: json['tanggal_deteksi'] != null
          ? DateTime.parse(json['tanggal_deteksi'])
          : DateTime.now(),
    );
  }

  factory DetectionResultModel.fromEntity(DetectionResult entity) {
    return DetectionResultModel(
      id: entity.id,
      teksAsli: entity.teksAsli,
      probabilitasFakta: entity.probabilitasFakta,
      probabilitasHoaks: entity.probabilitasHoaks,
      prediksiAkhir: entity.prediksiAkhir,
      penjelasanShap:
          entity.penjelasanShap.map(WordWeightModel.fromEntity).toList(),
      penjelasanLime:
          entity.penjelasanLime.map(WordWeightModel.fromEntity).toList(),
      analisisDetail: entity.analisisDetail,
      tanggalDeteksi: entity.tanggalDeteksi,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'teks_asli': teksAsli,
        'probabilitas_fakta': probabilitasFakta,
        'probabilitas_hoaks': probabilitasHoaks,
        'prediksi_akhir': prediksiAkhir,
        'penjelasan_shap': penjelasanShap
            .map((e) => WordWeightModel.fromEntity(e).toJson())
            .toList(),
        'penjelasan_lime': penjelasanLime
            .map((e) => WordWeightModel.fromEntity(e).toJson())
            .toList(),
        'analisis_detail': analisisDetail,
        'tanggal_deteksi': tanggalDeteksi.toIso8601String(),
      };
}

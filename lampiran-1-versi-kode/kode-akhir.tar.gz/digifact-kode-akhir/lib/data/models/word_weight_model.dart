import '../../domain/entities/word_weight.dart';

class WordWeightModel extends WordWeight {
  const WordWeightModel({required super.kata, required super.bobot});

  factory WordWeightModel.fromJson(Map<String, dynamic> json) {
    return WordWeightModel(
      kata: json['kata'] ?? '',
      bobot: (json['bobot'] as num).toDouble(),
    );
  }

  factory WordWeightModel.fromEntity(WordWeight entity) {
    return WordWeightModel(kata: entity.kata, bobot: entity.bobot);
  }

  Map<String, dynamic> toJson() => {'kata': kata, 'bobot': bobot};
}

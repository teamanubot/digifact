import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/constants/storage_keys.dart';
import '../../models/detection_result_model.dart';

abstract class HistoryLocalDataSource {
  List<DetectionResultModel> getHistory();

  Future<void> saveAll(List<DetectionResultModel> history);

  Future<void> clearHistory();
}

class HistoryLocalDataSourceImpl implements HistoryLocalDataSource {
  final SharedPreferences _prefs;

  HistoryLocalDataSourceImpl(this._prefs);

  @override
  List<DetectionResultModel> getHistory() {
    final listJson = _prefs.getStringList(StorageKeys.history);
    if (listJson == null) return [];
    try {
      return listJson
          .map((item) => DetectionResultModel.fromJson(json.decode(item)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  @override
  Future<void> saveAll(List<DetectionResultModel> history) async {
    await _prefs.setStringList(
      StorageKeys.history,
      history.map((item) => json.encode(item.toJson())).toList(),
    );
  }

  @override
  Future<void> clearHistory() async {
    await _prefs.remove(StorageKeys.history);
  }
}

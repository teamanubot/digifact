import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/constants/app_constants.dart';
import '../../../core/constants/storage_keys.dart';

abstract class OnboardingLocalDataSource {
  bool get hasSeenOnboarding;

  Future<void> markOnboardingDone();

  Future<void> resetOnboarding();

  Future<void> checkAndResetOnboardingExpiry();
}

class OnboardingLocalDataSourceImpl implements OnboardingLocalDataSource {
  final SharedPreferences _prefs;

  OnboardingLocalDataSourceImpl(this._prefs);

  @override
  bool get hasSeenOnboarding =>
      _prefs.getBool(StorageKeys.onboardingDone) ?? false;

  @override
  Future<void> markOnboardingDone() async {
    await _prefs.setBool(StorageKeys.onboardingDone, true);
  }

  @override
  Future<void> resetOnboarding() async {
    await _prefs.remove(StorageKeys.onboardingDone);
  }

  @override
  Future<void> checkAndResetOnboardingExpiry() async {
    final lastOpened = _lastOpenedTime;
    if (lastOpened != null &&
        DateTime.now().difference(lastOpened).inDays >=
            AppConstants.onboardingExpiryDays) {
      await resetOnboarding();
    }
    await _prefs.setString(
      StorageKeys.lastOpened,
      DateTime.now().toIso8601String(),
    );
  }

  DateTime? get _lastOpenedTime {
    final timeStr = _prefs.getString(StorageKeys.lastOpened);
    return timeStr == null ? null : DateTime.tryParse(timeStr);
  }
}

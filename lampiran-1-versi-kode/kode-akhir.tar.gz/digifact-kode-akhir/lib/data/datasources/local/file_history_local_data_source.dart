import 'dart:convert';
import 'dart:io';

import '../../models/detection_result_model.dart';
import 'history_local_data_source.dart';

/// Implementasi alternatif [HistoryLocalDataSource] yang menyimpan riwayat
/// sebagai satu berkas JSON, bukan SharedPreferences.
///
/// Tidak dipasang di DI secara default. Ada untuk menunjukkan bahwa
/// penyimpanan dapat diganti dengan mengubah satu baris di `InitialBinding`
/// tanpa menyentuh domain maupun presentation (lihat
/// `test/data/history_data_source_contract_test.dart` dan
/// `docs/ARSITEKTUR.md`, bagian studi kasus perubahan).
class FileHistoryLocalDataSource implements HistoryLocalDataSource {
  final File _file;

  FileHistoryLocalDataSource(this._file);

  @override
  List<DetectionResultModel> getHistory() {
    try {
      if (!_file.existsSync()) return [];
      final decoded = json.decode(_file.readAsStringSync()) as List;
      return decoded
          .map((e) => DetectionResultModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  @override
  Future<void> saveAll(List<DetectionResultModel> history) async {
    await _file.parent.create(recursive: true);
    await _file.writeAsString(json.encode(history.map((e) => e.toJson()).toList()));
  }

  @override
  Future<void> clearHistory() async {
    if (await _file.exists()) await _file.delete();
  }
}

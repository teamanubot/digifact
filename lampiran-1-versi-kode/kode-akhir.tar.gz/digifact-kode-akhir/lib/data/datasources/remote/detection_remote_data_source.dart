import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../../core/constants/api_constants.dart';
import '../../../core/error/exceptions.dart';
import '../../models/detection_result_model.dart';

abstract class DetectionRemoteDataSource {
  Future<bool> checkServerStatus();

  Future<DetectionResultModel> detectHoax(String textOrUrl);
}

class DetectionRemoteDataSourceImpl implements DetectionRemoteDataSource {
  final http.Client _client;

  DetectionRemoteDataSourceImpl(this._client);

  @override
  Future<bool> checkServerStatus() async {
    try {
      final response = await _client
          .get(Uri.parse('${ApiConstants.baseUrl}/'))
          .timeout(ApiConstants.healthCheckTimeout);
      return response.statusCode == 200 || response.statusCode == 405;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<DetectionResultModel> detectHoax(String textOrUrl) async {
    final uri = Uri.parse('${ApiConstants.baseUrl}${ApiConstants.detectPath}');

    try {
      final response = await _client
          .post(
            uri,
            headers: const {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: json.encode({'teks_berita': textOrUrl}),
          )
          .timeout(ApiConstants.detectTimeout);

      if (response.statusCode == 200) {
        return DetectionResultModel.fromJson(json.decode(response.body));
      }
      throw ServerException(_extractErrorMessage(response.body));
    } on ServerException {
      rethrow;
    } on TimeoutException {
      throw const RequestTimeoutException();
    } on http.ClientException {
      throw NetworkException(
        'Gagal menghubungi server FastAPI di ${ApiConstants.baseUrl}. '
        'Pastikan server Anda berjalan.',
      );
    } catch (e) {
      throw ServerException(e.toString().replaceAll('Exception: ', ''));
    }
  }

  String _extractErrorMessage(String body) {
    try {
      final data = json.decode(body);
      if (data is Map && data.containsKey('detail')) {
        return data['detail'].toString();
      }
    } catch (_) {}
    return 'Terjadi kesalahan pada server (Status: tidak diketahui)';
  }
}

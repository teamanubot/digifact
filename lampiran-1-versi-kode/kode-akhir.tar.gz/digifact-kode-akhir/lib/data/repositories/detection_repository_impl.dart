import '../../core/error/exceptions.dart';
import '../../core/error/failures.dart';
import '../../domain/entities/detection_result.dart';
import '../../domain/repositories/detection_repository.dart';
import '../datasources/remote/detection_remote_data_source.dart';

class DetectionRepositoryImpl implements DetectionRepository {
  final DetectionRemoteDataSource _remote;

  DetectionRepositoryImpl(this._remote);

  @override
  Future<bool> checkServerStatus() => _remote.checkServerStatus();

  @override
  Future<DetectionResult> detectHoax(String textOrUrl) async {
    try {
      return await _remote.detectHoax(textOrUrl);
    } on ServerException catch (e) {
      throw ServerFailure(e.message);
    } on NetworkException catch (e) {
      throw NetworkFailure(e.message);
    } on RequestTimeoutException {
      throw const TimeoutFailure(
        'Server terlalu lama merespons. Silakan coba lagi.',
      );
    }
  }
}

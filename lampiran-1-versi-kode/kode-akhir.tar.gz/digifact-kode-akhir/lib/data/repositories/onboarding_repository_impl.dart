import '../../domain/repositories/onboarding_repository.dart';
import '../datasources/local/onboarding_local_data_source.dart';

class OnboardingRepositoryImpl implements OnboardingRepository {
  final OnboardingLocalDataSource _local;

  OnboardingRepositoryImpl(this._local);

  @override
  bool get hasSeenOnboarding => _local.hasSeenOnboarding;

  @override
  Future<void> markOnboardingDone() => _local.markOnboardingDone();

  @override
  Future<void> resetOnboarding() => _local.resetOnboarding();

  @override
  Future<void> checkAndResetOnboardingExpiry() =>
      _local.checkAndResetOnboardingExpiry();
}

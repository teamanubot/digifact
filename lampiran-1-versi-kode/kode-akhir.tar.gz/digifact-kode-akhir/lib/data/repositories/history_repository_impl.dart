import '../../core/error/failures.dart';
import '../../domain/entities/detection_result.dart';
import '../../domain/repositories/history_repository.dart';
import '../datasources/local/history_local_data_source.dart';
import '../models/detection_result_model.dart';

class HistoryRepositoryImpl implements HistoryRepository {
  final HistoryLocalDataSource _local;

  HistoryRepositoryImpl(this._local);

  @override
  // Salin ke List<DetectionResult> agar tipe runtime-nya bukan List<DetectionResultModel>;
  // use case boleh menyisipkan entity biasa ke dalamnya.
  List<DetectionResult> getHistory() =>
      List<DetectionResult>.of(_local.getHistory());

  @override
  Future<void> saveHistory(List<DetectionResult> history) async {
    try {
      await _local.saveAll(
        history.map(DetectionResultModel.fromEntity).toList(),
      );
    } catch (_) {
      throw const CacheFailure('Riwayat tidak dapat disimpan di perangkat.');
    }
  }

  @override
  Future<void> clearHistory() async {
    try {
      await _local.clearHistory();
    } catch (_) {
      throw const CacheFailure('Riwayat tidak dapat dihapus dari perangkat.');
    }
  }
}

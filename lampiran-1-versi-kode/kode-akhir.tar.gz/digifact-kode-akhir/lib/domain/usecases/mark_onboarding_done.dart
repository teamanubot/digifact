import '../../core/usecase/usecase.dart';
import '../repositories/onboarding_repository.dart';

class MarkOnboardingDone extends UseCase<Future<void>, NoParams> {
  final OnboardingRepository _repository;

  const MarkOnboardingDone(this._repository);

  @override
  Future<void> call(NoParams params) => _repository.markOnboardingDone();
}

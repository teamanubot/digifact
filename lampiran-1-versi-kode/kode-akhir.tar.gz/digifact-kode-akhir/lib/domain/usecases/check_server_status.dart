import '../../core/usecase/usecase.dart';
import '../repositories/detection_repository.dart';

class CheckServerStatus extends UseCase<Future<bool>, NoParams> {
  final DetectionRepository _repository;

  const CheckServerStatus(this._repository);

  @override
  Future<bool> call(NoParams params) => _repository.checkServerStatus();
}

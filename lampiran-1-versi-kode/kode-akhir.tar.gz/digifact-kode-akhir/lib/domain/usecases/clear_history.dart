import '../../core/usecase/usecase.dart';
import '../repositories/history_repository.dart';

class ClearHistory extends UseCase<Future<void>, NoParams> {
  final HistoryRepository _repository;

  const ClearHistory(this._repository);

  @override
  Future<void> call(NoParams params) => _repository.clearHistory();
}

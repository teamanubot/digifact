import '../../core/usecase/usecase.dart';
import '../repositories/onboarding_repository.dart';

class CheckOnboardingExpiry extends UseCase<Future<void>, NoParams> {
  final OnboardingRepository _repository;

  const CheckOnboardingExpiry(this._repository);

  @override
  Future<void> call(NoParams params) => _repository.checkAndResetOnboardingExpiry();
}

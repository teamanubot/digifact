import '../../core/usecase/usecase.dart';
import '../repositories/onboarding_repository.dart';

class HasSeenOnboarding extends UseCase<bool, NoParams> {
  final OnboardingRepository _repository;

  const HasSeenOnboarding(this._repository);

  @override
  bool call(NoParams params) => _repository.hasSeenOnboarding;
}

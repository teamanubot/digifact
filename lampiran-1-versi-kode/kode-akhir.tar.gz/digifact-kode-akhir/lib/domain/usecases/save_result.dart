import '../../core/constants/app_constants.dart';
import '../../core/usecase/usecase.dart';
import '../entities/detection_result.dart';
import '../repositories/history_repository.dart';

/// Menyimpan hasil ke riwayat.
///
/// Aturan bisnis: id yang sama menimpa data lama, hasil terbaru berada di
/// urutan pertama, dan riwayat dibatasi [AppConstants.maxHistoryItems] item
/// (yang terlama dibuang).
class SaveResult extends UseCase<Future<void>, DetectionResult> {
  final HistoryRepository _repository;

  const SaveResult(this._repository);

  @override
  Future<void> call(DetectionResult params) {
    final history = _repository.getHistory()
      ..removeWhere((item) => item.id == params.id)
      ..insert(0, params);
    return _repository.saveHistory(
      history.take(AppConstants.maxHistoryItems).toList(),
    );
  }
}

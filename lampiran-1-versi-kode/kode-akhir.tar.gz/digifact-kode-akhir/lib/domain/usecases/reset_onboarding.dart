import '../../core/usecase/usecase.dart';
import '../repositories/onboarding_repository.dart';

class ResetOnboarding extends UseCase<Future<void>, NoParams> {
  final OnboardingRepository _repository;

  const ResetOnboarding(this._repository);

  @override
  Future<void> call(NoParams params) => _repository.resetOnboarding();
}

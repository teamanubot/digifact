import '../../core/usecase/usecase.dart';
import '../entities/detection_result.dart';
import '../repositories/history_repository.dart';

/// Riwayat deteksi, diurutkan dari yang terbaru.
class GetHistory extends UseCase<List<DetectionResult>, NoParams> {
  final HistoryRepository _repository;

  const GetHistory(this._repository);

  @override
  List<DetectionResult> call(NoParams params) {
    return _repository.getHistory()
      ..sort((a, b) => b.tanggalDeteksi.compareTo(a.tanggalDeteksi));
  }
}

import '../../core/usecase/usecase.dart';
import '../repositories/history_repository.dart';

class DeleteResult extends UseCase<Future<void>, String> {
  final HistoryRepository _repository;

  const DeleteResult(this._repository);

  @override
  Future<void> call(String params) {
    final history = _repository.getHistory()
      ..removeWhere((item) => item.id == params);
    return _repository.saveHistory(history);
  }
}

import '../../core/constants/app_constants.dart';
import '../../core/error/failures.dart';
import '../../core/usecase/usecase.dart';
import '../entities/detection_result.dart';
import '../repositories/detection_repository.dart';

/// Mendeteksi teks berita atau URL.
///
/// Aturan bisnis: input dipangkas (trim), tidak boleh kosong, dan minimal
/// [AppConstants.minInputLength] karakter. Pelanggaran melempar [ValidationFailure].
class DetectHoax extends UseCase<Future<DetectionResult>, String> {
  final DetectionRepository _repository;

  const DetectHoax(this._repository);

  @override
  Future<DetectionResult> call(String params) {
    final input = params.trim();
    if (input.isEmpty) {
      throw const ValidationFailure(
        'Silakan masukkan teks berita atau URL terlebih dahulu.',
      );
    }
    if (input.length < AppConstants.minInputLength) {
      throw const ValidationFailure(
        'Teks terlalu pendek. Masukkan minimal '
        '${AppConstants.minInputLength} karakter.',
      );
    }
    return _repository.detectHoax(input);
  }
}

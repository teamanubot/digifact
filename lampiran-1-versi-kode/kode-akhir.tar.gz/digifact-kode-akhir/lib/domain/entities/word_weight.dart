/// Bobot kontribusi sebuah kata terhadap prediksi model (SHAP / LIME).
class WordWeight {
  final String kata;
  final double bobot;

  const WordWeight({required this.kata, required this.bobot});
}

import 'verdict.dart';
import 'word_weight.dart';

/// Hasil deteksi berita beserta penjelasan model (Explainable AI).
class DetectionResult {
  final String id;
  final String teksAsli;
  final double probabilitasFakta;
  final double probabilitasHoaks;
  final String prediksiAkhir;
  final List<WordWeight> penjelasanShap;
  final List<WordWeight> penjelasanLime;
  final String analisisDetail;
  final DateTime tanggalDeteksi;

  const DetectionResult({
    required this.id,
    required this.teksAsli,
    required this.probabilitasFakta,
    required this.probabilitasHoaks,
    required this.prediksiAkhir,
    required this.penjelasanShap,
    required this.penjelasanLime,
    required this.analisisDetail,
    required this.tanggalDeteksi,
  });

  Verdict get verdict => Verdict.fromLabel(prediksiAkhir);

  /// Tingkat keyakinan pada kesimpulan akhir (0..1). Untuk hasil netral,
  /// keyakinan didefinisikan 0.5 karena model tidak memutuskan.
  double get confidence {
    switch (verdict) {
      case Verdict.fakta:
        return probabilitasFakta;
      case Verdict.hoaks:
        return probabilitasHoaks;
      case Verdict.netral:
        return 0.5;
    }
  }
}

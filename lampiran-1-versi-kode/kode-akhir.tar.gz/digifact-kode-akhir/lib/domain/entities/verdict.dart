/// Kesimpulan akhir klasifikasi. Label mentah dari API dipetakan di sini agar
/// lapisan UI tidak membandingkan string secara langsung.
enum Verdict {
  fakta('Fakta'),
  hoaks('Hoaks'),
  netral('Netral / Perlu Verifikasi Manual');

  final String label;
  const Verdict(this.label);

  /// Label tak dikenal diperlakukan sebagai [netral] (perlu verifikasi manual).
  static Verdict fromLabel(String label) {
    switch (label.trim().toLowerCase()) {
      case 'fakta':
        return Verdict.fakta;
      case 'hoaks':
        return Verdict.hoaks;
      default:
        return Verdict.netral;
    }
  }
}

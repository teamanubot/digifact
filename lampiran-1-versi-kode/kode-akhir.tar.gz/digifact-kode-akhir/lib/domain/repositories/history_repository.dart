import '../entities/detection_result.dart';

/// Penyimpanan riwayat. Repository hanya membaca/menulis daftar utuh; aturan
/// bisnis (urutan, batas jumlah, duplikat) berada di use case.
abstract class HistoryRepository {
  List<DetectionResult> getHistory();

  Future<void> saveHistory(List<DetectionResult> history);

  Future<void> clearHistory();
}

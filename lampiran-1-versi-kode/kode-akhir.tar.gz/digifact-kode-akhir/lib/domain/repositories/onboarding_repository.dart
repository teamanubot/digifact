abstract class OnboardingRepository {
  bool get hasSeenOnboarding;

  Future<void> markOnboardingDone();

  Future<void> resetOnboarding();

  /// Mereset onboarding jika aplikasi tidak dibuka dalam waktu lama, lalu
  /// memperbarui waktu terakhir aplikasi dibuka.
  Future<void> checkAndResetOnboardingExpiry();
}

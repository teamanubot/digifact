import '../entities/detection_result.dart';

abstract class DetectionRepository {
  /// Mengecek apakah server deteksi aktif.
  Future<bool> checkServerStatus();

  /// Mendeteksi teks berita atau URL. Melempar [Failure] jika gagal.
  Future<DetectionResult> detectHoax(String textOrUrl);
}

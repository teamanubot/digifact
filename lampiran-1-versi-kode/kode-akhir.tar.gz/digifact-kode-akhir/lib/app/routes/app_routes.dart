abstract class Routes {
  const Routes._();

  static const splash = '/splash';
  static const onboarding = '/onboarding';
  static const home = '/home';
  static const history = '/history';
  static const result = '/result';
  static const education = '/education';
}

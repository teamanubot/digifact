import '../../domain/entities/detection_result.dart';

/// Argumen untuk [Routes.result].
class ResultArguments {
  final DetectionResult result;
  final bool isSaved;

  const ResultArguments({required this.result, this.isSaved = false});
}

import 'package:get/get.dart';

import '../../presentation/bindings/history_binding.dart';
import '../../presentation/bindings/home_binding.dart';
import '../../presentation/bindings/onboarding_binding.dart';
import '../../presentation/bindings/result_binding.dart';
import '../../presentation/bindings/splash_binding.dart';
import '../../presentation/pages/education/education_screen.dart';
import '../../presentation/pages/history/history_screen.dart';
import '../../presentation/pages/home/home_screen.dart';
import '../../presentation/pages/onboarding/onboarding_screen.dart';
import '../../presentation/pages/result/result_screen.dart';
import '../../presentation/pages/splash/splash_screen.dart';
import '../transitions/fade_slide_transition.dart';
import 'app_routes.dart';

abstract class AppPages {
  const AppPages._();

  static const initial = Routes.splash;

  static final pages = <GetPage<dynamic>>[
    GetPage(
      name: Routes.splash,
      page: () => const SplashScreen(),
      binding: SplashBinding(),
      transition: Transition.fadeIn,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.onboarding,
      page: () => const OnboardingScreen(),
      binding: OnboardingBinding(),
      customTransition: FadeSlideTransition(slideOffset: 0.05),
      transitionDuration: const Duration(milliseconds: 450),
    ),
    GetPage(
      name: Routes.home,
      page: () => const HomeScreen(),
      binding: HomeBinding(),
      customTransition: FadeSlideTransition(slideOffset: 0.05),
      transitionDuration: const Duration(milliseconds: 450),
    ),
    GetPage(
      name: Routes.history,
      page: () => const HistoryScreen(),
      binding: HistoryBinding(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: Routes.result,
      page: () => const ResultScreen(),
      binding: ResultBinding(),
      customTransition: FadeSlideTransition(),
      transitionDuration: const Duration(milliseconds: 450),
    ),
    GetPage(
      name: Routes.education,
      page: () => const EducationScreen(),
      transition: Transition.rightToLeft,
    ),
  ];
}

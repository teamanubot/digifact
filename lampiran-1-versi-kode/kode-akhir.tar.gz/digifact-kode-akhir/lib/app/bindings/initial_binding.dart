import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../data/datasources/local/history_local_data_source.dart';
import '../../data/datasources/local/onboarding_local_data_source.dart';
import '../../data/datasources/remote/detection_remote_data_source.dart';
import '../../data/repositories/detection_repository_impl.dart';
import '../../data/repositories/history_repository_impl.dart';
import '../../data/repositories/onboarding_repository_impl.dart';
import '../../domain/repositories/detection_repository.dart';
import '../../domain/repositories/history_repository.dart';
import '../../domain/repositories/onboarding_repository.dart';
import '../../domain/usecases/check_onboarding_expiry.dart';
import '../../domain/usecases/check_server_status.dart';
import '../../domain/usecases/clear_history.dart';
import '../../domain/usecases/delete_result.dart';
import '../../domain/usecases/detect_hoax.dart';
import '../../domain/usecases/get_history.dart';
import '../../domain/usecases/has_seen_onboarding.dart';
import '../../domain/usecases/mark_onboarding_done.dart';
import '../../domain/usecases/reset_onboarding.dart';
import '../../domain/usecases/save_result.dart';

/// Dependency injection global (permanent) — dipanggil sekali saat aplikasi start.
///
/// Urutan: external -> data source -> repository -> use case.
class InitialBinding extends Bindings {
  final SharedPreferences prefs;

  InitialBinding({required this.prefs});

  @override
  void dependencies() {
    // External
    Get.put<SharedPreferences>(prefs, permanent: true);
    Get.lazyPut<http.Client>(() => http.Client(), fenix: true);

    // Data sources
    Get.lazyPut<DetectionRemoteDataSource>(
      () => DetectionRemoteDataSourceImpl(Get.find()),
      fenix: true,
    );
    Get.lazyPut<HistoryLocalDataSource>(
      () => HistoryLocalDataSourceImpl(Get.find()),
      fenix: true,
    );
    Get.lazyPut<OnboardingLocalDataSource>(
      () => OnboardingLocalDataSourceImpl(Get.find()),
      fenix: true,
    );

    // Repositories
    Get.lazyPut<DetectionRepository>(
      () => DetectionRepositoryImpl(Get.find()),
      fenix: true,
    );
    Get.lazyPut<HistoryRepository>(
      () => HistoryRepositoryImpl(Get.find()),
      fenix: true,
    );
    Get.lazyPut<OnboardingRepository>(
      () => OnboardingRepositoryImpl(Get.find()),
      fenix: true,
    );

    // Use cases
    Get.lazyPut(() => CheckServerStatus(Get.find()), fenix: true);
    Get.lazyPut(() => DetectHoax(Get.find()), fenix: true);
    Get.lazyPut(() => GetHistory(Get.find()), fenix: true);
    Get.lazyPut(() => SaveResult(Get.find()), fenix: true);
    Get.lazyPut(() => DeleteResult(Get.find()), fenix: true);
    Get.lazyPut(() => ClearHistory(Get.find()), fenix: true);
    Get.lazyPut(() => HasSeenOnboarding(Get.find()), fenix: true);
    Get.lazyPut(() => MarkOnboardingDone(Get.find()), fenix: true);
    Get.lazyPut(() => ResetOnboarding(Get.find()), fenix: true);
    Get.lazyPut(() => CheckOnboardingExpiry(Get.find()), fenix: true);
  }
}

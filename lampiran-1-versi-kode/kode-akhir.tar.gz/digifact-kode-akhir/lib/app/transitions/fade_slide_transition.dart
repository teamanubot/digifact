import 'package:flutter/material.dart';
import 'package:get/get.dart';

/// Transisi halaman: fade + geser tipis dari bawah.
class FadeSlideTransition extends CustomTransition {
  final double slideOffset;

  FadeSlideTransition({this.slideOffset = 0.04});

  @override
  Widget buildTransition(
    BuildContext context,
    Curve? curve,
    Alignment? alignment,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final curved = CurvedAnimation(parent: animation, curve: Curves.easeOut);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: Offset(0, slideOffset),
          end: Offset.zero,
        ).animate(curved),
        child: child,
      ),
    );
  }
}

import 'package:flutter/material.dart';

class AppColors {
  const AppColors._();

  // Backgrounds
  static const navy = Color(0xFF0A1F44);
  static const navyDeep = Color(0xFF050D1A);
  static const navyMid = Color(0xFF0D1B35);
  static const navyCard = Color(0xFF0F2347);
  static const navyElevated = Color(0xFF112851);

  // Neon Accents
  static const neonGreen = Color(0xFF33FF33);
  static const neonRed = Color(0xFFFF3333);
  static const neonCyan = Color(0xFF00D4FF);
  static const neonBlue = Color(0xFF2979FF);

  // Text
  static const textPrimary = Colors.white;
  static const textSecondary = Color(0xFF708090); // Slate Gray
  static const textMuted = Color(0xFF3D5475);

  // Borders
  static const borderSubtle = Color(0xFF1A3060);
  static const borderGlow = Color(0xFF243D6B);
}

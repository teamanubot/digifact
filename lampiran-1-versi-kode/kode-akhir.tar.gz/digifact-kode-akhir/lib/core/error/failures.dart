/// Kegagalan pada level domain. Dilempar oleh repository dan ditangkap oleh
/// controller untuk ditampilkan ke pengguna.
sealed class Failure implements Exception {
  final String message;
  const Failure(this.message);

  @override
  String toString() => message;
}

class ServerFailure extends Failure {
  const ServerFailure(super.message);
}

class NetworkFailure extends Failure {
  const NetworkFailure(super.message);
}

class TimeoutFailure extends Failure {
  const TimeoutFailure(super.message);
}

class CacheFailure extends Failure {
  const CacheFailure(super.message);
}

/// Input pengguna tidak memenuhi aturan bisnis (mis. kosong atau terlalu pendek).
class ValidationFailure extends Failure {
  const ValidationFailure(super.message);
}

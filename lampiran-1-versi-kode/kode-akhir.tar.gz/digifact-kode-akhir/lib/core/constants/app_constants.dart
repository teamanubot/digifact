class AppConstants {
  const AppConstants._();

  /// Jumlah maksimum riwayat deteksi yang disimpan di perangkat.
  static const int maxHistoryItems = 50;

  /// Panjang minimum teks/URL yang diterima untuk dideteksi (karakter).
  static const int minInputLength = 10;

  /// Jumlah riwayat terbaru yang ditampilkan di beranda.
  static const int recentHistoryCount = 3;

  /// Onboarding ditampilkan kembali jika aplikasi tidak dibuka selama N hari.
  static const int onboardingExpiryDays = 7;
}

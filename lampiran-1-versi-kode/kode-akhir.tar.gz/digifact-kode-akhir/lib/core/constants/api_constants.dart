class ApiConstants {
  const ApiConstants._();

  static const String baseUrl = 'https://api.rmun.tech';
  static const String detectPath = '/api/deteksi';

  static const Duration healthCheckTimeout = Duration(seconds: 4);
  static const Duration detectTimeout = Duration(seconds: 30);
}

class StorageKeys {
  const StorageKeys._();

  static const String history = 'digifact_history';
  static const String onboardingDone = 'digifact_onboarding_done';
  static const String lastOpened = 'digifact_last_opened';
}

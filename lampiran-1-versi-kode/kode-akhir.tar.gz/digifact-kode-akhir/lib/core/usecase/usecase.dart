/// Kontrak dasar use case: satu use case = satu aksi bisnis.
abstract class UseCase<Output, Params> {
  const UseCase();

  Output call(Params params);
}

/// Placeholder untuk use case tanpa parameter.
class NoParams {
  const NoParams();
}

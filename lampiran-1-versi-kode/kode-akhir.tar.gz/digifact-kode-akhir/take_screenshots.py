import subprocess
import time
import os

def run_command(cmd, shell=True):
    print(f"Executing: {cmd}")
    return subprocess.Popen(cmd, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def run_sync(cmd):
    print(f"Executing sync: {cmd}")
    subprocess.run(cmd, shell=True)

# Path penyimpanan screenshot
screenshot_dir = "/root/mat/digifact/screenshots_tablet_10"
# Hapus screenshot lama yang hitam polos
run_sync(f"rm -rf {screenshot_dir}/*.png")
os.makedirs(screenshot_dir, exist_ok=True)

# Setel variabel lingkungan
os.environ["DISPLAY"] = ":99"
os.environ["GDK_BACKEND"] = "x11"
os.environ["LIBGL_ALWAYS_SOFTWARE"] = "1"
os.environ["GBM_ALWAYS_SOFTWARE"] = "1"

# Bersihkan sisa proses
run_sync("killall -9 Xvfb openbox digifact 2>/dev/null || true")
run_sync("rm -f /tmp/.X*-lock")

print("Starting Xvfb on display :99 with resolution 1080x1920...")
xvfb_proc = run_command("Xvfb :99 -screen 0 1080x1920x24")
time.sleep(2)

print("Starting Openbox window manager...")
openbox_proc = run_command("openbox")
time.sleep(2)

print("Launching the Flutter Linux application in tablet mode...")
app_proc = run_command("/root/mat/digifact/build/linux/x64/debug/bundle/digifact --tablet-10")

# Menunggu window terbuat dan mengatur ukuran/posisi
print("Waiting for window to be created...")
win_id = None
for i in range(30):
    res = subprocess.run("xdotool search --class 'digifact'", shell=True, capture_output=True, text=True)
    out = res.stdout.strip()
    if out:
        win_id = out.split('\n')[0]
        print(f"Window found! ID: {win_id}")
        # Atur ukuran menjadi 1080x1920 dan pindahkan ke 0,0
        run_sync(f"xdotool windowsize {win_id} 1080 1920")
        run_sync(f"xdotool windowmove {win_id} 0 0")
        break
    time.sleep(0.5)

if not win_id:
    print("Error: Window not found after timeout!")
    app_proc.terminate()
    openbox_proc.terminate()
    xvfb_proc.terminate()
    exit(1)

# Beri waktu tambahan agar Flutter selesai merender frame pertama
time.sleep(4)

# 1. Ambil screenshot Splash Screen
print("Capturing Splash Screen...")
run_sync(f"scrot -z {screenshot_dir}/1_splash.png")
time.sleep(4) # Menunggu splash screen selesai dan transisi ke onboarding

# 2. Ambil screenshot Onboarding 1
print("Capturing Onboarding Page 1...")
run_sync(f"scrot -z {screenshot_dir}/2_onboarding1.png")

# Klik tombol Lanjutkan (di posisi bottom center, x=540, y=1850)
print("Navigating to Onboarding Page 2...")
run_sync("xdotool mousemove 540 1850 click 1")
time.sleep(1.5)

# 3. Ambil screenshot Onboarding 2
print("Capturing Onboarding Page 2...")
run_sync(f"scrot -z {screenshot_dir}/3_onboarding2.png")

# Klik tombol Lanjutkan
print("Navigating to Onboarding Page 3...")
run_sync("xdotool mousemove 540 1850 click 1")
time.sleep(1.5)

# 4. Ambil screenshot Onboarding 3
print("Capturing Onboarding Page 3...")
run_sync(f"scrot -z {screenshot_dir}/4_onboarding3.png")

# Klik tombol Mulai Menggunakan DigiFact
print("Navigating to Home Screen...")
run_sync("xdotool mousemove 540 1850 click 1")
time.sleep(3.5) # Tunggu transisi ke Home Screen

# 5. Ambil screenshot Home Screen
print("Capturing Home Screen...")
run_sync(f"scrot -z {screenshot_dir}/5_home.png")

# Klik kolom input berita (di posisi x=540, y=450)
print("Focusing input field...")
run_sync("xdotool mousemove 540 450 click 1")
time.sleep(0.5)

# Ketik teks berita hoax uji coba
print("Typing test news content...")
run_sync('xdotool type "Jokowi pergi ke pasar"')
time.sleep(1.0)

# Klik tombol "ANALISIS BERITA SEKARANG" (di posisi x=540, y=600)
print("Triggering analysis...")
run_sync("xdotool mousemove 540 600 click 1")
time.sleep(6.0) # Menunggu pemanggilan API dan transisi ke Result Screen

# 6. Ambil screenshot Result Screen
print("Capturing Result Screen...")
run_sync(f"scrot -z {screenshot_dir}/6_result.png")

# Kembali ke Home Screen dengan menekan tombol Escape
print("Returning to Home Screen...")
run_sync("xdotool key Escape")
time.sleep(1.5)

# Klik menu "Panduan Cek" (posisi kiri, x=270, y=720)
print("Opening Education Screen...")
run_sync("xdotool mousemove 270 720 click 1")
time.sleep(2.0)

# 7. Ambil screenshot Education Screen
print("Capturing Education Screen...")
run_sync(f"scrot -z {screenshot_dir}/7_education.png")

# Kembali ke Home Screen
print("Returning to Home Screen...")
run_sync("xdotool key Escape")
time.sleep(1.5)

# Klik menu "Riwayat Cek" (posisi kanan, x=810, y=720)
print("Opening History Screen...")
run_sync("xdotool mousemove 810 720 click 1")
time.sleep(2.0)

# 8. Ambil screenshot History Screen
print("Capturing History Screen...")
run_sync(f"scrot -z {screenshot_dir}/8_history.png")

# Menghentikan aplikasi, openbox, dan Xvfb
print("Cleaning up...")
app_proc.terminate()
openbox_proc.terminate()
xvfb_proc.terminate()
time.sleep(1)

print("Screenshots generation process completed successfully!")

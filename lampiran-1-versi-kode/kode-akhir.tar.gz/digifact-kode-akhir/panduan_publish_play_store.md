# Panduan Publikasi Aplikasi Digifact ke Google Play Store

Dokumen ini berisi panduan langkah-demi-langkah bagi Anda untuk mempublikasikan aplikasi **Digifact** ke Google Play Store, setelah seluruh proses konfigurasi teknis selesai dilakukan.

---

## 🛠️ Konfigurasi yang Telah Diterapkan

Kami telah melakukan persiapan teknis pada proyek Flutter Anda agar siap dirilis:

1. **Pengubahan Package Name**: Mengubah package name bawaan dari `com.example.digifact` menjadi yang unik dan profesional: **`com.teamanubot.digifact`** (Play Store tidak mengizinkan package name `com.example`).
2. **Pembuatan Signing Key (Keystore)**: Membuat berkas kunci penandatanganan rilis (`upload-keystore.jks`) di dalam folder `android/app/`.
3. **Konfigurasi Keamanan (`.gitignore`)**: Menambahkan konfigurasi keystore dan berkas sensitif `key.properties` ke `.gitignore` agar password Anda tidak bocor ke publik.
4. **Konfigurasi Build Gradle**: Menghubungkan `key.properties` dengan `android/app/build.gradle.kts` sehingga aplikasi Anda otomatis ditandatangani dengan kunci rilis setiap kali Anda menjalankan perintah build.

---

## 📦 1. Membuat Berkas Android App Bundle (.aab)

Google Play Store mewajibkan aplikasi baru diunggah dalam format **Android App Bundle (.aab)**, bukan lagi `.apk`. Format ini lebih optimal karena memperkecil ukuran unduhan di ponsel pengguna.

Perintah berikut digunakan untuk memicu proses build:

```bash
flutter build appbundle
```

Setelah build selesai, berkas rilis Anda akan berada di:
`build/app/outputs/bundle/release/app-release.aab`

---

## 💳 2. Mendaftar Akun Google Play Console

Sebelum dapat mengunggah aplikasi, Anda memerlukan akun developer Google:

1. Kunjungi [Google Play Console](https://play.google.com/console/signup).
2. Masuk menggunakan akun Google Anda.
3. Pilih tipe akun (**Developer Pribadi** atau **Organisasi/Bisnis**).
4. Selesaikan pembayaran biaya registrasi sekali seumur hidup sebesar **$25 USD** menggunakan kartu kredit/debit online.
5. Lakukan verifikasi identitas (menggunakan KTP/SIM/Paspor) sesuai instruksi Google. Proses verifikasi biasanya memakan waktu 1-3 hari kerja.

---

## 🚀 3. Langkah-Langkah Mengunggah Aplikasi di Play Console

Setelah akun aktif dan terverifikasi, ikuti langkah berikut untuk mempublikasikan aplikasi Anda:

### Langkah A: Membuat Aplikasi Baru

1. Di halaman utama Play Console, klik tombol **Create app** (Buat aplikasi) di kanan atas.
2. Isi informasi dasar:
   * **App name**: `Digifact` (atau nama publik yang Anda inginkan).
   * **Default language**: Bahasa default aplikasi (misal: Indonesia).
   * **App or game**: Pilih **App** (Aplikasi).
   * **Free or paid**: Pilih **Free** (Gratis) atau **Paid** (Berbayar).
   * Setujui ketentuan layanan lalu klik **Create app**.

### Langkah B: Menyelesaikan Setup Aplikasi (Set Up Your App)

Di dasbor aplikasi Anda, gulir ke bawah ke bagian **Set up your app** dan klik **View tasks**. Anda harus menyelesaikan seluruh tugas berikut sebelum bisa merilis:

1. **Privacy Policy**: Sediakan URL Kebijakan Privasi aplikasi Anda. (Anda bisa membuat dokumen Kebijakan Privasi sederhana gratis secara online).
2. **App Access**: Pilih opsi apakah semua bagian aplikasi dapat diakses tanpa kredensial khusus, atau memerlukan login.
3. **Ads**: Nyatakan apakah aplikasi mengandung iklan atau tidak.
4. **Content Rating**: Isi kuesioner singkat mengenai konten aplikasi Anda untuk menentukan batas umur pengguna.
5. **Target Audience**: Tentukan rentang umur pengguna aplikasi Anda (misal: 13 tahun ke atas, atau dewasa).
6. **News Apps**: Nyatakan apakah aplikasi Anda adalah aplikasi berita atau bukan (Pilih: *No*).
7. **Data Safety**: Isi deklarasi tentang data pengguna apa saja yang dikumpulkan dan dibagikan oleh aplikasi Anda (misalnya: data lokasi, informasi pribadi, dll).
8. **Government Apps**: Nyatakan apakah aplikasi Anda merupakan perwakilan instansi pemerintah atau bukan (Pilih: *No*).

### Langkah C: Menyiapkan Halaman Toko (Store Listing)

Di menu kiri, pilih **Grow** > **Store presence** > **Main store listing**. Unggah aset promosi berikut:

* **Short description**: Deskripsi singkat aplikasi (maksimal 80 karakter).
* **Full description**: Deskripsi lengkap fitur dan keunggulan aplikasi Anda (maksimal 4000 karakter).
* **App Icon**: Gambar logo aplikasi berukuran **512x512 piksel** bertipe PNG. (Kami melihat Anda memiliki `app_icon.png` di proyek Anda).
* **Feature Graphic**: Banner promosi berukuran **1024x500 piksel** bertipe JPG atau PNG.
* **Screenshots**: Unggah minimal 2 hingga 8 tangkapan layar aplikasi untuk ponsel (dan tablet jika didukung).

### Langkah D: Membuat Rilis Rantai Produksi (Production Release)

Setelah store listing siap, buat rilis untuk dipublikasikan ke publik:

1. Di menu kiri, pilih **Release** > **Production**.
2. Klik **Create new release** di kanan atas.
3. Pada opsi **Play App Signing**, klik **Choose signing key** dan pilih **Use Google-managed key** (sangat disarankan oleh Google).
4. Pada bagian **App bundles**, unggah berkas `.aab` yang telah Anda build sebelumnya:
   `build/app/outputs/bundle/release/app-release.aab`
5. Isi **Release name** (misal: `1.0.0`) dan **Release notes** (catatan perubahan, misalnya: `Rilis perdana aplikasi Digifact`).
6. Klik **Save** lalu klik **Review release**.
7. Klik **Start rollout to Production** untuk mengirimkan aplikasi Anda ke tim Google Play untuk ditinjau.

---

## ⏳ 4. Proses Peninjauan (Review)

* Peninjauan pertama aplikasi baru oleh Google biasanya memerlukan waktu **3 hingga 7 hari kerja** (terkadang bisa lebih cepat).
* Anda dapat memantau status peninjauan di halaman utama Google Play Console. Statusnya akan berubah dari **Under review** menjadi **Published** atau **Live on Google Play** jika disetujui.

> [!IMPORTANT]
> Pastikan data yang dimasukkan saat mengisi kuesioner Data Safety dan Content Rating akurat agar aplikasi Anda terhindar dari penolakan (rejection) saat proses peninjauan.

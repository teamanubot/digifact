# Dokumentasi Arsitektur DigiFact (Clean Architecture + GetX)

Dokumen ini merangkum keputusan arsitektur, bukti pengujian, studi kasus perubahan, dan pengukuran
sebelum/sesudah refactor. Semua angka dapat direproduksi (lihat bagian *Reproduksi*).

## 1. Masalah pada kode awal

Kode awal terdiri dari 10 file. Seluruh logika ada di `State` widget:

| Gejala | Bukti terukur (kode lama) |
|---|---|
| UI bergantung pada implementasi konkret | 5 dari 6 file UI mengimpor `ApiService`/`StorageService` langsung |
| Service di-*thread* lewat konstruktor antar screen | 8 parameter service di konstruktor screen |
| Logika bisnis/IO bercampur dengan UI | 23 pemanggilan `widget.apiService` / `widget.storageService` dari `State` |
| Token desain tersimpan di screen | `AppColors` dan `AppRadius` didefinisikan di `home_screen.dart` dan di-import screen lain |
| Tidak bisa diuji | Satu-satunya test berisi `expect(true, true)` |
| Screen sangat besar | `result_screen.dart` 1.185 baris, `home_screen.dart` 1.086 baris; 4 file di atas 500 baris, 6 di atas 300 |

## 2. Arsitektur target

```
presentation  ──►  domain  ◄──  data
     │                │           │
     └────────────────┴───────────┴──►  core   (tanpa ketergantungan ke layer lain)
```

| Layer | Isi | Boleh bergantung pada |
|---|---|---|
| `domain` | Entity, `Verdict`, kontrak repository, use case | Dart murni + `core` |
| `data` | Model (fromJson/toJson), data source (HTTP, SharedPreferences, file), implementasi repository | `domain`, `core` |
| `presentation` | Controller GetX, binding, halaman, widget | `domain`, `core`, `app` |
| `app` | Tema, routing, DI global | semua (composition root) |
| `core` | Konstanta, `Failure`/`Exception`, kontrak `UseCase` | tidak ada |

### Alur satu permintaan (deteksi berita)

```mermaid
sequenceDiagram
    participant UI as HomeScreen
    participant C as HomeController
    participant UC as DetectHoax (use case)
    participant R as DetectionRepositoryImpl
    participant DS as RemoteDataSource
    participant API as FastAPI

    UI->>C: detect()
    C->>UC: call(teks)
    Note over UC: validasi: tidak kosong, >= 10 karakter
    UC->>R: detectHoax(teks.trim())
    R->>DS: detectHoax(teks)
    DS->>API: POST /api/deteksi
    API-->>DS: JSON
    DS-->>R: DetectionResultModel
    R-->>UC: DetectionResult (entity)
    UC-->>C: DetectionResult
    C->>C: SaveResult, perbarui state Rx
    C-->>UI: Obx rebuild + navigasi ke Result
```

Kegagalan mengikuti jalur sebaliknya sebagai `Failure` bertipe
(`ValidationFailure`, `NetworkFailure`, `TimeoutFailure`, `ServerFailure`). Data source melempar
`Exception` teknis, repository memetakannya menjadi `Failure` domain, controller menampilkan pesannya.

### Peran komponen GetX

| Komponen GetX | Peran di proyek | Lokasi |
|---|---|---|
| `GetxController` | State reaktif (`Rx`) + orkestrasi use case | `presentation/controllers` |
| `Obx` | Rebuild UI sebagian saat state berubah | `presentation/pages` |
| `Bindings` | DI per halaman (`lazyPut` controller); controller dibuang saat halaman keluar | `presentation/bindings` |
| `InitialBinding` | DI global: data source → repository → use case (`fenix: true`) | `app/bindings` |
| `GetPage` + named route | Navigasi terpusat, transisi kustom | `app/routes` |

Controller menerima use case lewat **konstruktor** (bukan memanggil `Get.find` di dalam logika),
sehingga dapat diuji dengan dependensi palsu. `Get.find` hanya muncul di *composition root*
(binding) dan saat View mengambil controller-nya.

## 3. Aturan bisnis di domain

Aturan berikut sebelumnya tersebar di UI dan data source. Sekarang berada di use case sehingga dapat
diuji tanpa Flutter:

| Use case | Aturan |
|---|---|
| `DetectHoax` | Input di-`trim`; kosong atau kurang dari 10 karakter ditolak (`ValidationFailure`) sebelum menyentuh jaringan |
| `SaveResult` | Id sama menimpa data lama; hasil terbaru di urutan pertama; riwayat dibatasi 50 item |
| `DeleteResult` | Hanya menghapus id yang dimaksud |
| `GetHistory` | Diurutkan dari tanggal terbaru |
| `Verdict` / `DetectionResult.confidence` | Pemetaan label API ke enum; label tak dikenal menjadi `netral`; keyakinan hasil netral = 0,5 |

Pemetaan verdict ke tampilan (warna, ikon, label) berada di satu tempat, `VerdictStyle`, dan dipakai
halaman hasil, riwayat, dan beranda.

## 4. Dekomposisi UI

Logika sudah keluar dari UI (bagian 3), tetapi file layar masih sangat besar. Layar kemudian dipecah
menjadi widget kecil: tiap bagian (kartu, header, daftar, painter) menjadi kelas widget sendiri
dengan parameter eksplisit, sedangkan `Screen` hanya merakitnya.

| Layar | Kode awal | Setelah GetX, sebelum pemecahan | Sesudah pemecahan |
|---|---|---|---|
| `result_screen.dart` | 1.185 | 1.115 | 148 |
| `home_screen.dart` | 1.086 | 853 | 88 |
| `onboarding_screen.dart` | 738 | 708 | 142 |
| `splash_screen.dart` | 576 | 549 | 205 |
| `history_screen.dart` | 470 | 416 | 59 |
| `education_screen.dart` | 405 | 407 | 104 |

*(Baris non-kosong. Kolom ke-2 menunjukkan bahwa memindahkan logika ke controller saja belum
membuat layar kecil; pemecahan menjadi widget yang melakukannya.)*

Sesudah pemecahan, tidak ada satu pun file di `lib/` yang melebihi 300 baris (terbesar 259 baris).

**Bukti bahwa pemecahan tidak mengubah tampilan: golden test.** Sebelum satu baris pun diubah, render
10 keadaan layar ditangkap sebagai gambar acuan (splash, onboarding, beranda kosong dan berisi,
hasil Hoaks/Fakta/Netral, riwayat kosong dan berisi, edukasi). Setelah pemecahan, seluruhnya tetap
identik piksel demi piksel. Golden test dijalankan dengan font DM Sans yang dibundel sebagai asset
(bukan diunduh), sehingga render deterministik dan aplikasi juga tampil benar saat offline.

## 5. Pengujian

**110 test dalam 18 file**, seluruhnya lulus (`flutter test`; terakhir dijalankan 28 Oktober 2026). Layanan API memiliki 27 test terpisah (`hoax-detector-api/tests`, `python3 -m pytest tests`).

| Tingkat | Berkas | Yang dibuktikan |
|---|---|---|
| Domain | `test/domain` | Aturan bisnis use case dengan repository palsu |
| Data | `test/data` | Parsing model, round-trip penyimpanan, pemetaan `Exception → Failure`, data korup tidak membuat crash, **contract test** data source |
| Controller | `test/presentation/controllers` | 22 test yang memanggil method controller langsung: state Rx, alur sukses/gagal/validasi, gagal simpan riwayat (hasil tetap tampil), anti panggilan ganda, navigasi |
| Alur UI | `test/presentation` | Splash → Onboarding/Home, deteksi, halaman hasil, bookmark, riwayat, dengan binding dan route asli |
| Golden | `test/golden` | 14 keadaan layar: 10 acuan awal identik piksel sebelum dan sesudah refactor UI, ditambah slide onboarding 2 dan 3 serta tab SHAP dan LIME pada layar hasil |
| Arsitektur | `test/architecture` | Aturan dependensi antar-layer ditegakkan otomatis |
| Perbandingan | `test/comparison` | Fitur yang sama dengan tiga pendekatan state management |

**Architecture test** memindai seluruh `import` di `lib/` dan gagal bila: domain memakai
Flutter/GetX/http/storage atau mengimpor layer lain; data mengimpor presentation; `core` mengimpor
layer lain; presentation mengimpor data langsung; controller mengimpor repository; domain/data memakai
`Get.find`; sebuah use case tidak tunggal atau tidak mewarisi `UseCase`.

*Validasi test itu sendiri:* pelanggaran sengaja disisipkan (Flutter di domain, data layer di
controller, presentation di data), dan ketiganya terdeteksi. Pada uji pertama, pelanggaran antar-layer
**tidak** terdeteksi karena bug resolusi path relatif di test; bug itu diperbaiki lalu pelanggaran
terdeteksi. Test yang tidak pernah gagal tidak membuktikan apa pun, jadi validasi ini penting.

**Cakupan kode** (`flutter test --coverage`):

| Layer | Cakupan |
|---|---|
| domain | 96,3% |
| presentation/controllers | 94,9% |
| data | 76,1% |
| app | 93,8% |
| core | 52,2% |
| presentation/pages + widgets + bindings | 97,7% |
| **Total** | **95,9%** |

> Cakupan pages tinggi karena widget dan golden test merender halaman secara utuh; itu menunjukkan
> kode dieksekusi, bukan bahwa semua tampilan divalidasi. Cakupan domain dan controller adalah angka
> yang paling bermakna untuk argumen testability. Cakupan `core` rendah karena berisi definisi tipe
> `Failure`/`Exception` yang tidak semuanya dipicu skenario uji.

### Bug yang ditemukan oleh pengujian dan eksekusi nyata

Bagian ini penting karena menunjukkan pengujian benar-benar berfungsi, bukan hanya angka cakupan.

| Temuan | Ditemukan oleh | Penyebab | Perbaikan |
|---|---|---|---|
| `isLoading` tetap `true` selama pengguna melihat halaman hasil | Test controller | **Regresi yang diperkenalkan refactor sendiri**: `detect()` meng-`await` navigasi sehingga `finally` baru jalan setelah halaman hasil ditutup. Kode asli tidak menunggu | `isLoading` dimatikan sebelum berpindah halaman |
| Menyisipkan `DetectionResult` biasa ke riwayat melempar error tipe saat runtime | Contract test data source | `getHistory()` mengembalikan `List<DetectionResultModel>` yang hanya di-*upcast*; tidak terlihat di aplikasi karena semua hasil berasal dari model | Salin ke `List<DetectionResult>` bertipe benar |
| Teks analisis menampilkan `**tebal**` mentah di layar | Screenshot aplikasi asli | Backend mengirim penanda markdown tebal, UI menampilkannya sebagai teks biasa. Tidak mungkin ketahuan dari widget test | `BoldText` merender penanda menjadi huruf tebal, dengan unit test |
| Kegagalan menyimpan riwayat menyembunyikan vonis yang sudah berhasil | Tinjauan kode saat menulis tabel kegagalan | `HomeController.detect` menyimpan hasil di blok `try` yang sama dengan deteksi, dan `CacheFailure` tidak pernah dilempar | Penyimpanan dipisah; kegagalan dipetakan ke `CacheFailure`, hasil tetap tampil dengan pesan gagal simpan, diuji pengendali dan repositori |
| Kutipan dan ikon pada gambar acuan golden tergambar sebagai kotak putih dan banner debug ikut tampil | Pemeriksaan visual gambar acuan | Font ikon dan varian italic font teks belum termuat saat gambar diambil; banner debug aktif di lingkungan uji | Font dimuat sebelum pengambilan gambar, banner dimatikan, seluruh acuan dibuat ulang |
| Cek antar-layer di architecture test tidak pernah gagal | Validasi mutasi | Path relatif tidak di-resolve ke absolut | Diperbaiki, lalu divalidasi ulang dengan pelanggaran sengaja |

## 6. Studi kasus perubahan: mengganti penyimpanan riwayat

Klaim utama Clean Architecture adalah perubahan terisolasi. Untuk mengujinya, penyimpanan riwayat
diganti dari SharedPreferences ke berkas JSON (`FileHistoryLocalDataSource`).

| Yang berubah | Jumlah |
|---|---|
| Berkas baru (implementasi kontrak `HistoryLocalDataSource`) | 1 |
| Baris di `InitialBinding` untuk memasangnya | 1 |
| Berkas di `domain/` yang berubah | **0** |
| Berkas di `presentation/` yang berubah | **0** |

Pemasangan pada `InitialBinding` (contoh, tidak diaktifkan secara default):

```dart
// sebelum
Get.lazyPut<HistoryLocalDataSource>(() => HistoryLocalDataSourceImpl(Get.find()), fenix: true);
// sesudah
Get.lazyPut<HistoryLocalDataSource>(() => FileHistoryLocalDataSource(File(path)), fenix: true);
```

**Bukti: contract test.** `test/data/history_data_source_contract_test.dart` menjalankan rangkaian uji
yang sama, melalui repository dan use case asli, terhadap **kedua** implementasi: baca-tulis utuh
termasuk penjelasan XAI, aturan `SaveResult` (terbaru dulu, id sama menimpa), batas 50 item, hapus satu
dan hapus semua. Keduanya lulus, dan aturan bisnis berlaku identik karena berada di use case, bukan di
data source.

Skenario perubahan lain, dan dampaknya:

| Perubahan | Berkas yang perlu diubah |
|---|---|
| Ganti alamat server API | 1 konstanta (`ApiConstants.baseUrl`) |
| Ganti batas riwayat 50 → 100 | 1 konstanta (`AppConstants.maxHistoryItems`), diuji oleh use case |
| Ganti state management | Hanya `presentation`; domain tidak berubah (lihat bagian 7) |

Catatan jujur: `FileHistoryLocalDataSource` menerima objek `File`; penggunaan nyata di perangkat seluler
memerlukan penentuan direktori dokumen (mis. paket `path_provider`) yang tidak ditambahkan di sini.

## 7. Perbandingan state management (empiris)

Fitur yang sama (riwayat: muat, hapus satu, hapus semua) diimplementasikan dengan tiga pendekatan,
seluruhnya memakai **use case domain yang sama tanpa modifikasi**. Skenario uji identik dijalankan
terhadap ketiganya (`test/comparison`) dan seluruhnya lulus.

| Pendekatan | Baris logika | Kelas | Catatan |
|---|---|---|---|
| GetX (`GetxController` + `.obs`) | 16 | 1 | Tanpa kelas state terpisah |
| Cubit (paket `bloc`) | 20 | 2 | Butuh kelas state immutable |
| ChangeNotifier (dasar Provider) | 19 | 1 | `notifyListeners()` manual |

Hasilnya: untuk fitur sekecil ini perbedaan ukuran kode kecil (16–20 baris). Temuan yang lebih
bermakna adalah bahwa **domain independen dari state management**: pendekatan bisa diganti tanpa
menyentuh use case atau aturan bisnis.

Perbandingan kualitatif (tidak ada klaim performa yang diukur di proyek ini):

| Aspek | GetX (dipakai) | Provider / Riverpod | BLoC |
|---|---|---|---|
| Boilerplate | Rendah | Rendah–sedang | Tinggi (event/state) |
| DI + routing + state dalam satu paket | Ya | Tidak | Tidak |
| Kemudahan DI implisit | `Get.find` global (service locator) | Terikat pohon widget / provider graph | Terikat pohon widget |
| Risiko utama | Service locator dan state global mudah disalahgunakan; ketergantungan pada satu paket serba-ada | Kurva belajar (Riverpod) | Verbose untuk fitur sederhana |
| Keterlacakan perubahan state | Sedang | Sedang–tinggi | Tinggi (event eksplisit) |

Mitigasi risiko GetX di proyek ini: DI lewat konstruktor, `Get.find` dibatasi di composition root,
dan *architecture test* mencegah `Get.*` merembes ke domain dan data.

## 8. Hasil pengukuran sebelum vs sesudah

| Metrik | Sebelum | Sesudah |
|---|---|---|
| Jumlah file Dart di `lib/` | 10 | 104 |
| Total baris (non-kosong) | 4.784 | 6.026 (+26%) |
| Rata-rata baris per file | 478 | 57 |
| File terbesar | 1.185 baris | 259 baris |
| File > 500 baris | 4 | **0** |
| File > 300 baris | 6 | **0** |
| File UI yang mengimpor service/data konkret | 5 dari 6 | **0** (ditegakkan test) |
| Pemanggilan service langsung dari `State` widget | 23 | **0** |
| Aturan bisnis yang dapat diuji tanpa Flutter | 0 | 5 use case + entity |
| Jumlah test bermakna | 0 | 110 (aplikasi) dan 27 (layanan) |
| Cakupan kode total | tidak ada | 95,9% |

**Pembacaan jujur:** arsitektur ini menambah jumlah file dan total baris (kode *boilerplate*:
kontrak repository, use case, model/entity terpisah, kelas widget). Manfaatnya adalah keterpisahan
tanggung jawab, kemampuan diuji, perubahan yang terisolasi, dan aturan dependensi yang dapat
ditegakkan secara otomatis, bukan kode yang lebih sedikit.

## 9. Tangkapan layar aplikasi berjalan

Diambil dari aplikasi Linux hasil `flutter build linux` yang berjalan sungguhan (jendela 1080×1920
dalam layar virtual), memanggil API produksi, sehingga layar hasil berisi prediksi model yang
sebenarnya. Berkas ada di `docs/screenshots/`, dibuat oleh `tool/take_screenshots.py`.

| # | Berkas | Isi |
|---|---|---|
| 1 | `1_splash.png` | Splash |
| 2–4 | `2_onboarding_1.png` … `4_onboarding_3.png` | Tiga slide onboarding |
| 5 | `5_beranda.png` | Beranda |
| 6 | `6_beranda_input.png` | Beranda dengan teks uji |
| 7 | `7_hasil_atas.png` | Hasil: vonis, gauge, analisis, kata kunci SHAP |
| 8 | `8_hasil_lime.png` | Hasil: tab kata kunci LIME |
| 9 | `9_edukasi.png` | Panduan literasi digital |
| 10 | `10_riwayat.png` | Riwayat berisi hasil yang baru disimpan |

> Perangkat yang dipakai adalah Linux desktop dengan jendela berukuran tablet, bukan perangkat
> Android/iOS fisik. Haptic feedback dan perilaku khusus platform seluler tidak teramati.

## 10. Keterbatasan

1. **Sebagian use case tipis** (meneruskan panggilan ke repository), karena logika bisnis berat
   berada di backend ML, bukan di klien.
2. **`AnimationController` tetap di `State` widget.** Itu keputusan sadar (murni urusan tampilan),
   sehingga tidak semua state halaman ada di controller.
3. **Belum diuji di perangkat seluler fisik.** Pengujian melalui widget/golden test dan aplikasi
   Linux desktop.
4. **Gambar acuan golden dibuat ulang pada 28 Oktober 2026** (font dan ikon dimuat, banner debug dimatikan, empat acuan ditambahkan); bukti identik sebelum-sesudah refactor berasal dari sepuluh acuan awal yang dijalankan sebelum perbaikan itu. **Golden test bergantung platform** (dibuat dan dijalankan di Linux); perubahan tampilan yang
   disengaja memerlukan `flutter test test/golden --update-goldens`.
5. **Ketergantungan pada satu paket serba-ada (GetX)** untuk state, DI, dan routing.
6. **`FileHistoryLocalDataSource` belum dipasang secara default** dan belum menentukan direktori
   penyimpanan nyata di perangkat seluler.
7. **Layar edukasi memuat statistik tanpa sumber** ("60% konten media sosial adalah hoaks",
   "hoaks menyebar 6× lebih cepat") dan sebuah kutipan tanpa rujukan. Untuk keperluan skripsi
   sebaiknya diberi sumber atau dihapus.
8. **Cakupan layer `core` rendah (52,2%)** karena definisi tipe tidak semuanya dipicu skenario uji.

## Reproduksi

```bash
export PATH=/root/flutter/bin:$PATH    # Flutter untuk Linux/WSL
flutter pub get
flutter analyze
flutter test                           # 110 test
flutter test --coverage                # menghasilkan coverage/lcov.info
flutter test test/golden --update-goldens   # hanya jika tampilan sengaja diubah

python3 tool/compare_state_management.py    # ukuran kode tiga pendekatan

flutter build linux --debug
python3 tool/take_screenshots.py            # menulis docs/screenshots/*.png
```

Kode versi sebelum refactor ada di `digifact.zip` (root proyek) untuk pembandingan.

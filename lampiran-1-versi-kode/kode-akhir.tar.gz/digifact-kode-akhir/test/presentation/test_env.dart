import 'package:digifact/app/routes/app_pages.dart';
import 'package:digifact/domain/usecases/check_onboarding_expiry.dart';
import 'package:digifact/domain/usecases/check_server_status.dart';
import 'package:digifact/domain/usecases/clear_history.dart';
import 'package:digifact/domain/usecases/delete_result.dart';
import 'package:digifact/domain/usecases/detect_hoax.dart';
import 'package:digifact/domain/usecases/get_history.dart';
import 'package:digifact/domain/usecases/has_seen_onboarding.dart';
import 'package:digifact/domain/usecases/mark_onboarding_done.dart';
import 'package:digifact/domain/usecases/reset_onboarding.dart';
import 'package:digifact/domain/usecases/save_result.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../helpers/fakes.dart';

/// Lingkungan uji: repository palsu + use case asli + routing/binding asli aplikasi.
/// Hanya lapisan data yang diganti, sehingga controller, binding, route, dan
/// UI diuji dengan konfigurasi yang sama seperti di produksi.
class TestEnv {
  final detection = FakeDetectionRepository();
  final history = FakeHistoryRepository();
  final onboarding = FakeOnboardingRepository(done: true);

  void register() {
    Get.put(CheckServerStatus(detection));
    Get.put(DetectHoax(detection));
    Get.put(GetHistory(history));
    Get.put(SaveResult(history));
    Get.put(DeleteResult(history));
    Get.put(ClearHistory(history));
    Get.put(HasSeenOnboarding(onboarding));
    Get.put(MarkOnboardingDone(onboarding));
    Get.put(ResetOnboarding(onboarding));
    Get.put(CheckOnboardingExpiry(onboarding));
  }

  Future<void> pumpApp(WidgetTester tester, String route) async {
    // Font dibundel sebagai asset; larang unduhan agar test deterministik dan offline.
    GoogleFonts.config.allowRuntimeFetching = false;
    register();
    tester.view.physicalSize = const Size(2400, 3200);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      GetMaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: route,
        getPages: AppPages.pages,
      ),
    );
    await tester.pump(const Duration(milliseconds: 200));
  }
}

/// Animasi berulang (repeat) membuat pumpAndSettle tidak pernah selesai,
/// jadi maju dalam langkah waktu tetap.
Future<void> pumpFor(WidgetTester tester, Duration total) async {
  const step = Duration(milliseconds: 100);
  for (var t = Duration.zero; t < total; t += step) {
    await tester.pump(step);
  }
}

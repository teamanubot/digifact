import 'package:digifact/app/routes/app_routes.dart';
import 'package:digifact/presentation/controllers/history_controller.dart';
import 'package:digifact/presentation/controllers/result_controller.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import '../../helpers/fakes.dart';
import '../test_env.dart';

void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  Future<HistoryController> start(WidgetTester tester) async {
    await env.pumpApp(tester, Routes.history);
    await pumpFor(tester, const Duration(milliseconds: 600));
    return Get.find<HistoryController>();
  }

  testWidgets('memuat riwayat terurut terbaru lebih dulu', (tester) async {
    env.history.stored = [
      makeResult(id: 'lama', at: DateTime(2025, 1, 1)),
      makeResult(id: 'baru', at: DateTime(2026, 1, 1)),
    ];
    final c = await start(tester);

    expect(c.history.map((e) => e.id), ['baru', 'lama']);
  });

  testWidgets('deleteItem menghapus satu item dari state dan penyimpanan', (tester) async {
    env.history.stored = [makeResult(id: 'a'), makeResult(id: 'b')];
    final c = await start(tester);

    await c.deleteItem('a');

    expect(c.history.map((e) => e.id), ['b']);
    expect(env.history.stored.map((e) => e.id), ['b']);
  });

  testWidgets('clearAll mengosongkan state dan penyimpanan', (tester) async {
    env.history.stored = [makeResult(id: 'a'), makeResult(id: 'b')];
    final c = await start(tester);

    await c.clearAll();

    expect(c.history, isEmpty);
    expect(env.history.stored, isEmpty);
  });

  testWidgets('openResult membuka halaman hasil dengan status tersimpan', (tester) async {
    final item = makeResult(id: 'a');
    env.history.stored = [item];
    final c = await start(tester);

    c.openResult(item);
    await pumpFor(tester, const Duration(milliseconds: 1600));

    expect(Get.currentRoute, Routes.result);
    expect(Get.find<ResultController>().isSaved.value, isTrue);
    expect(Get.find<ResultController>().result.id, 'a');
  });

  testWidgets('riwayat dimuat ulang setelah kembali dari halaman hasil', (tester) async {
    final item = makeResult(id: 'a');
    env.history.stored = [item];
    final c = await start(tester);

    c.openResult(item);
    await pumpFor(tester, const Duration(milliseconds: 1600));
    await Get.find<ResultController>().toggleSave(); // hapus dari riwayat di halaman hasil
    Get.back();
    await pumpFor(tester, const Duration(milliseconds: 800));

    expect(c.history, isEmpty, reason: 'state harus disegarkan setelah kembali');
  });
}

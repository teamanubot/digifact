import 'package:digifact/app/routes/app_routes.dart';
import 'package:digifact/core/error/failures.dart';
import 'package:digifact/presentation/controllers/home_controller.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import '../../helpers/fakes.dart';
import '../test_env.dart';

/// Menguji HomeController secara langsung (memanggil method-nya), bukan lewat tap UI.
void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  const valid = 'Bantuan tunai gratis untuk semua warga klik tautan ini';

  Future<HomeController> start(WidgetTester tester) async {
    await env.pumpApp(tester, Routes.home);
    await pumpFor(tester, const Duration(milliseconds: 200));
    return Get.find<HomeController>();
  }

  testWidgets('keadaan awal: tidak loading, tidak ada input', (tester) async {
    final c = await start(tester);

    expect(c.isLoading.value, isFalse);
    expect(c.hasInput.value, isFalse);
    expect(c.recentHistory, isEmpty);
  });

  testWidgets('checkServer mengikuti status repository', (tester) async {
    env.detection.serverActive = false;
    final c = await start(tester);
    expect(c.isServerActive.value, isFalse);

    env.detection.serverActive = true;
    await c.checkServer();
    expect(c.isServerActive.value, isTrue);
  });

  testWidgets('hasInput bereaksi terhadap isi teks dan clearInput', (tester) async {
    final c = await start(tester);

    c.textController.text = 'abc';
    expect(c.hasInput.value, isTrue);

    c.clearInput();
    expect(c.hasInput.value, isFalse);
    expect(c.textController.text, isEmpty);
  });

  testWidgets('detect sukses: loading true saat berjalan, false setelahnya, riwayat tersimpan',
      (tester) async {
    env.detection.result = makeResult(id: 'ok');
    final c = await start(tester);
    c.textController.text = valid;

    // Tidak di-await: detect() selesai setelah halaman hasil ditutup.
    c.detect();
    expect(c.isLoading.value, isTrue, reason: 'loading harus aktif selama proses');
    await pumpFor(tester, const Duration(milliseconds: 1600));

    expect(Get.currentRoute, Routes.result);
    expect(c.isLoading.value, isFalse,
        reason: 'loading harus berhenti begitu halaman hasil terbuka');
    expect(env.history.stored.map((e) => e.id), ['ok']);
    expect(c.recentHistory.map((e) => e.id), ['ok']);
  });

  testWidgets('gagal menyimpan riwayat: hasil tetap tampil dan tidak tersimpan', (tester) async {
    env.detection.result = makeResult(id: 'tetap');
    env.history.saveFailure = const CacheFailure('Riwayat tidak dapat disimpan di perangkat.');
    final c = await start(tester);
    c.textController.text = valid;

    c.detect();
    await pumpFor(tester, const Duration(milliseconds: 1600));

    expect(Get.currentRoute, Routes.result, reason: 'vonis tidak boleh disembunyikan');
    expect(env.history.stored, isEmpty);
    expect(c.isLoading.value, isFalse);
  });

  testWidgets('detect saat sedang loading diabaikan (tidak ada panggilan ganda)',
      (tester) async {
    final c = await start(tester);
    c.textController.text = valid;

    c.detect();
    await c.detect(); // ditolak karena isLoading
    await pumpFor(tester, const Duration(milliseconds: 1600));

    expect(env.detection.calls, hasLength(1));
  });

  testWidgets('input tidak valid: ValidationFailure, server tidak dipanggil', (tester) async {
    final c = await start(tester);
    c.textController.text = 'pendek';

    await c.detect();
    await pumpFor(tester, const Duration(milliseconds: 300));

    expect(env.detection.calls, isEmpty);
    expect(env.history.stored, isEmpty);
    expect(c.isLoading.value, isFalse);
    expect(Get.currentRoute, Routes.home);
  });

  testWidgets('kegagalan jaringan: riwayat tidak berubah dan loading berhenti',
      (tester) async {
    env.detection.failure = const NetworkFailure('offline');
    final c = await start(tester);
    c.textController.text = valid;

    await c.detect();
    await pumpFor(tester, const Duration(milliseconds: 300));

    expect(env.history.stored, isEmpty);
    expect(c.isLoading.value, isFalse);
    expect(find.text('offline'), findsOneWidget, reason: 'pesan Failure ditampilkan di dialog');
  });

  testWidgets('loadRecentHistory hanya mengambil 3 terbaru', (tester) async {
    for (var i = 0; i < 6; i++) {
      env.history.stored.add(makeResult(id: '$i', at: DateTime(2026, 1, 1 + i)));
    }
    final c = await start(tester);

    expect(c.recentHistory.map((e) => e.id), ['5', '4', '3']);
  });

  testWidgets('resetOnboarding memanggil use case', (tester) async {
    final c = await start(tester);

    await c.resetOnboarding();

    expect(env.onboarding.resetCalls, 1);
  });
}

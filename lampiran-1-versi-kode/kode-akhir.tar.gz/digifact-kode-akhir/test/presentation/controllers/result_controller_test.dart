import 'package:digifact/app/routes/app_routes.dart';
import 'package:digifact/app/routes/route_arguments.dart';
import 'package:digifact/presentation/controllers/result_controller.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import '../../helpers/fakes.dart';
import '../test_env.dart';

void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  Future<ResultController> open(
    WidgetTester tester, {
    required bool isSaved,
    String label = 'Hoaks',
    double fakta = 0.1,
    double hoaks = 0.9,
  }) async {
    final result = makeResult(id: 'r', label: label, fakta: fakta, hoaks: hoaks);
    if (isSaved) env.history.stored = [result];
    await env.pumpApp(tester, Routes.home);
    Get.toNamed(Routes.result, arguments: ResultArguments(result: result, isSaved: isSaved));
    await pumpFor(tester, const Duration(milliseconds: 1600));
    return Get.find<ResultController>();
  }

  testWidgets('state awal mengikuti argumen route', (tester) async {
    final c = await open(tester, isSaved: true);

    expect(c.result.id, 'r');
    expect(c.isSaved.value, isTrue);
  });

  testWidgets('toggleSave: simpan lalu hapus, konsisten dengan penyimpanan', (tester) async {
    final c = await open(tester, isSaved: false);
    expect(env.history.stored, isEmpty);

    await c.toggleSave();
    expect(c.isSaved.value, isTrue);
    expect(env.history.stored.map((e) => e.id), ['r']);

    await c.toggleSave();
    expect(c.isSaved.value, isFalse);
    expect(env.history.stored, isEmpty);
  });

  testWidgets('share menyalin laporan berisi klasifikasi dan probabilitas', (tester) async {
    String? copied;
    tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
      SystemChannels.platform,
      (call) async {
        if (call.method == 'Clipboard.setData') {
          copied = (call.arguments as Map)['text'] as String;
        }
        return null;
      },
    );
    addTearDown(() => tester.binding.defaultBinaryMessenger
        .setMockMethodCallHandler(SystemChannels.platform, null));

    final c = await open(tester, isSaved: false, hoaks: 0.93, fakta: 0.07);
    c.share();

    expect(copied, isNotNull);
    expect(copied, contains('Klasifikasi: *Hoaks*'));
    expect(copied, contains('Probabilitas Hoaks: 93.0%'));
    expect(copied, contains('Probabilitas Fakta: 7.0%'));
    expect(copied, contains('analisis'));
  });
}

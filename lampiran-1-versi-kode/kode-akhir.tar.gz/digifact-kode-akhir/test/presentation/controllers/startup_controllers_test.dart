import 'package:digifact/app/routes/app_routes.dart';
import 'package:digifact/presentation/controllers/onboarding_controller.dart';
import 'package:digifact/presentation/controllers/splash_controller.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import '../test_env.dart';

void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  testWidgets('SplashController: pengguna baru diarahkan ke onboarding', (tester) async {
    env.onboarding.done = false;
    await env.pumpApp(tester, Routes.history); // halaman netral sebagai titik awal
    Get.put(SplashController(Get.find()));

    Get.find<SplashController>().navigateNext();
    await pumpFor(tester, const Duration(milliseconds: 1500));

    expect(Get.currentRoute, Routes.onboarding);
  });

  testWidgets('SplashController: pengguna lama diarahkan ke beranda', (tester) async {
    env.onboarding.done = true;
    await env.pumpApp(tester, Routes.history);
    Get.put(SplashController(Get.find()));

    Get.find<SplashController>().navigateNext();
    await pumpFor(tester, const Duration(milliseconds: 1500));

    expect(Get.currentRoute, Routes.home);
  });

  testWidgets('SplashController.navigateNext idempoten (hanya navigasi sekali)',
      (tester) async {
    env.onboarding.done = true;
    await env.pumpApp(tester, Routes.history);
    final c = Get.put(SplashController(Get.find()));

    c.navigateNext();
    c.navigateNext();
    c.navigateNext();
    await pumpFor(tester, const Duration(milliseconds: 1500));

    expect(Get.currentRoute, Routes.home);
    expect(env.onboarding.hasSeenCalls, 1,
        reason: 'keputusan navigasi hanya diambil sekali');
  });

  testWidgets('OnboardingController.finish menandai selesai lalu membuka beranda',
      (tester) async {
    env.onboarding.done = false;
    await env.pumpApp(tester, Routes.onboarding);
    await pumpFor(tester, const Duration(milliseconds: 500));

    await Get.find<OnboardingController>().finish();
    await pumpFor(tester, const Duration(milliseconds: 1500));

    expect(env.onboarding.done, isTrue);
    expect(Get.currentRoute, Routes.home);
  });
}

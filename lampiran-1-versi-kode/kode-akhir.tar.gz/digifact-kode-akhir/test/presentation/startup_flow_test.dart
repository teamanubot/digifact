import 'package:digifact/app/routes/app_routes.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import 'test_env.dart';

void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  // Total animasi splash ±3,5 dtk (1200 ms + 80 + 700 + 120 + 1500 + 500 ms exit).
  const splashDuration = Duration(seconds: 6);

  testWidgets('splash -> beranda untuk pengguna yang sudah melihat onboarding',
      (tester) async {
    env.onboarding.done = true;
    await env.pumpApp(tester, Routes.splash);
    await pumpFor(tester, splashDuration);

    expect(find.text('ANALISIS BERITA SEKARANG'), findsOneWidget);
    expect(Get.currentRoute, Routes.home);
  });

  testWidgets('splash -> onboarding untuk pengguna baru', (tester) async {
    env.onboarding.done = false;
    await env.pumpApp(tester, Routes.splash);
    await pumpFor(tester, splashDuration);

    expect(find.text('Lewati'), findsOneWidget);
    expect(Get.currentRoute, Routes.onboarding);
  });

  testWidgets('melewati onboarding menandai selesai dan membuka beranda',
      (tester) async {
    env.onboarding.done = false;
    await env.pumpApp(tester, Routes.onboarding);
    await pumpFor(tester, const Duration(milliseconds: 500));

    await tester.tap(find.text('Lewati'));
    await pumpFor(tester, const Duration(milliseconds: 1500));

    expect(env.onboarding.done, isTrue);
    expect(find.text('ANALISIS BERITA SEKARANG'), findsOneWidget);
  });
}

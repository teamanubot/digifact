import 'package:digifact/app/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import 'test_env.dart';

/// Layar pengantar tidak boleh meluap pada layar yang kurang tinggi
/// (ditemukan pada uji emulator Android 7.0 berukuran 411 x 731 dp).
void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  for (final u in const [
    ('411 x 731 dp (emulator uji)', Size(1080, 1920), 2.625),
    ('360 x 640 dp (ponsel kecil)', Size(720, 1280), 2.0),
  ]) {
    testWidgets('onboarding tidak meluap pada ${u.$1}', (tester) async {
      env.onboarding.done = false;
      await env.pumpApp(tester, Routes.onboarding);
      tester.view.physicalSize = u.$2;
      tester.view.devicePixelRatio = u.$3;
      await pumpFor(tester, const Duration(milliseconds: 1700));
      for (var i = 0; i < 2; i++) {
        await tester.tap(find.text('Lanjutkan'));
        await pumpFor(tester, const Duration(milliseconds: 1700));
      }
      expect(tester.takeException(), isNull);
    });
  }
}

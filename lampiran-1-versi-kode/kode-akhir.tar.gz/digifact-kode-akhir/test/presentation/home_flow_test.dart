import 'package:digifact/app/routes/app_routes.dart';
import 'package:digifact/core/error/failures.dart';
import 'package:digifact/presentation/controllers/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import '../helpers/fakes.dart';
import 'test_env.dart';

void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  const analyze = 'ANALISIS BERITA SEKARANG';
  const validText = 'Bantuan tunai gratis untuk semua warga klik tautan ini';

  testWidgets('deteksi berhasil: membuka halaman hasil dan menyimpan riwayat',
      (tester) async {
    env.detection.result = makeResult(id: 'r1');
    await env.pumpApp(tester, Routes.home);

    await tester.enterText(find.byType(TextField), validText);
    await tester.tap(find.text(analyze));
    // 450 ms transisi + 800 ms timer haptic di ResultScreen.
    await pumpFor(tester, const Duration(milliseconds: 1600));

    expect(find.text('Hasil Analisis AI'), findsOneWidget);
    expect(env.detection.calls, [validText]);
    expect(env.history.stored.map((e) => e.id), ['r1']);
  });

  testWidgets('beranda memberi tahu bahwa teks dikirim ke server dan riwayat hanya lokal',
      (tester) async {
    await env.pumpApp(tester, Routes.home);

    expect(find.textContaining('dikirim ke server untuk dianalisis'), findsOneWidget);
    expect(find.textContaining('hanya disimpan di perangkat ini'), findsOneWidget);
  });

  testWidgets('input kosong: tidak memanggil server dan menampilkan pesan',
      (tester) async {
    await env.pumpApp(tester, Routes.home);

    await tester.tap(find.text(analyze));
    await pumpFor(tester, const Duration(milliseconds: 400));

    expect(env.detection.calls, isEmpty);
    expect(
      find.text('Silakan masukkan teks berita atau URL terlebih dahulu.'),
      findsOneWidget,
    );
    expect(find.text('Hasil Analisis AI'), findsNothing);
    expect(Get.find<HomeController>().isLoading.value, isFalse);
  });

  testWidgets('server gagal: dialog kesalahan tampil dan loading berhenti',
      (tester) async {
    env.detection.failure = const ServerFailure('Server sedang bermasalah');
    await env.pumpApp(tester, Routes.home);

    await tester.enterText(find.byType(TextField), validText);
    await tester.tap(find.text(analyze));
    await pumpFor(tester, const Duration(milliseconds: 500));

    expect(find.text('Koneksi Gagal'), findsOneWidget);
    expect(find.text('Server sedang bermasalah'), findsOneWidget);
    expect(env.history.stored, isEmpty, reason: 'gagal tidak boleh menyimpan riwayat');
    expect(Get.find<HomeController>().isLoading.value, isFalse);
  });

  testWidgets('status server mengikuti hasil pengecekan', (tester) async {
    env.detection.serverActive = false;
    await env.pumpApp(tester, Routes.home);
    await pumpFor(tester, const Duration(milliseconds: 300));

    expect(find.text('Offline'), findsOneWidget);
    expect(Get.find<HomeController>().isServerActive.value, isFalse);
  });

  testWidgets('riwayat terbaru tampil di beranda maksimal 3 item', (tester) async {
    for (var i = 0; i < 5; i++) {
      env.history.stored.add(makeResult(id: '$i', at: DateTime(2026, 1, 1 + i)));
    }
    await env.pumpApp(tester, Routes.home);

    expect(Get.find<HomeController>().recentHistory, hasLength(3));
    expect(Get.find<HomeController>().recentHistory.first.id, '4');
  });
}

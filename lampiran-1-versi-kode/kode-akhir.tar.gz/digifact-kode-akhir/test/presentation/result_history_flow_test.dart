import 'package:digifact/app/routes/app_routes.dart';
import 'package:digifact/app/routes/route_arguments.dart';
import 'package:digifact/domain/entities/detection_result.dart';
import 'package:digifact/presentation/controllers/history_controller.dart';
import 'package:digifact/presentation/controllers/result_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';

import '../helpers/fakes.dart';
import 'test_env.dart';

void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  group('ResultScreen', () {
    testWidgets('bookmark: hapus lalu simpan kembali memperbarui riwayat',
        (tester) async {
      final result = makeResult(id: 'r1');
      env.history.stored = [result];
      await env.pumpApp(tester, Routes.home);

      Get.toNamed(Routes.result,
          arguments: ResultArguments(result: result, isSaved: true));
      await pumpFor(tester, const Duration(milliseconds: 1600));

      final controller = Get.find<ResultController>();
      expect(controller.isSaved.value, isTrue);

      await tester.tap(find.byIcon(Icons.bookmark_rounded));
      await pumpFor(tester, const Duration(milliseconds: 400));
      expect(controller.isSaved.value, isFalse);
      expect(env.history.stored, isEmpty);

      await tester.tap(find.byIcon(Icons.bookmark_border_rounded));
      await pumpFor(tester, const Duration(milliseconds: 400));
      expect(controller.isSaved.value, isTrue);
      expect(env.history.stored.map((e) => e.id), ['r1']);
    });

    testWidgets('menampilkan verdict, analisis, dan penjelasan XAI', (tester) async {
      final result = makeResult(id: 'r2', label: 'Hoaks', hoaks: 0.93, fakta: 0.07);
      await env.pumpApp(tester, Routes.home);

      Get.toNamed(Routes.result,
          arguments: ResultArguments(result: result, isSaved: false));
      await pumpFor(tester, const Duration(milliseconds: 1600));

      expect(find.text('INDIKASI HOAKS'), findsOneWidget);
      expect(find.text('analisis'), findsOneWidget);
      expect(Get.find<ResultController>().isSaved.value, isFalse);
    });

    testWidgets('penjelasan kosong: vonis dan analisis tetap tampil, daftar kata kunci menampilkan keadaan kosong',
        (tester) async {
      final result = DetectionResult(
        id: 'kosong',
        teksAsli: 'teks kosong',
        probabilitasFakta: 0.07,
        probabilitasHoaks: 0.93,
        prediksiAkhir: 'Hoaks',
        penjelasanShap: const [],
        penjelasanLime: const [],
        analisisDetail: 'analisis tanpa penjelasan',
        tanggalDeteksi: DateTime(2026, 1, 1),
      );
      await env.pumpApp(tester, Routes.home);

      Get.toNamed(Routes.result, arguments: ResultArguments(result: result, isSaved: false));
      await pumpFor(tester, const Duration(milliseconds: 1600));

      expect(find.text('INDIKASI HOAKS'), findsOneWidget);
      expect(find.text('analisis tanpa penjelasan'), findsOneWidget);
      expect(find.text('Tidak ada data kata kunci.'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });

    testWidgets('verdict netral tidak ditampilkan sebagai Fakta/Hoaks', (tester) async {
      final result = makeResult(
        id: 'r3',
        label: 'Netral / Perlu Verifikasi Manual',
        fakta: 0.5,
        hoaks: 0.5,
      );
      await env.pumpApp(tester, Routes.home);

      Get.toNamed(Routes.result,
          arguments: ResultArguments(result: result, isSaved: false));
      await pumpFor(tester, const Duration(milliseconds: 1600));

      expect(find.text('PERLU VERIFIKASI'), findsOneWidget);
      expect(find.text('INDIKASI HOAKS'), findsNothing);
      expect(find.text('INFORMASI FAKTA'), findsNothing);
    });
  });

  group('HistoryScreen', () {
    testWidgets('menampilkan jumlah riwayat dan mengurutkan terbaru dulu',
        (tester) async {
      env.history.stored = [
        makeResult(id: 'lama', at: DateTime(2026, 1, 1)),
        makeResult(id: 'baru', at: DateTime(2026, 6, 1)),
      ];
      await env.pumpApp(tester, Routes.history);
      await pumpFor(tester, const Duration(milliseconds: 600));

      expect(find.text('2 pencarian tersimpan'), findsOneWidget);
      expect(Get.find<HistoryController>().history.first.id, 'baru');
    });

    testWidgets('riwayat kosong menampilkan keadaan kosong', (tester) async {
      await env.pumpApp(tester, Routes.history);
      await pumpFor(tester, const Duration(milliseconds: 600));

      expect(find.text('2 pencarian tersimpan'), findsNothing);
      expect(find.byIcon(Icons.history_toggle_off_rounded), findsOneWidget);
    });

    testWidgets('hapus semua: konfirmasi lalu riwayat kosong', (tester) async {
      env.history.stored = [makeResult(id: 'a'), makeResult(id: 'b')];
      await env.pumpApp(tester, Routes.history);
      await pumpFor(tester, const Duration(milliseconds: 600));

      await tester.tap(find.byIcon(Icons.delete_sweep_rounded));
      await pumpFor(tester, const Duration(milliseconds: 400));
      expect(find.text('Hapus Semua Riwayat?'), findsOneWidget);

      await tester.tap(find.text('Hapus'));
      await pumpFor(tester, const Duration(milliseconds: 600));

      expect(env.history.stored, isEmpty);
      expect(Get.find<HistoryController>().history, isEmpty);
    });
  });
}

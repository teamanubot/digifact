import 'package:digifact/presentation/widgets/bold_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const base = TextStyle(fontSize: 13);
  String plain(List<InlineSpan> spans) => spans.map((s) => (s as TextSpan).text).join();

  test('penanda **tebal** dihapus dan bagian dalamnya ditebalkan', () {
    final spans = boldSpans('Model menilai **mirip pola Hoaks** dengan **87%**.', base);

    expect(plain(spans), 'Model menilai mirip pola Hoaks dengan 87%.');
    final bold = spans.cast<TextSpan>().where((s) => s.style!.fontWeight == FontWeight.w700);
    expect(bold.map((s) => s.text), ['mirip pola Hoaks', '87%']);
  });

  test('teks tanpa penanda tidak berubah', () {
    expect(plain(boldSpans('teks biasa', base)), 'teks biasa');
  });

  test('penanda tanpa pasangan dibiarkan apa adanya (tidak merusak teks)', () {
    expect(plain(boldSpans('hanya satu ** penanda', base)), 'hanya satu ** penanda');
  });
}

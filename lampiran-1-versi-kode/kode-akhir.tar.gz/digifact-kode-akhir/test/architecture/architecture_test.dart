import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

/// Architecture test: menegakkan aturan dependensi Clean Architecture secara
/// otomatis dengan memindai `import` pada seluruh file di `lib/`.
///
///   presentation -> domain <- data          core: tidak bergantung ke layer lain
///
/// Jika seseorang menambah import yang melanggar aturan, test ini gagal.
void main() {
  final libDir = Directory('lib');

  List<File> filesIn(String layer) => Directory('lib/$layer')
      .listSync(recursive: true)
      .whereType<File>()
      .where((f) => f.path.endsWith('.dart'))
      .toList();

  List<String> importsOf(File file) => file
      .readAsLinesSync()
      .where((l) => l.trimLeft().startsWith('import '))
      .toList();

  /// Layer tujuan sebuah import relatif/package (null jika bukan milik app).
  String? layerOf(String importLine, File from) {
    final match = RegExp(r"import\s+'([^']+)'").firstMatch(importLine);
    if (match == null) return null;
    final target = match.group(1)!;
    if (target.startsWith('dart:')) return null;
    if (target.startsWith('package:digifact/')) {
      return target.replaceFirst('package:digifact/', '').split('/').first;
    }
    if (target.startsWith('package:')) return null;
    final resolved = from.absolute.parent.uri.resolve(target).path;
    final libPath = libDir.absolute.uri.path;
    if (!resolved.startsWith(libPath)) return null;
    return resolved.substring(libPath.length).split('/').first;
  }

  List<String> violations({
    required String layer,
    required Set<String> forbiddenLayers,
    Set<String> forbiddenPackages = const {},
    String? subPath,
  }) {
    final found = <String>[];
    for (final file in filesIn(layer)) {
      if (subPath != null && !file.path.contains(subPath)) continue;
      for (final line in importsOf(file)) {
        final target = layerOf(line, file);
        if (target != null && forbiddenLayers.contains(target)) {
          found.add('${file.path}: $line');
        }
        if (forbiddenPackages.any((p) => line.contains("'package:$p"))) {
          found.add('${file.path}: $line');
        }
      }
    }
    return found;
  }

  test('domain murni: tanpa Flutter, GetX, http, storage, data, presentation, app', () {
    expect(
      violations(
        layer: 'domain',
        forbiddenLayers: {'data', 'presentation', 'app'},
        forbiddenPackages: {
          'flutter/',
          'get/',
          'http/',
          'shared_preferences/',
          'google_fonts/',
        },
      ),
      isEmpty,
    );
  });

  test('data tidak bergantung ke presentation, app, maupun GetX/Flutter UI', () {
    expect(
      violations(
        layer: 'data',
        forbiddenLayers: {'presentation', 'app'},
        forbiddenPackages: {'get/', 'flutter/'},
      ),
      isEmpty,
    );
  });

  test('core tidak bergantung ke layer lain', () {
    expect(
      violations(
        layer: 'core',
        forbiddenLayers: {'domain', 'data', 'presentation', 'app'},
        forbiddenPackages: {'get/', 'flutter/'},
      ),
      isEmpty,
    );
  });

  test('presentation tidak mengakses data layer secara langsung', () {
    expect(
      violations(layer: 'presentation', forbiddenLayers: {'data'}),
      isEmpty,
    );
  });

  test('controller hanya bergantung pada use case, bukan repository', () {
    final found = <String>[];
    for (final file in filesIn('presentation/controllers')) {
      for (final line in importsOf(file)) {
        if (line.contains('domain/repositories/')) {
          found.add('${file.path}: $line');
        }
      }
    }
    expect(found, isEmpty);
  });

  test('domain tidak memakai service locator (Get.find/Get.put)', () {
    final found = <String>[];
    for (final layer in ['domain', 'data']) {
      for (final file in filesIn(layer)) {
        if (RegExp(r'Get\.(find|put|lazyPut)').hasMatch(file.readAsStringSync())) {
          found.add(file.path);
        }
      }
    }
    expect(found, isEmpty);
  });

  test('satu use case per file, dan tiap use case mewarisi UseCase', () {
    final found = <String>[];
    for (final file in Directory('lib/domain/usecases').listSync().whereType<File>()) {
      final src = file.readAsStringSync();
      final classes = RegExp(r'^class\s+\w+', multiLine: true).allMatches(src).length;
      if (classes != 1 || !src.contains('extends UseCase<')) found.add(file.path);
    }
    expect(found, isEmpty);
  });
}

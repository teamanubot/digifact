import 'dart:io';

import 'package:digifact/app/routes/app_routes.dart';
import 'package:digifact/app/routes/route_arguments.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../helpers/fakes.dart';
import '../presentation/test_env.dart';

/// Golden test: menangkap render tiap halaman sebagai gambar acuan.
///
/// Tujuan: membuktikan refactor UI (memecah file besar menjadi widget kecil)
/// tidak mengubah tampilan satu piksel pun. Acuan dibuat SEBELUM refactor.
/// Render bergantung platform, jadi acuan dibuat dan dijalankan di Linux.
///
/// Perbarui acuan (hanya bila perubahan tampilan disengaja):
///   flutter test test/golden --update-goldens
void main() {
  late TestEnv env;

  setUp(() => env = TestEnv());
  tearDown(Get.reset);

  // Font ikon tidak dimuat otomatis oleh flutter_test (ikon tampil sebagai kotak),
  // jadi dimuat dari cache SDK Flutter agar gambar acuan memuat ikon sebenarnya.
  setUpAll(() async {
    final root = Platform.environment['FLUTTER_ROOT'];
    final otf = File('$root/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf');
    if (root != null && otf.existsSync()) {
      final loader = FontLoader('MaterialIcons')
        ..addFont(Future.value(ByteData.sublistView(otf.readAsBytesSync())));
      await loader.load();
    }
  });

  // Varian font google_fonts dimuat dari asset secara asinkron; tunggu sampai
  // selesai agar teks (termasuk gaya italic) tidak tergambar sebagai kotak.
  Future<void> golden(WidgetTester tester, String name) async {
    await tester.runAsync(GoogleFonts.pendingFonts);
    await tester.pump(const Duration(milliseconds: 100));
    await expectLater(
      find.byType(GetMaterialApp),
      matchesGoldenFile('goldens/$name.png'),
    );
  }

  const settle = Duration(milliseconds: 1700);

  testWidgets('splash', (tester) async {
    await env.pumpApp(tester, Routes.splash);
    await pumpFor(tester, const Duration(milliseconds: 1200));
    await golden(tester, 'splash');
    await pumpFor(tester, const Duration(seconds: 5)); // tuntaskan timer navigasi
  });

  testWidgets('onboarding', (tester) async {
    env.onboarding.done = false;
    await env.pumpApp(tester, Routes.onboarding);
    await pumpFor(tester, settle);
    await golden(tester, 'onboarding_1');
  });

  for (final n in const [2, 3]) {
    testWidgets('onboarding $n', (tester) async {
      env.onboarding.done = false;
      await env.pumpApp(tester, Routes.onboarding);
      await pumpFor(tester, settle);
      for (var i = 1; i < n; i++) {
        await tester.tap(find.text('Lanjutkan'));
        await pumpFor(tester, settle);
      }
      await golden(tester, 'onboarding_$n');
    });
  }

  testWidgets('home kosong', (tester) async {
    await env.pumpApp(tester, Routes.home);
    await pumpFor(tester, settle);
    await golden(tester, 'home_kosong');
  });

  testWidgets('home dengan riwayat', (tester) async {
    env.history.stored = [
      makeResult(id: 'a', label: 'Hoaks', at: DateTime(2026, 6, 3, 10, 30)),
      makeResult(id: 'b', label: 'Fakta', hoaks: 0.1, fakta: 0.9, at: DateTime(2026, 6, 2, 9, 5)),
      makeResult(id: 'c', label: 'Netral / Perlu Verifikasi Manual', hoaks: 0.5, fakta: 0.5, at: DateTime(2026, 6, 1, 8, 0)),
    ];
    await env.pumpApp(tester, Routes.home);
    await pumpFor(tester, settle);
    await golden(tester, 'home_riwayat');
  });

  for (final c in const [
    ('hoaks', 'Hoaks', 0.07, 0.93),
    ('fakta', 'Fakta', 0.91, 0.09),
    ('netral', 'Netral / Perlu Verifikasi Manual', 0.55, 0.45),
  ]) {
    testWidgets('hasil ${c.$1}', (tester) async {
      final result = makeResult(id: 'r', label: c.$2, fakta: c.$3, hoaks: c.$4, at: DateTime(2026, 6, 3, 10, 30));
      await env.pumpApp(tester, Routes.home);
      Get.toNamed(Routes.result, arguments: ResultArguments(result: result, isSaved: true));
      await pumpFor(tester, const Duration(milliseconds: 2500));
      await golden(tester, 'hasil_${c.$1}');
    });
  }

  // Tab penjelasan kata kunci pada layar hasil: SHAP (bawaan) dan LIME.
  for (final t in const [('shap', '(SHAP)'), ('lime', '(LIME)')]) {
    testWidgets('hasil tab ${t.$1}', (tester) async {
      final result = makeResult(id: 'r', label: 'Hoaks', fakta: 0.07, hoaks: 0.93, at: DateTime(2026, 6, 3, 10, 30));
      await env.pumpApp(tester, Routes.home);
      Get.toNamed(Routes.result, arguments: ResultArguments(result: result, isSaved: true));
      await pumpFor(tester, const Duration(milliseconds: 2500));
      final tab = find.textContaining(t.$2);
      await tester.ensureVisible(tab);
      await tester.tap(tab);
      await pumpFor(tester, const Duration(milliseconds: 800));
      await tester.ensureVisible(tab);
      await pumpFor(tester, const Duration(milliseconds: 400));
      await golden(tester, 'hasil_tab_${t.$1}');
    });
  }

  testWidgets('riwayat berisi', (tester) async {
    env.history.stored = [
      makeResult(id: 'a', label: 'Hoaks', at: DateTime(2026, 6, 3, 10, 30)),
      makeResult(id: 'b', label: 'Fakta', hoaks: 0.1, fakta: 0.9, at: DateTime(2026, 6, 2, 9, 5)),
    ];
    await env.pumpApp(tester, Routes.history);
    await pumpFor(tester, settle);
    await golden(tester, 'riwayat_berisi');
  });

  testWidgets('riwayat kosong', (tester) async {
    await env.pumpApp(tester, Routes.history);
    await pumpFor(tester, settle);
    await golden(tester, 'riwayat_kosong');
  });

  testWidgets('edukasi', (tester) async {
    await env.pumpApp(tester, Routes.education);
    await pumpFor(tester, settle);
    await golden(tester, 'edukasi');
  });
}

import 'package:bloc/bloc.dart';
import 'package:digifact/core/usecase/usecase.dart';
import 'package:digifact/domain/entities/detection_result.dart';
import 'package:digifact/domain/usecases/clear_history.dart';
import 'package:digifact/domain/usecases/delete_result.dart';
import 'package:digifact/domain/usecases/get_history.dart';

/// State immutable: di BLoC/Cubit, setiap perubahan adalah objek state baru.
class HistoryState {
  final List<DetectionResult> items;

  const HistoryState(this.items);
}

/// Pendekatan 2: Cubit (paket `bloc`). Cakupan fitur identik.
class HistoryCubit extends Cubit<HistoryState> {
  final GetHistory _getHistory;
  final DeleteResult _deleteResult;
  final ClearHistory _clearHistory;

  HistoryCubit(this._getHistory, this._deleteResult, this._clearHistory)
      : super(const HistoryState([]));

  void load() => emit(HistoryState(_getHistory(const NoParams())));

  Future<void> delete(String id) async {
    await _deleteResult(id);
    load();
  }

  Future<void> clear() async {
    await _clearHistory(const NoParams());
    load();
  }
}

import 'package:digifact/domain/entities/detection_result.dart';
import 'package:digifact/domain/usecases/clear_history.dart';
import 'package:digifact/domain/usecases/delete_result.dart';
import 'package:digifact/domain/usecases/get_history.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/fakes.dart';
import 'history_cubit.dart';
import 'history_getx.dart';
import 'history_notifier.dart';

/// Perbandingan empiris state management pada fitur yang SAMA (riwayat:
/// muat, hapus satu, hapus semua) di atas use case domain yang SAMA.
///
/// Membuktikan dua hal:
///  1. Domain independen dari state management: tiga pendekatan berbeda
///     memakai use case yang persis sama tanpa modifikasi apa pun.
///  2. Perilakunya ekuivalen (skenario uji identik lulus di ketiganya).
///
/// Ukuran kode tiap pendekatan dihitung oleh `tool/compare_state_management.py`.
class _Facade {
  final String name;
  final List<DetectionResult> Function() items;
  final void Function() load;
  final Future<void> Function(String) delete;
  final Future<void> Function() clear;

  _Facade(this.name, this.items, this.load, this.delete, this.clear);
}

_Facade _getx(FakeHistoryRepository r) {
  final c = HistoryGetx(GetHistory(r), DeleteResult(r), ClearHistory(r));
  return _Facade('GetX', () => c.items, c.load, c.delete, c.clear);
}

_Facade _cubit(FakeHistoryRepository r) {
  final c = HistoryCubit(GetHistory(r), DeleteResult(r), ClearHistory(r));
  return _Facade('Cubit', () => c.state.items, c.load, c.delete, c.clear);
}

_Facade _notifier(FakeHistoryRepository r) {
  final c = HistoryNotifier(GetHistory(r), DeleteResult(r), ClearHistory(r));
  return _Facade('ChangeNotifier', () => c.items, c.load, c.delete, c.clear);
}

void main() {
  final builders = <String, _Facade Function(FakeHistoryRepository)>{
    'GetX': _getx,
    'Cubit': _cubit,
    'ChangeNotifier': _notifier,
  };

  for (final entry in builders.entries) {
    group('riwayat dengan ${entry.key}', () {
      late FakeHistoryRepository repo;
      late _Facade f;

      setUp(() {
        repo = FakeHistoryRepository([
          makeResult(id: 'lama', at: DateTime(2025, 1, 1)),
          makeResult(id: 'baru', at: DateTime(2026, 1, 1)),
        ]);
        f = entry.value(repo);
      });

      test('kosong sebelum dimuat', () => expect(f.items(), isEmpty));

      test('load: terurut terbaru dulu (aturan bisnis dari use case)', () {
        f.load();
        expect(f.items().map((e) => e.id), ['baru', 'lama']);
      });

      test('delete: item hilang dari state dan penyimpanan', () async {
        f.load();
        await f.delete('baru');
        expect(f.items().map((e) => e.id), ['lama']);
        expect(repo.stored.map((e) => e.id), ['lama']);
      });

      test('clear: state dan penyimpanan kosong', () async {
        f.load();
        await f.clear();
        expect(f.items(), isEmpty);
        expect(repo.stored, isEmpty);
      });
    });
  }
}

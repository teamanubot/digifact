import 'package:digifact/core/usecase/usecase.dart';
import 'package:digifact/domain/entities/detection_result.dart';
import 'package:digifact/domain/usecases/clear_history.dart';
import 'package:digifact/domain/usecases/delete_result.dart';
import 'package:digifact/domain/usecases/get_history.dart';
import 'package:get/get.dart';

/// Pendekatan 1: GetX. Cakupan fitur identik dengan dua pendekatan lain.
class HistoryGetx extends GetxController {
  final GetHistory _getHistory;
  final DeleteResult _deleteResult;
  final ClearHistory _clearHistory;

  HistoryGetx(this._getHistory, this._deleteResult, this._clearHistory);

  final items = <DetectionResult>[].obs;

  void load() => items.assignAll(_getHistory(const NoParams()));

  Future<void> delete(String id) async {
    await _deleteResult(id);
    load();
  }

  Future<void> clear() async {
    await _clearHistory(const NoParams());
    load();
  }
}

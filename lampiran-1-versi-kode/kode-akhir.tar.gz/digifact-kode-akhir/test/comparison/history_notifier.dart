import 'package:digifact/core/usecase/usecase.dart';
import 'package:digifact/domain/entities/detection_result.dart';
import 'package:digifact/domain/usecases/clear_history.dart';
import 'package:digifact/domain/usecases/delete_result.dart';
import 'package:digifact/domain/usecases/get_history.dart';
import 'package:flutter/foundation.dart';

/// Pendekatan 3: ChangeNotifier bawaan Flutter (dasar dari Provider).
/// Cakupan fitur identik.
class HistoryNotifier extends ChangeNotifier {
  final GetHistory _getHistory;
  final DeleteResult _deleteResult;
  final ClearHistory _clearHistory;

  HistoryNotifier(this._getHistory, this._deleteResult, this._clearHistory);

  List<DetectionResult> items = const [];

  void load() {
    items = _getHistory(const NoParams());
    notifyListeners();
  }

  Future<void> delete(String id) async {
    await _deleteResult(id);
    load();
  }

  Future<void> clear() async {
    await _clearHistory(const NoParams());
    load();
  }
}

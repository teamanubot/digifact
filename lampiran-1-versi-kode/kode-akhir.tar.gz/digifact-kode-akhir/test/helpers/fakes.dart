import 'package:digifact/core/error/failures.dart';
import 'package:digifact/domain/entities/detection_result.dart';
import 'package:digifact/domain/entities/word_weight.dart';
import 'package:digifact/domain/repositories/detection_repository.dart';
import 'package:digifact/domain/repositories/history_repository.dart';
import 'package:digifact/domain/repositories/onboarding_repository.dart';

DetectionResult makeResult({
  String id = 'id-1',
  String label = 'Hoaks',
  double fakta = 0.1,
  double hoaks = 0.9,
  DateTime? at,
}) {
  return DetectionResult(
    id: id,
    teksAsli: 'teks $id',
    probabilitasFakta: fakta,
    probabilitasHoaks: hoaks,
    prediksiAkhir: label,
    penjelasanShap: const [WordWeight(kata: 'bantuan', bobot: 0.2)],
    penjelasanLime: const [WordWeight(kata: 'gratis', bobot: 0.1)],
    analisisDetail: 'analisis',
    tanggalDeteksi: at ?? DateTime(2026, 1, 1),
  );
}

/// Repository riwayat in-memory: menyimpan urutan persis seperti diberikan.
class FakeHistoryRepository implements HistoryRepository {
  List<DetectionResult> stored;
  int saveCalls = 0;
  Failure? saveFailure;

  FakeHistoryRepository([List<DetectionResult>? initial])
      : stored = List.of(initial ?? const []);

  @override
  List<DetectionResult> getHistory() => List.of(stored);

  @override
  Future<void> saveHistory(List<DetectionResult> history) async {
    saveCalls++;
    if (saveFailure != null) throw saveFailure!;
    stored = List.of(history);
  }

  @override
  Future<void> clearHistory() async => stored = [];
}

class FakeDetectionRepository implements DetectionRepository {
  DetectionResult? result;
  Failure? failure;
  bool serverActive;
  final calls = <String>[];

  FakeDetectionRepository({this.result, this.failure, this.serverActive = true});

  @override
  Future<bool> checkServerStatus() async => serverActive;

  @override
  Future<DetectionResult> detectHoax(String textOrUrl) async {
    calls.add(textOrUrl);
    if (failure != null) throw failure!;
    return result ?? makeResult();
  }
}

class FakeOnboardingRepository implements OnboardingRepository {
  bool done;
  int resetCalls = 0;
  int hasSeenCalls = 0;

  FakeOnboardingRepository({this.done = false});

  @override
  bool get hasSeenOnboarding {
    hasSeenCalls++;
    return done;
  }

  @override
  Future<void> markOnboardingDone() async => done = true;

  @override
  Future<void> resetOnboarding() async {
    resetCalls++;
    done = false;
  }

  @override
  Future<void> checkAndResetOnboardingExpiry() async {}
}

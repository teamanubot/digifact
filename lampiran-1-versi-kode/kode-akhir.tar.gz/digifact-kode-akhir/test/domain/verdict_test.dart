import 'package:digifact/domain/entities/verdict.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/fakes.dart';

void main() {
  group('Verdict.fromLabel', () {
    test('memetakan label API', () {
      expect(Verdict.fromLabel('Fakta'), Verdict.fakta);
      expect(Verdict.fromLabel('Hoaks'), Verdict.hoaks);
      expect(Verdict.fromLabel(' hoaks '), Verdict.hoaks);
    });

    test('label netral atau tak dikenal menjadi netral', () {
      expect(Verdict.fromLabel('Netral / Perlu Verifikasi Manual'), Verdict.netral);
      expect(Verdict.fromLabel('apa saja'), Verdict.netral);
      expect(Verdict.fromLabel(''), Verdict.netral);
    });
  });

  group('DetectionResult.confidence', () {
    test('Hoaks memakai probabilitas hoaks', () {
      expect(makeResult(label: 'Hoaks', hoaks: 0.9, fakta: 0.1).confidence, 0.9);
    });

    test('Fakta memakai probabilitas fakta', () {
      expect(makeResult(label: 'Fakta', hoaks: 0.2, fakta: 0.8).confidence, 0.8);
    });

    test('Netral bernilai 0.5', () {
      expect(makeResult(label: 'Netral / Perlu Verifikasi Manual').confidence, 0.5);
    });
  });
}

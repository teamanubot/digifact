import 'package:digifact/core/error/failures.dart';
import 'package:digifact/domain/usecases/detect_hoax.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/fakes.dart';

void main() {
  late FakeDetectionRepository repository;
  late DetectHoax detectHoax;

  setUp(() {
    repository = FakeDetectionRepository();
    detectHoax = DetectHoax(repository);
  });

  test('input kosong ditolak dengan ValidationFailure', () {
    expect(() => detectHoax('   '), throwsA(isA<ValidationFailure>()));
    expect(repository.calls, isEmpty, reason: 'repository tidak boleh dipanggil');
  });

  test('input terlalu pendek ditolak', () {
    expect(() => detectHoax('pendek'), throwsA(isA<ValidationFailure>()));
    expect(repository.calls, isEmpty);
  });

  test('input valid dipangkas lalu diteruskan ke repository', () async {
    final result = await detectHoax('   Bantuan tunai gratis untuk warga   ');

    expect(repository.calls, ['Bantuan tunai gratis untuk warga']);
    expect(result.prediksiAkhir, 'Hoaks');
  });

  test('Failure dari repository diteruskan apa adanya', () {
    repository.failure = const NetworkFailure('offline');

    expect(
      detectHoax('Bantuan tunai gratis untuk warga'),
      throwsA(isA<NetworkFailure>()),
    );
  });
}

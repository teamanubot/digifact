import 'package:digifact/core/constants/app_constants.dart';
import 'package:digifact/core/usecase/usecase.dart';
import 'package:digifact/domain/usecases/clear_history.dart';
import 'package:digifact/domain/usecases/delete_result.dart';
import 'package:digifact/domain/usecases/get_history.dart';
import 'package:digifact/domain/usecases/save_result.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/fakes.dart';

void main() {
  late FakeHistoryRepository repository;

  setUp(() => repository = FakeHistoryRepository());

  group('SaveResult', () {
    test('hasil terbaru diletakkan di urutan pertama', () async {
      final save = SaveResult(repository);
      await save(makeResult(id: 'a'));
      await save(makeResult(id: 'b'));

      expect(repository.stored.map((e) => e.id), ['b', 'a']);
    });

    test('id yang sama menimpa data lama, bukan menggandakan', () async {
      final save = SaveResult(repository);
      await save(makeResult(id: 'a', label: 'Hoaks'));
      await save(makeResult(id: 'a', label: 'Fakta'));

      expect(repository.stored, hasLength(1));
      expect(repository.stored.single.prediksiAkhir, 'Fakta');
    });

    test('riwayat dibatasi ${AppConstants.maxHistoryItems} item, terlama dibuang',
        () async {
      final save = SaveResult(repository);
      for (var i = 0; i < AppConstants.maxHistoryItems + 5; i++) {
        await save(makeResult(id: '$i'));
      }

      expect(repository.stored, hasLength(AppConstants.maxHistoryItems));
      expect(repository.stored.first.id, '${AppConstants.maxHistoryItems + 4}');
      expect(repository.stored.any((e) => e.id == '0'), isFalse);
    });
  });

  group('DeleteResult', () {
    test('hanya menghapus id yang dimaksud', () async {
      repository = FakeHistoryRepository([makeResult(id: 'a'), makeResult(id: 'b')]);

      await DeleteResult(repository)('a');

      expect(repository.stored.map((e) => e.id), ['b']);
    });

    test('id yang tidak ada tidak mengubah data', () async {
      repository = FakeHistoryRepository([makeResult(id: 'a')]);

      await DeleteResult(repository)('zzz');

      expect(repository.stored.map((e) => e.id), ['a']);
    });
  });

  group('GetHistory', () {
    test('diurutkan dari tanggal terbaru', () {
      repository = FakeHistoryRepository([
        makeResult(id: 'lama', at: DateTime(2025, 1, 1)),
        makeResult(id: 'baru', at: DateTime(2026, 6, 1)),
        makeResult(id: 'tengah', at: DateTime(2025, 12, 1)),
      ]);

      final ids = GetHistory(repository)(const NoParams()).map((e) => e.id);

      expect(ids, ['baru', 'tengah', 'lama']);
    });
  });

  test('ClearHistory mengosongkan riwayat', () async {
    repository = FakeHistoryRepository([makeResult(id: 'a')]);

    await ClearHistory(repository)(const NoParams());

    expect(repository.stored, isEmpty);
  });
}

import 'dart:io';

import 'package:digifact/core/usecase/usecase.dart';
import 'package:digifact/data/datasources/local/file_history_local_data_source.dart';
import 'package:digifact/data/datasources/local/history_local_data_source.dart';
import 'package:digifact/data/repositories/history_repository_impl.dart';
import 'package:digifact/domain/usecases/clear_history.dart';
import 'package:digifact/domain/usecases/delete_result.dart';
import 'package:digifact/domain/usecases/get_history.dart';
import 'package:digifact/domain/usecases/save_result.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../helpers/fakes.dart';

/// Contract test: SEMUA implementasi [HistoryLocalDataSource] harus lolos
/// rangkaian pengujian yang sama, melalui repository dan use case asli.
///
/// Inilah bukti studi kasus perubahan: mengganti penyimpanan hanya menuntut
/// implementasi baru kontrak data source; domain (use case + aturan bisnis)
/// dan presentation tidak berubah dan tetap lulus.
void main() {
  final implementations = <String, Future<HistoryLocalDataSource> Function()>{
    'SharedPreferences': () async {
      SharedPreferences.setMockInitialValues({});
      return HistoryLocalDataSourceImpl(await SharedPreferences.getInstance());
    },
    'File JSON': () async {
      final dir = await Directory.systemTemp.createTemp('digifact_history_');
      addTearDown(() => dir.deleteSync(recursive: true));
      return FileHistoryLocalDataSource(File('${dir.path}/riwayat.json'));
    },
  };

  for (final entry in implementations.entries) {
    group('kontrak data source: ${entry.key}', () {
      late HistoryRepositoryImpl repository;
      late SaveResult save;
      late GetHistory get;

      setUp(() async {
        repository = HistoryRepositoryImpl(await entry.value());
        save = SaveResult(repository);
        get = GetHistory(repository);
      });

      test('kosong pada awalnya', () {
        expect(get(const NoParams()), isEmpty);
      });

      test('simpan lalu baca kembali utuh (termasuk penjelasan XAI)', () async {
        await save(makeResult(id: 'a'));

        final loaded = get(const NoParams()).single;
        expect(loaded.id, 'a');
        expect(loaded.penjelasanShap.single.kata, 'bantuan');
        expect(loaded.penjelasanLime.single.bobot, 0.1);
        expect(loaded.tanggalDeteksi, DateTime(2026, 1, 1));
      });

      test('aturan bisnis SaveResult berlaku: terbaru dulu, id sama menimpa', () async {
        await save(makeResult(id: 'a', at: DateTime(2026, 1, 1)));
        await save(makeResult(id: 'b', at: DateTime(2026, 2, 1)));
        await save(makeResult(id: 'a', label: 'Fakta', at: DateTime(2026, 3, 1)));

        final ids = get(const NoParams()).map((e) => e.id);
        expect(ids, ['a', 'b']);
        expect(get(const NoParams()).first.prediksiAkhir, 'Fakta');
      });

      test('batas 50 item ditegakkan use case, bukan data source', () async {
        for (var i = 0; i < 55; i++) {
          await save(makeResult(id: '$i', at: DateTime(2026, 1, 1 + i)));
        }
        expect(get(const NoParams()), hasLength(50));
      });

      test('hapus satu item dan hapus semua', () async {
        await save(makeResult(id: 'a'));
        await save(makeResult(id: 'b'));

        await DeleteResult(repository)('a');
        expect(get(const NoParams()).map((e) => e.id), ['b']);

        await ClearHistory(repository)(const NoParams());
        expect(get(const NoParams()), isEmpty);
      });
    });
  }
}

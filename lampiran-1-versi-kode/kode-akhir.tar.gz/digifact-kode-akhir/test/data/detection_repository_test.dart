import 'package:digifact/core/error/exceptions.dart';
import 'package:digifact/core/error/failures.dart';
import 'package:digifact/data/datasources/remote/detection_remote_data_source.dart';
import 'package:digifact/data/models/detection_result_model.dart';
import 'package:digifact/data/repositories/detection_repository_impl.dart';
import 'package:flutter_test/flutter_test.dart';

class _ThrowingRemote implements DetectionRemoteDataSource {
  final Object error;

  _ThrowingRemote(this.error);

  @override
  Future<bool> checkServerStatus() async => false;

  @override
  Future<DetectionResultModel> detectHoax(String textOrUrl) async =>
      throw error;
}

void main() {
  Future<Object?> failureFor(Object error) async {
    final repository = DetectionRepositoryImpl(_ThrowingRemote(error));
    try {
      await repository.detectHoax('teks');
    } catch (e) {
      return e;
    }
    return null;
  }

  test('ServerException dipetakan ke ServerFailure', () async {
    expect(await failureFor(const ServerException('x')), isA<ServerFailure>());
  });

  test('NetworkException dipetakan ke NetworkFailure', () async {
    expect(
      await failureFor(const NetworkException('x')),
      isA<NetworkFailure>(),
    );
  });

  test('timeout dipetakan ke TimeoutFailure', () async {
    expect(
      await failureFor(const RequestTimeoutException()),
      isA<TimeoutFailure>(),
    );
  });
}

import 'package:digifact/data/models/detection_result_model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final json = {
    'teks_asli': 'Berita uji',
    'probabilitas_fakta': 0.8,
    'probabilitas_hoaks': 0.2,
    'prediksi_akhir': 'Fakta',
    'penjelasan_shap': [
      {'kata': 'presiden', 'bobot': -0.12},
    ],
    'penjelasan_lime': [
      {'kata': 'antara', 'bobot': 1},
    ],
    'analisis_detail': 'Detail',
  };

  test('fromJson memetakan respons API dan memberi id default', () {
    final model = DetectionResultModel.fromJson(json);

    expect(model.id, isNotEmpty);
    expect(model.prediksiAkhir, 'Fakta');
    expect(model.penjelasanShap.single.kata, 'presiden');
    expect(model.penjelasanLime.single.bobot, 1.0);
  });

  test('toJson -> fromJson bersifat round-trip', () {
    final original = DetectionResultModel.fromJson(json);
    final restored = DetectionResultModel.fromJson(original.toJson());

    expect(restored.id, original.id);
    expect(restored.probabilitasHoaks, original.probabilitasHoaks);
    expect(restored.tanggalDeteksi, original.tanggalDeteksi);
    expect(restored.penjelasanShap.first.bobot, -0.12);
  });
}

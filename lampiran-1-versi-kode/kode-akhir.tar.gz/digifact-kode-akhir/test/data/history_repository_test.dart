import 'package:digifact/core/error/failures.dart';
import 'package:digifact/data/datasources/local/history_local_data_source.dart';
import 'package:digifact/data/models/detection_result_model.dart';
import 'package:digifact/data/repositories/history_repository_impl.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../helpers/fakes.dart';

/// Menguji persistensi riwayat (round-trip ke SharedPreferences).
/// Aturan bisnis riwayat diuji di test/domain/history_usecases_test.dart.
void main() {
  late HistoryRepositoryImpl repository;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    repository = HistoryRepositoryImpl(HistoryLocalDataSourceImpl(prefs));
  });

  test('riwayat kosong pada awalnya', () {
    expect(repository.getHistory(), isEmpty);
  });

  test('data yang disimpan dapat dibaca kembali utuh', () async {
    await repository.saveHistory([makeResult(id: 'a'), makeResult(id: 'b')]);

    final loaded = repository.getHistory();
    expect(loaded.map((e) => e.id), ['a', 'b']);
    expect(loaded.first.penjelasanShap.single.kata, 'bantuan');
    expect(loaded.first.probabilitasHoaks, 0.9);
  });

  test('clearHistory menghapus semua data', () async {
    await repository.saveHistory([makeResult(id: 'a')]);
    await repository.clearHistory();

    expect(repository.getHistory(), isEmpty);
  });

  test('data korup di penyimpanan tidak membuat aplikasi crash', () async {
    SharedPreferences.setMockInitialValues({
      'digifact_history': ['bukan-json'],
    });
    final prefs = await SharedPreferences.getInstance();
    final broken = HistoryRepositoryImpl(HistoryLocalDataSourceImpl(prefs));

    expect(broken.getHistory(), isEmpty);
  });

  test('kegagalan penyimpanan dipetakan menjadi CacheFailure', () async {
    final gagal = HistoryRepositoryImpl(_PenyimpananRusak());

    expect(() => gagal.saveHistory([makeResult(id: 'a')]), throwsA(isA<CacheFailure>()));
    expect(gagal.clearHistory, throwsA(isA<CacheFailure>()));
  });
}

class _PenyimpananRusak implements HistoryLocalDataSource {
  @override
  List<DetectionResultModel> getHistory() => [];

  @override
  Future<void> saveAll(List<DetectionResultModel> history) async => throw Exception('disk penuh');

  @override
  Future<void> clearHistory() async => throw Exception('disk penuh');
}

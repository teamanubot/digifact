# Kemas Ulang Kelas (Class Repackaging) ke dalam package default (tanpa nama)
-repackageclasses ''

# Overload nama method dan field secara agresif untuk obfuscation maksimum
-overloadaggressively

# Mengizinkan modifikasi akses modifier untuk inlining dan optimasi lebih efisien
-allowaccessmodification

# Hapus log debug (verbose & debug) dari aplikasi rilis untuk mengurangi ukuran kode
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}

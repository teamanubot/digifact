package com.teamanubot.digifact

import android.os.Bundle
import androidx.core.view.WindowCompat
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Layar penuh (edge-to-edge) untuk Android 15+ (SDK 35).
        // FlutterActivity bukan ComponentActivity sehingga enableEdgeToEdge()
        // tidak tersedia; WindowCompat menghasilkan perilaku yang sama.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
    }
}

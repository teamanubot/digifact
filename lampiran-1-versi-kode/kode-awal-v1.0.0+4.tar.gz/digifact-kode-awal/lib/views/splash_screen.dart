import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';
import 'home_screen.dart';
import 'onboarding_screen.dart';

// =============================================================
// SPLASH SCREEN – Animasi intro premium DigiFact
// =============================================================
class SplashScreen extends StatefulWidget {
  final StorageService storageService;
  final ApiService apiService;

  const SplashScreen({
    super.key,
    required this.storageService,
    required this.apiService,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  // ── Controllers ──────────────────────────────────────────────
  late AnimationController _logoController;
  late AnimationController _ringController;
  late AnimationController _particleController;
  late AnimationController _textController;
  late AnimationController _taglineController;
  late AnimationController _exitController;

  // ── Animations ───────────────────────────────────────────────
  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  late Animation<double> _ringScale;
  late Animation<double> _ringOpacity;
  late Animation<double> _textFade;
  late Animation<Offset> _textSlide;
  late Animation<double> _taglineFade;
  late Animation<double> _exitFade;

  static const int _particleCount = 8;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _startSequence();

    // Failsafe: paksa navigasi setelah 5 detik jika animasi macet
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted && !_navigated) {
        _navigated = true;
        _navigate();
      }
    });
  }

  void _initAnimations() {
    // Logo scale + fade in (elasticOut agar terasa "pop")
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _logoScale = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.elasticOut),
    );
    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );

    // Ring expand dari tengah
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _ringScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _ringController, curve: Curves.easeOutCubic),
    );
    _ringOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _ringController,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
      ),
    );

    // Partikel orbit (looping sepanjang splash)
    _particleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    // Teks nama aplikasi slide up + fade
    _textController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _textFade = CurvedAnimation(
      parent: _textController,
      curve: Curves.easeOut,
    );
    _textSlide = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _textController, curve: Curves.easeOutCubic),
    );

    // Tagline fade in
    _taglineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _taglineFade = CurvedAnimation(
      parent: _taglineController,
      curve: Curves.easeOut,
    );

    // Exit fade out keseluruhan layar
    _exitController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _exitFade = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _exitController, curve: Curves.easeIn),
    );
  }

  Future<void> _startSequence() async {
    try {
      // Tahap 1: Ring + logo muncul bersamaan
      if (!mounted) return;
      await Future.wait([
        _ringController.forward(),
        _logoController.forward(),
      ]);

      // Tahap 2: Nama aplikasi slide up
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 80));
      if (!mounted) return;
      await _textController.forward();

      // Tahap 3: Tagline fade in
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;
      await _taglineController.forward();

      // Tahap 4: Tahan sebentar lalu fade out
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 1500));
      if (!mounted) return;
      await _exitController.forward();
    } catch (_) {
      // Jika animasi diputus karena dispose, abaikan
    }

    if (mounted && !_navigated) {
      _navigated = true;
      _navigate();
    }
  }


  void _navigate() {
    final Widget destination = widget.storageService.hasSeenOnboarding
        ? HomeScreen(
            apiService: widget.apiService,
            storageService: widget.storageService,
          )
        : OnboardingScreen(
            storageService: widget.storageService,
            apiService: widget.apiService,
          );

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (context, animation, _) => destination,
        transitionsBuilder: (context, animation, _, child) {
          return FadeTransition(opacity: animation, child: child);
        },
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  @override
  void dispose() {
    _logoController.dispose();
    _ringController.dispose();
    _particleController.dispose();
    _textController.dispose();
    _taglineController.dispose();
    _exitController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(0xFF050D1A),
      body: FadeTransition(
        opacity: _exitFade,
        child: Stack(
          children: [
            // ── Layer 1: Background ──────────────────────────────
            _buildBackground(size),

            // ── Layer 2: Orbit rings ─────────────────────────────
            Center(child: _buildOrbitRings()),

            // ── Layer 3: Orbit particles ─────────────────────────
            Center(child: _buildParticles()),

            // ── Layer 4: Logo center ─────────────────────────────
            Center(child: _buildLogo()),

            // ── Layer 5: Bottom text block ───────────────────────
            _buildBottomText(size),

            // ── Layer 6: Version + loading dots ─────────────────
            _buildVersionBadge(),
          ],
        ),
      ),
    );
  }

  // ── BACKGROUND ───────────────────────────────────────────────
  Widget _buildBackground(Size size) {
    return AnimatedBuilder(
      animation: _particleController,
      builder: (context, _) {
        final t = _particleController.value * 2 * math.pi;
        return Stack(
          children: [
            // Radial gradient biru gelap ke hitam
            Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0, -0.2),
                  radius: 1.2,
                  colors: [Color(0xFF0A2550), Color(0xFF050D1A)],
                ),
              ),
            ),
            // Orb hijau
            Positioned(
              top: size.height * 0.08 + 20 * math.sin(t * 0.55),
              right: size.width * 0.08 + 10 * math.cos(t * 0.4),
              child: _glowBlob(180, AppColors.neonGreen, 0.06),
            ),
            // Orb cyan
            Positioned(
              bottom: size.height * 0.1 + 15 * math.sin(t * 0.5),
              left: size.width * 0.04 + 10 * math.cos(t * 0.65),
              child: _glowBlob(200, AppColors.neonCyan, 0.05),
            ),
          ],
        );
      },
    );
  }

  Widget _glowBlob(double s, Color color, double alpha) {
    return Container(
      width: s,
      height: s,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withValues(alpha: alpha), Colors.transparent],
        ),
      ),
    );
  }

  // ── ORBIT RINGS ──────────────────────────────────────────────
  Widget _buildOrbitRings() {
    return AnimatedBuilder(
      animation: Listenable.merge([_ringController, _particleController]),
      builder: (context, _) {
        return ScaleTransition(
          scale: _ringScale,
          child: FadeTransition(
            opacity: _ringOpacity,
            child: SizedBox(
              width: 280,
              height: 280,
              child: CustomPaint(
                painter: _SplashRingPainter(
                  progress: _particleController.value,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ── PARTICLES ────────────────────────────────────────────────
  Widget _buildParticles() {
    return AnimatedBuilder(
      animation: _particleController,
      builder: (context, _) {
        return SizedBox(
          width: 280,
          height: 280,
          child: CustomPaint(
            painter: _SplashParticlePainter(
              progress: _particleController.value,
              count: _particleCount,
            ),
          ),
        );
      },
    );
  }

  // ── LOGO ─────────────────────────────────────────────────────
  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _logoController,
      builder: (context, _) {
        return FadeTransition(
          opacity: _logoFade,
          child: ScaleTransition(
            scale: _logoScale,
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFF0D3580), Color(0xFF0A2050)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: AppColors.neonCyan.withValues(alpha: 0.35),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.neonCyan.withValues(alpha: 0.28),
                    blurRadius: 36,
                    spreadRadius: 6,
                  ),
                  BoxShadow(
                    color: AppColors.neonGreen.withValues(alpha: 0.12),
                    blurRadius: 52,
                    spreadRadius: 10,
                  ),
                ],
              ),
              child: Center(
                child: ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [AppColors.neonCyan, AppColors.neonGreen],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ).createShader(bounds),
                  child: const Icon(
                    Icons.fact_check_rounded,
                    size: 46,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ── BOTTOM TEXT ──────────────────────────────────────────────
  Widget _buildBottomText(Size size) {
    return Positioned(
      bottom: size.height * 0.24,
      left: 0,
      right: 0,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Nama "DigiFact"
          SlideTransition(
            position: _textSlide,
            child: FadeTransition(
              opacity: _textFade,
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'Digi',
                      style: GoogleFonts.dmSans(
                        fontSize: 42,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        letterSpacing: -1.5,
                      ),
                    ),
                    TextSpan(
                      text: 'Fact',
                      style: GoogleFonts.dmSans(
                        fontSize: 42,
                        fontWeight: FontWeight.w800,
                        color: AppColors.neonCyan,
                        letterSpacing: -1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Tagline
          FadeTransition(
            opacity: _taglineFade,
            child: Text(
              'Deteksi Kebenaran Informasi\nberbasis Kecerdasan Buatan',
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(
                fontSize: 14,
                color: AppColors.textSecondary,
                height: 1.6,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── VERSION BADGE ────────────────────────────────────────────
  Widget _buildVersionBadge() {
    return Positioned(
      bottom: 36,
      left: 0,
      right: 0,
      child: FadeTransition(
        opacity: _taglineFade,
        child: Column(
          children: [
            _buildLoadingDots(),
            const SizedBox(height: 14),
            Text(
              'v1.0.0 · Random Forest + SHAP/LIME',
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(
                fontSize: 10.5,
                color: AppColors.textMuted,
                letterSpacing: 0.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingDots() {
    return AnimatedBuilder(
      animation: _particleController,
      builder: (context, _) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(3, (i) {
            final phase = (_particleController.value + i * 0.25) % 1.0;
            final opacity =
                (math.sin(phase * 2 * math.pi) * 0.45 + 0.55).clamp(0.15, 1.0);
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 3.5),
              width: 5,
              height: 5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.neonCyan.withValues(alpha: opacity),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.neonCyan.withValues(alpha: opacity * 0.4),
                    blurRadius: 6,
                  ),
                ],
              ),
            );
          }),
        );
      },
    );
  }
}

// =============================================================
// CUSTOM PAINTERS untuk Splash
// =============================================================

class _SplashRingPainter extends CustomPainter {
  final double progress;
  _SplashRingPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);

    void drawRing(double radius, Color color, double alpha, double strokeW) {
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..color = color.withValues(alpha: alpha)
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeW,
      );
    }

    // Tiga ring statis
    drawRing(size.width / 2 - 4, AppColors.neonCyan, 0.12, 1.0);
    drawRing(size.width / 2 - 28, AppColors.neonCyan, 0.08, 0.8);
    drawRing(size.width / 2 - 54, AppColors.neonGreen, 0.07, 0.6);

    // Arc aktif berputar – outer (cyan)
    final outerPaint = Paint()
      ..color = AppColors.neonCyan.withValues(alpha: 0.7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: size.width / 2 - 4),
      progress * 2 * math.pi,
      math.pi * 0.6,
      false,
      outerPaint,
    );

    // Arc aktif berputar – inner (green, berlawanan arah)
    final innerPaint = Paint()
      ..color = AppColors.neonGreen.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: size.width / 2 - 54),
      -progress * 1.5 * 2 * math.pi,
      math.pi * 0.5,
      false,
      innerPaint,
    );
  }

  @override
  bool shouldRepaint(_SplashRingPainter old) => old.progress != progress;
}

class _SplashParticlePainter extends CustomPainter {
  final double progress;
  final int count;
  _SplashParticlePainter({required this.progress, required this.count});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final outerR = size.width / 2 - 4;
    final innerR = size.width / 2 - 54;

    for (int i = 0; i < count; i++) {
      final frac = i / count;
      final brightness =
          (math.sin((progress + frac * 2) * 2 * math.pi) * 0.4 + 0.6)
              .clamp(0.2, 1.0);

      // Outer dot (cyan)
      final outerAngle = (progress + frac) * 2 * math.pi;
      final ox = center.dx + outerR * math.cos(outerAngle);
      final oy = center.dy + outerR * math.sin(outerAngle);
      canvas.drawCircle(
        Offset(ox, oy),
        5,
        Paint()
          ..color = AppColors.neonCyan.withValues(alpha: 0.18 * brightness)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
        Offset(ox, oy),
        2.5,
        Paint()..color = AppColors.neonCyan.withValues(alpha: brightness),
      );

      // Inner dot (green, separuh partikel, arah terbalik)
      if (i % 2 == 0) {
        final innerAngle = (-progress * 1.4 + frac * 1.5) * 2 * math.pi;
        final ix = center.dx + innerR * math.cos(innerAngle);
        final iy = center.dy + innerR * math.sin(innerAngle);
        canvas.drawCircle(
          Offset(ix, iy),
          3,
          Paint()
            ..color = AppColors.neonGreen.withValues(alpha: 0.15 * brightness)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
        );
        canvas.drawCircle(
          Offset(ix, iy),
          1.8,
          Paint()
            ..color = AppColors.neonGreen.withValues(alpha: brightness * 0.75),
        );
      }
    }
  }

  @override
  bool shouldRepaint(_SplashParticlePainter old) => old.progress != progress;
}

import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/detection_result.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';
import 'education_screen.dart';
import 'history_screen.dart';
import 'result_screen.dart';

// =============================================================
// DESIGN SYSTEM TOKENS
// =============================================================
class AppColors {
  // Backgrounds
  static const navy = Color(0xFF0A1F44);
  static const navyDeep = Color(0xFF050D1A);
  static const navyMid = Color(0xFF0D1B35);
  static const navyCard = Color(0xFF0F2347);
  static const navyElevated = Color(0xFF112851);

  // Neon Accents
  static const neonGreen = Color(0xFF33FF33);
  static const neonRed = Color(0xFFFF3333);
  static const neonCyan = Color(0xFF00D4FF);
  static const neonBlue = Color(0xFF2979FF);

  // Text
  static const textPrimary = Colors.white;
  static const textSecondary = Color(0xFF708090); // Slate Gray
  static const textMuted = Color(0xFF3D5475);

  // Borders
  static const borderSubtle = Color(0xFF1A3060);
  static const borderGlow = Color(0xFF243D6B);
}

class AppRadius {
  static const xs = 8.0;
  static const sm = 12.0;
  static const md = 16.0;
  static const lg = 20.0;
  static const xl = 24.0;
  static const xxl = 32.0;
}

// =============================================================
// HOME SCREEN
// =============================================================
class HomeScreen extends StatefulWidget {
  final ApiService apiService;
  final StorageService storageService;

  const HomeScreen({
    super.key,
    required this.apiService,
    required this.storageService,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  bool _isServerActive = false;
  List<DetectionResult> _recentHistory = [];

  // Controllers animasi
  late AnimationController _pulseController;
  late AnimationController _shimmerController;
  late AnimationController _buttonScaleController;
  late Animation<double> _buttonScaleAnim;
  late AnimationController _bgOrbitController;

  // Scan line animation state
  bool _isInputFocused = false;

  @override
  void initState() {
    super.initState();
    _checkServer();
    _loadRecentHistory();

    // Denyut nadi indikator server
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    // Shimmer background orbit
    _bgOrbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    // Shimmer untuk loading state
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    // Scale animasi tombol
    _buttonScaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _buttonScaleAnim = Tween<double>(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _buttonScaleController, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _textController.dispose();
    _pulseController.dispose();
    _shimmerController.dispose();
    _buttonScaleController.dispose();
    _bgOrbitController.dispose();
    super.dispose();
  }

  Future<void> _checkServer() async {
    final status = await widget.apiService.checkServerStatus();
    if (mounted) setState(() => _isServerActive = status);
  }

  void _loadRecentHistory() {
    final history = widget.storageService.getHistory();
    setState(() => _recentHistory = history.take(3).toList());
  }

  Future<void> _processDetection() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.info_outline_rounded, color: Color(0xFFFF3333), size: 16),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Silakan masukkan teks berita atau URL terlebih dahulu.',
                  style: GoogleFonts.dmSans(fontSize: 13, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      );
      return;
    }

    // Haptic feedback
    HapticFeedback.mediumImpact();

    setState(() => _isLoading = true);

    try {
      final result = await widget.apiService.detectHoax(text);
      await widget.storageService.saveResult(result);
      _loadRecentHistory();

      if (mounted) {
        Navigator.of(context).push(
          PageRouteBuilder(
            pageBuilder: (context, animation, _) => ResultScreen(
              result: result,
              storageService: widget.storageService,
              isSaved: true,
            ),
            transitionsBuilder: (context, animation, _, child) {
              return FadeTransition(
                opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.04),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOut)),
                  child: child,
                ),
              );
            },
            transitionDuration: const Duration(milliseconds: 450),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        HapticFeedback.heavyImpact();
        showDialog(
          context: context,
          builder: (context) => _buildErrorDialog(e.toString()),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Widget _buildErrorDialog(String message) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          color: AppColors.navyMid,
          borderRadius: BorderRadius.circular(AppRadius.xl),
          border: Border.all(
            color: AppColors.neonRed.withValues(alpha: 0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.neonRed.withValues(alpha: 0.12),
              blurRadius: 32,
              spreadRadius: 4,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.neonRed.withValues(alpha: 0.1),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.neonRed.withValues(alpha: 0.25)),
              ),
              child: const Icon(Icons.signal_wifi_bad_rounded, color: AppColors.neonRed, size: 28),
            ),
            const SizedBox(height: 18),
            Text(
              'Koneksi Gagal',
              style: GoogleFonts.dmSans(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              message.replaceAll('Exception: ', ''),
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(
                fontSize: 13,
                color: AppColors.textSecondary,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  backgroundColor: AppColors.neonRed.withValues(alpha: 0.12),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    side: BorderSide(color: AppColors.neonRed.withValues(alpha: 0.35)),
                  ),
                ),
                child: Text(
                  'Tutup',
                  style: GoogleFonts.dmSans(
                    fontWeight: FontWeight.w700,
                    color: AppColors.neonRed,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: Stack(
        children: [
          // ── Animated background orbs ──────────────────────────
          _buildAnimatedBackground(),

          // ── Main content ──────────────────────────────────────
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(),
                        const SizedBox(height: 28),
                        _buildAiBadge(),
                        const SizedBox(height: 24),
                        _buildInputCard(),
                        const SizedBox(height: 20),
                        _buildNavMenuRow(),
                        const SizedBox(height: 32),
                        _buildRecentHeader(),
                        const SizedBox(height: 14),
                        _buildRecentList(),
                        const SizedBox(height: 32),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── BACKGROUND ORBS ─────────────────────────────────────────
  Widget _buildAnimatedBackground() {
    return AnimatedBuilder(
      animation: _bgOrbitController,
      builder: (context, _) {
        final t = _bgOrbitController.value * 2 * math.pi;
        return Stack(
          children: [
            // Orb kiri atas – cyan
            Positioned(
              top: -60 + 20 * math.sin(t * 0.7),
              left: -80 + 10 * math.cos(t * 0.5),
              child: _glowOrb(260, AppColors.neonCyan, 0.08),
            ),
            // Orb kanan bawah – blue
            Positioned(
              bottom: -80 + 15 * math.sin(t * 0.4),
              right: -60 + 10 * math.cos(t * 0.6),
              child: _glowOrb(240, AppColors.neonBlue, 0.10),
            ),
            // Orb tengah mikro – green
            Positioned(
              top: 300 + 30 * math.sin(t),
              right: 60 + 20 * math.cos(t * 0.8),
              child: _glowOrb(120, AppColors.neonGreen, 0.05),
            ),
          ],
        );
      },
    );
  }

  Widget _glowOrb(double size, Color color, double alpha) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            color.withValues(alpha: alpha),
            color.withValues(alpha: 0),
          ],
        ),
      ),
    );
  }

  // ── HEADER ───────────────────────────────────────────────────
  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'Digi',
                      style: GoogleFonts.dmSans(
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        letterSpacing: -1.2,
                      ),
                    ),
                    TextSpan(
                      text: 'Fact',
                      style: GoogleFonts.dmSans(
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        color: AppColors.neonCyan,
                        letterSpacing: -1.2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'Deteksi Kebenaran Informasi · AI-Powered',
                style: GoogleFonts.dmSans(
                  fontSize: 11.5,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w400,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),

        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Server status badge
            GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                _checkServer();
              },
              child: AnimatedBuilder(
                animation: _pulseController,
                builder: (_, _) {
                  final isOn = _isServerActive;
                  final dotColor = isOn ? AppColors.neonGreen : AppColors.neonRed;
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: dotColor.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: dotColor.withValues(alpha: 0.25),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: dotColor,
                            boxShadow: [
                              BoxShadow(
                                color: dotColor.withValues(alpha: _pulseController.value * 0.9),
                                blurRadius: 8 * _pulseController.value,
                                spreadRadius: 2 * _pulseController.value,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 7),
                        Text(
                          isOn ? 'Server Online' : 'Offline',
                          style: GoogleFonts.dmSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: dotColor,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(width: 8),
            // Tombol Reset Onboarding untuk debugging / pengujian
            GestureDetector(
              onTap: () async {
                HapticFeedback.mediumImpact();
                await widget.storageService.resetOnboarding();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Row(
                        children: [
                          const Icon(Icons.check_circle_rounded, color: AppColors.neonGreen, size: 18),
                          const SizedBox(width: 8),
                          Text(
                            'Status Onboarding berhasil direset!',
                            style: GoogleFonts.dmSans(color: Colors.white),
                          ),
                        ],
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.04),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.1),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.restart_alt_rounded,
                  color: Colors.white70,
                  size: 16,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ── AI POWERED BADGE ─────────────────────────────────────────
  Widget _buildAiBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Row(
        children: [
          // Animasi grid dot
          _buildAiDotGrid(),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Machine Learning · Random Forest',
                  style: GoogleFonts.dmSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.neonCyan,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Didukung SHAP & LIME untuk Explainable AI yang transparan.',
                  style: GoogleFonts.dmSans(
                    fontSize: 11.5,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAiDotGrid() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, _) {
        return SizedBox(
          width: 36,
          height: 36,
          child: GridView.count(
            crossAxisCount: 3,
            mainAxisSpacing: 3,
            crossAxisSpacing: 3,
            physics: const NeverScrollableScrollPhysics(),
            children: List.generate(9, (i) {
              final delay = (i * 0.11) % 1.0;
              final v = (_pulseController.value + delay) % 1.0;
              return Container(
                decoration: BoxDecoration(
                  color: AppColors.neonCyan.withValues(
                    alpha: 0.15 + 0.6 * (math.sin(v * math.pi)).clamp(0.0, 1.0),
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            }),
          ),
        );
      },
    );
  }

  // ── INPUT CARD ───────────────────────────────────────────────
  Widget _buildInputCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.xl),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: AppColors.navyCard.withValues(alpha: 0.85),
            borderRadius: BorderRadius.circular(AppRadius.xl),
            border: Border.all(
              color: _isInputFocused
                  ? AppColors.neonCyan.withValues(alpha: 0.35)
                  : AppColors.borderSubtle,
              width: 1.5,
            ),
            boxShadow: [
              if (_isInputFocused)
                BoxShadow(
                  color: AppColors.neonCyan.withValues(alpha: 0.08),
                  blurRadius: 24,
                  spreadRadius: 2,
                ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Label + clear button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.document_scanner_outlined,
                        color: AppColors.neonCyan.withValues(alpha: 0.8),
                        size: 16,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Verifikasi Berita / URL',
                        style: GoogleFonts.dmSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  if (_textController.text.isNotEmpty)
                    GestureDetector(
                      onTap: () {
                        setState(() => _textController.clear());
                        HapticFeedback.selectionClick();
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.neonRed.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.neonRed.withValues(alpha: 0.2)),
                        ),
                        child: Text(
                          'Bersihkan',
                          style: GoogleFonts.dmSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: AppColors.neonRed,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 14),

              // Text field
              Focus(
                onFocusChange: (focused) => setState(() => _isInputFocused = focused),
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.navyDeep.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    border: Border.all(
                      color: _isInputFocused
                          ? AppColors.neonCyan.withValues(alpha: 0.2)
                          : AppColors.borderSubtle.withValues(alpha: 0.5),
                    ),
                  ),
                  child: TextField(
                    controller: _textController,
                    maxLines: 7,
                    minLines: 5,
                    style: GoogleFonts.dmSans(
                      fontSize: 14,
                      color: Colors.white,
                      height: 1.6,
                    ),
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      hintText:
                          'Tuliskan artikel atau tempel link URL berita\n(contoh: Kompas, Antara, Tempo) di sini...',
                      hintStyle: GoogleFonts.dmSans(
                        fontSize: 13.5,
                        color: AppColors.textMuted,
                        height: 1.6,
                      ),
                      contentPadding: const EdgeInsets.all(18),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),

              // Tombol Analisis dengan animasi press
              GestureDetector(
                onTapDown: (_) => _buttonScaleController.forward(),
                onTapUp: (_) {
                  _buttonScaleController.reverse();
                  _processDetection();
                },
                onTapCancel: () => _buttonScaleController.reverse(),
                child: ScaleTransition(
                  scale: _buttonScaleAnim,
                  child: _buildAnalyzeButton(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAnalyzeButton() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: double.infinity,
      height: 54,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.md),
        gradient: _isLoading
            ? LinearGradient(
                colors: [
                  AppColors.neonCyan.withValues(alpha: 0.3),
                  AppColors.neonBlue.withValues(alpha: 0.3),
                ],
              )
            : const LinearGradient(
                colors: [Color(0xFF0077FF), Color(0xFF00D4FF)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
        boxShadow: _isLoading
            ? []
            : [
                BoxShadow(
                  color: AppColors.neonCyan.withValues(alpha: 0.30),
                  blurRadius: 18,
                  spreadRadius: -2,
                  offset: const Offset(0, 6),
                ),
              ],
      ),
      child: _isLoading
          ? Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SpinKitPulse(
                  color: AppColors.neonCyan,
                  size: 22,
                  controller: _shimmerController,
                ),
                const SizedBox(width: 14),
                Text(
                  'MENGANALISIS DATA...',
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.0,
                    color: AppColors.neonCyan,
                  ),
                ),
              ],
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.bolt_rounded, color: Colors.white, size: 20),
                const SizedBox(width: 8),
                Text(
                  'ANALISIS BERITA SEKARANG',
                  style: GoogleFonts.dmSans(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
    );
  }

  // ── NAVIGATION MENU ──────────────────────────────────────────
  Widget _buildNavMenuRow() {
    return Row(
      children: [
        Expanded(
          child: _buildGlassMenu(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const EducationScreen()),
            ),
            icon: Icons.menu_book_rounded,
            accentColor: AppColors.neonCyan,
            title: 'Panduan Cek',
            subtitle: 'Tips Literasi Digital',
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: _buildGlassMenu(
            onTap: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => HistoryScreen(storageService: widget.storageService),
                ),
              );
              _loadRecentHistory();
            },
            icon: Icons.manage_search_rounded,
            accentColor: AppColors.neonGreen,
            title: 'Riwayat Cek',
            subtitle: 'Lihat aktivitas lalu',
          ),
        ),
      ],
    );
  }

  Widget _buildGlassMenu({
    required VoidCallback onTap,
    required IconData icon,
    required Color accentColor,
    required String title,
    required String subtitle,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.navyCard.withValues(alpha: 0.8),
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(color: AppColors.borderSubtle),
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              splashColor: accentColor.withValues(alpha: 0.08),
              highlightColor: accentColor.withValues(alpha: 0.04),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.circular(AppRadius.sm),
                        border: Border.all(color: accentColor.withValues(alpha: 0.22)),
                      ),
                      child: Icon(icon, color: accentColor, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: GoogleFonts.dmSans(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            subtitle,
                            style: GoogleFonts.dmSans(
                              fontSize: 10.5,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── RECENT HISTORY ───────────────────────────────────────────
  Widget _buildRecentHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Pengecekan Terbaru',
          style: GoogleFonts.dmSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        if (_recentHistory.isNotEmpty)
          GestureDetector(
            onTap: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => HistoryScreen(storageService: widget.storageService),
                ),
              );
              _loadRecentHistory();
            },
            child: Row(
              children: [
                Text(
                  'Lihat Semua',
                  style: GoogleFonts.dmSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.neonCyan,
                  ),
                ),
                const SizedBox(width: 3),
                const Icon(Icons.arrow_forward_ios_rounded, size: 10, color: AppColors.neonCyan),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildRecentList() {
    if (_recentHistory.isEmpty) {
      return _buildEmptyHistory();
    }
    return Column(
      children: _recentHistory.asMap().entries.map((entry) {
        return _buildHistoryCard(entry.value, entry.key);
      }).toList(),
    );
  }

  Widget _buildEmptyHistory() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
      decoration: BoxDecoration(
        color: AppColors.navyCard.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle.withValues(alpha: 0.5)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.neonCyan.withValues(alpha: 0.06),
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.neonCyan.withValues(alpha: 0.12)),
            ),
            child: Icon(Icons.inbox_outlined, color: AppColors.textSecondary, size: 32),
          ),
          const SizedBox(height: 14),
          Text(
            'Belum Ada Riwayat',
            style: GoogleFonts.dmSans(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Hasil deteksi akan otomatis tersimpan di sini.',
            textAlign: TextAlign.center,
            style: GoogleFonts.dmSans(
              fontSize: 12.5,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryCard(DetectionResult item, int index) {
    final isFakta = item.prediksiAkhir == 'Fakta';
    final isHoaks = item.prediksiAkhir == 'Hoaks';
    final statusColor = isFakta
        ? AppColors.neonGreen
        : isHoaks
            ? AppColors.neonRed
            : const Color(0xFFFFAA00);

    final snippet = item.teksAsli.length > 75
        ? '${item.teksAsli.substring(0, 75).replaceAll('\n', ' ')}...'
        : item.teksAsli.replaceAll('\n', ' ');

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.borderSubtle),
        boxShadow: [
          BoxShadow(
            color: statusColor.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => ResultScreen(
                    result: item,
                    storageService: widget.storageService,
                    isSaved: true,
                  ),
                ),
              );
              _loadRecentHistory();
            },
            splashColor: statusColor.withValues(alpha: 0.06),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Status dot bar kiri
                  Container(
                    width: 3,
                    height: 44,
                    decoration: BoxDecoration(
                      color: statusColor,
                      borderRadius: BorderRadius.circular(4),
                      boxShadow: [
                        BoxShadow(
                          color: statusColor.withValues(alpha: 0.5),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          snippet,
                          style: GoogleFonts.dmSans(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                            height: 1.4,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          DateFormat('dd MMM yyyy · HH:mm').format(item.tanggalDeteksi),
                          style: GoogleFonts.dmSans(
                            fontSize: 10.5,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Badge status
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: statusColor.withValues(alpha: 0.25)),
                    ),
                    child: Text(
                      item.prediksiAkhir,
                      style: GoogleFonts.dmSans(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                        color: statusColor,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

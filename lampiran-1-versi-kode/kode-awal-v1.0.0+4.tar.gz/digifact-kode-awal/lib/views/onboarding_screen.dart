import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';
import 'home_screen.dart';

// =============================================================
// DATA MODEL – Slide Onboarding
// =============================================================
class _OnboardSlide {
  final String tag;
  final String title;
  final String description;
  final IconData icon;
  final Color accentColor;
  final List<Color> gradientColors;
  final List<_FeaturePill> pills;

  const _OnboardSlide({
    required this.tag,
    required this.title,
    required this.description,
    required this.icon,
    required this.accentColor,
    required this.gradientColors,
    required this.pills,
  });
}

class _FeaturePill {
  final String label;
  final IconData icon;

  const _FeaturePill(this.label, this.icon);
}

// =============================================================
// ONBOARDING SCREEN
// =============================================================
class OnboardingScreen extends StatefulWidget {
  final StorageService storageService;
  final ApiService apiService;

  const OnboardingScreen({
    super.key,
    required this.storageService,
    required this.apiService,
  });

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  // Animasi per slide
  late AnimationController _slideEntryController;
  late Animation<double> _slideEntryFade;
  late Animation<Offset> _slideEntryOffset;

  // Animasi illustration float
  late AnimationController _floatController;
  late Animation<double> _floatAnim;

  // Animasi orbit background
  late AnimationController _orbitController;

  static final List<_OnboardSlide> _slides = [
    _OnboardSlide(
      tag: 'STEP 01 / 03',
      title: 'Deteksi Hoaks\ndengan AI Cerdas',
      description:
          'DigiFact menggunakan model Machine Learning Random Forest yang dilatih pada ribuan data berita untuk mengklasifikasi informasi secara akurat dan cepat.',
      icon: Icons.psychology_rounded,
      accentColor: AppColors.neonCyan,
      gradientColors: [Color(0xFF003D66), Color(0xFF001A33)],
      pills: [
        _FeaturePill('Random Forest', Icons.account_tree_rounded),
        _FeaturePill('+90% Akurasi Dataset', Icons.verified_rounded),
        _FeaturePill('Analisis Real-time', Icons.bolt_rounded),
      ],
    ),
    _OnboardSlide(
      tag: 'STEP 02 / 03',
      title: 'Hasil Transparan\n& Dapat Dipercaya',
      description:
          'Setiap keputusan AI dijelaskan menggunakan SHAP dan LIME — teknologi Explainable AI yang memetakan kata-kata kunci yang paling berpengaruh pada prediksi.',
      icon: Icons.analytics_rounded,
      accentColor: AppColors.neonGreen,
      gradientColors: [Color(0xFF003322), Color(0xFF001A11)],
      pills: [
        _FeaturePill('Explainable AI', Icons.auto_awesome_rounded),
        _FeaturePill('Analisis SHAP', Icons.bar_chart_rounded),
        _FeaturePill('Interpretasi LIME', Icons.science_rounded),
      ],
    ),
    _OnboardSlide(
      tag: 'STEP 03 / 03',
      title: 'Tingkatkan\nLiterasi Digitalmu',
      description:
          'Simpan riwayat pengecekan, pelajari panduan 5 langkah cek fakta, dan jadilah konsumen informasi yang lebih kritis dan bertanggung jawab.',
      icon: Icons.shield_rounded,
      accentColor: const Color(0xFFFFAA00),
      gradientColors: [Color(0xFF332200), Color(0xFF1A1100)],
      pills: [
        _FeaturePill('Riwayat Tersimpan', Icons.history_rounded),
        _FeaturePill('Panduan Cek Fakta', Icons.menu_book_rounded),
        _FeaturePill('Bagikan Hasil', Icons.ios_share_rounded),
      ],
    ),
  ];

  @override
  void initState() {
    super.initState();

    // Float animation untuk ilustrasi
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: -10, end: 10).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOut),
    );

    // Orbit background
    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    // Entry anim per slide
    _slideEntryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _slideEntryFade = CurvedAnimation(
      parent: _slideEntryController,
      curve: Curves.easeOut,
    );
    _slideEntryOffset = Tween<Offset>(
      begin: const Offset(0.08, 0),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideEntryController, curve: Curves.easeOutCubic),
    );
    _slideEntryController.forward();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _floatController.dispose();
    _orbitController.dispose();
    _slideEntryController.dispose();
    super.dispose();
  }

  void _goToNext() {
    HapticFeedback.selectionClick();
    if (_currentPage < _slides.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _finishOnboarding();
    }
  }

  void _skipOnboarding() {
    HapticFeedback.lightImpact();
    _finishOnboarding();
  }

  Future<void> _finishOnboarding() async {
    await widget.storageService.markOnboardingDone();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (context, animation, _) => HomeScreen(
          apiService: widget.apiService,
          storageService: widget.storageService,
        ),
        transitionsBuilder: (context, animation, _, child) {
          return FadeTransition(
            opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.05),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(parent: animation, curve: Curves.easeOut),
              ),
              child: child,
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final slide = _slides[_currentPage];

    return Scaffold(
      backgroundColor: AppColors.navyDeep,
      body: Stack(
        children: [
          // ── Background orbit animasi ─────────────────────────
          _buildAnimatedBg(slide.accentColor),

          // ── Konten utama ─────────────────────────────────────
          SafeArea(
            child: Column(
              children: [
                // Skip button atas kanan
                _buildTopBar(slide.accentColor),

                // PageView slides
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: (page) {
                      setState(() => _currentPage = page);
                      _slideEntryController.forward(from: 0);
                      HapticFeedback.selectionClick();
                    },
                    itemCount: _slides.length,
                    itemBuilder: (_, index) => _buildSlidePage(_slides[index]),
                  ),
                ),

                // Bottom navigation
                _buildBottomNav(slide),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── ANIMATED BACKGROUND ──────────────────────────────────────
  Widget _buildAnimatedBg(Color accentColor) {
    return AnimatedBuilder(
      animation: _orbitController,
      builder: (context, _) {
        final t = _orbitController.value * 2 * math.pi;
        return Stack(
          children: [
            // Gradient base
            AnimatedContainer(
              duration: const Duration(milliseconds: 600),
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -0.3),
                  radius: 1.0,
                  colors: [
                    accentColor.withValues(alpha: 0.07),
                    AppColors.navyDeep,
                  ],
                ),
              ),
            ),
            // Orb floating kiri
            Positioned(
              top: 80 + 25 * math.sin(t * 0.5),
              left: -60 + 15 * math.cos(t * 0.4),
              child: _bgOrb(220, accentColor, 0.06),
            ),
            // Orb floating kanan bawah
            Positioned(
              bottom: 100 + 20 * math.sin(t * 0.6),
              right: -40 + 12 * math.cos(t * 0.5),
              child: _bgOrb(200, accentColor, 0.04),
            ),
            // Grid dots dekoratif
            Positioned.fill(child: _buildDotGrid(accentColor)),
          ],
        );
      },
    );
  }

  Widget _bgOrb(double size, Color color, double alpha) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withValues(alpha: alpha), Colors.transparent],
        ),
      ),
    );
  }

  Widget _buildDotGrid(Color accentColor) {
    return CustomPaint(
      painter: _DotGridPainter(color: accentColor.withValues(alpha: 0.025)),
    );
  }

  // ── TOP BAR ──────────────────────────────────────────────────
  Widget _buildTopBar(Color accentColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Logo kecil
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFF0D3580), Color(0xFF0A2050)],
                  ),
                  border: Border.all(
                    color: AppColors.neonCyan.withValues(alpha: 0.3),
                  ),
                ),
                child: const Icon(
                  Icons.fact_check_rounded,
                  color: AppColors.neonCyan,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'Digi',
                      style: GoogleFonts.dmSans(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                    TextSpan(
                      text: 'Fact',
                      style: GoogleFonts.dmSans(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppColors.neonCyan,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Skip button
          GestureDetector(
            onTap: _skipOnboarding,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withValues(alpha: 0.10)),
              ),
              child: Text(
                'Lewati',
                style: GoogleFonts.dmSans(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── SLIDE PAGE ───────────────────────────────────────────────
  Widget _buildSlidePage(_OnboardSlide slide) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: SlideTransition(
        position: _slideEntryOffset,
        child: FadeTransition(
          opacity: _slideEntryFade,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Ilustrasi
              _buildIllustration(slide),
              const SizedBox(height: 36),

              // Tag step
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: slide.accentColor.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: slide.accentColor.withValues(alpha: 0.25),
                  ),
                ),
                child: Text(
                  slide.tag,
                  style: GoogleFonts.dmSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: slide.accentColor,
                    letterSpacing: 1.0,
                  ),
                ),
              ),
              const SizedBox(height: 18),

              // Judul
              Text(
                slide.title,
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  height: 1.2,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 14),

              // Deskripsi
              Text(
                slide.description,
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(
                  fontSize: 14,
                  color: AppColors.textSecondary,
                  height: 1.65,
                ),
              ),
              const SizedBox(height: 28),

              // Feature pills
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: slide.pills.map((pill) {
                  return Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 7,
                    ),
                    decoration: BoxDecoration(
                      color: slide.accentColor.withValues(alpha: 0.07),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: slide.accentColor.withValues(alpha: 0.18),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(pill.icon, color: slide.accentColor, size: 13),
                        const SizedBox(width: 6),
                        Text(
                          pill.label,
                          style: GoogleFonts.dmSans(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: slide.accentColor.withValues(alpha: 0.9),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── ILUSTRASI (Animated) ─────────────────────────────────────
  Widget _buildIllustration(_OnboardSlide slide) {
    return AnimatedBuilder(
      animation: _floatAnim,
      builder: (context, _) {
        return Transform.translate(
          offset: Offset(0, _floatAnim.value),
          child: SizedBox(
            height: 200,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer decorative ring
                AnimatedBuilder(
                  animation: _orbitController,
                  builder: (context, _) {
                    return Transform.rotate(
                      angle: _orbitController.value * 2 * math.pi,
                      child: SizedBox(
                        width: 190,
                        height: 190,
                        child: CustomPaint(
                          painter: _DashedRingPainter(
                            color: slide.accentColor.withValues(alpha: 0.15),
                          ),
                        ),
                      ),
                    );
                  },
                ),

                // Glow background circle
                Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        slide.accentColor.withValues(alpha: 0.15),
                        slide.accentColor.withValues(alpha: 0),
                      ],
                    ),
                  ),
                ),

                // Main icon container
                Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: slide.gradientColors,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(
                      color: slide.accentColor.withValues(alpha: 0.30),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: slide.accentColor.withValues(alpha: 0.25),
                        blurRadius: 32,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                  child: Center(
                    child: ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [slide.accentColor, Colors.white],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: Icon(slide.icon, size: 46, color: Colors.white),
                    ),
                  ),
                ),

                // Orbit mini-dots
                AnimatedBuilder(
                  animation: _orbitController,
                  builder: (context, _) {
                    return SizedBox(
                      width: 190,
                      height: 190,
                      child: CustomPaint(
                        painter: _MiniOrbitDotsPainter(
                          progress: _orbitController.value,
                          color: slide.accentColor,
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── BOTTOM NAV ───────────────────────────────────────────────
  Widget _buildBottomNav(_OnboardSlide slide) {
    final isLast = _currentPage == _slides.length - 1;

    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 0, 28, 36),
      child: Column(
        children: [
          // Dot indicators
          _buildDotIndicators(slide.accentColor),
          const SizedBox(height: 28),

          // Tombol utama
          GestureDetector(
            onTap: _goToNext,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: double.infinity,
              height: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppRadius.md),
                gradient: LinearGradient(
                  colors: isLast
                      ? [AppColors.neonGreen, const Color(0xFF00AA22)]
                      : [const Color(0xFF0077FF), AppColors.neonCyan],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: (isLast ? AppColors.neonGreen : AppColors.neonCyan)
                        .withValues(alpha: 0.30),
                    blurRadius: 18,
                    spreadRadius: -2,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    isLast ? 'Mulai Menggunakan DigiFact' : 'Lanjutkan',
                    style: GoogleFonts.dmSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: isLast ? AppColors.navyDeep : Colors.white,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    isLast ? Icons.rocket_launch_rounded : Icons.arrow_forward_rounded,
                    color: isLast ? AppColors.navyDeep : Colors.white,
                    size: 18,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDotIndicators(Color accentColor) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_slides.length, (index) {
        final isActive = index == _currentPage;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: isActive ? 28 : 8,
          height: 8,
          decoration: BoxDecoration(
            color: isActive
                ? accentColor
                : Colors.white.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(4),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: accentColor.withValues(alpha: 0.4),
                      blurRadius: 8,
                    ),
                  ]
                : [],
          ),
        );
      }),
    );
  }
}

// =============================================================
// CUSTOM PAINTERS
// =============================================================

/// Grid titik-titik dekoratif di background
class _DotGridPainter extends CustomPainter {
  final Color color;
  _DotGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    const spacing = 28.0;
    const radius = 1.2;

    for (double x = spacing; x < size.width; x += spacing) {
      for (double y = spacing; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_DotGridPainter old) => old.color != color;
}

/// Ring putus-putus (dashed) sebagai dekorasi orbit ilustrasi
class _DashedRingPainter extends CustomPainter {
  final Color color;
  _DashedRingPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 2;
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    const dashCount = 24;
    const dashAngle = (2 * math.pi) / dashCount;
    const gapFraction = 0.35;

    for (int i = 0; i < dashCount; i++) {
      final startAngle = i * dashAngle;
      final sweepAngle = dashAngle * (1 - gapFraction);
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_DashedRingPainter old) => old.color != color;
}

/// Tiga mini-dots yang mengorbit di sekitar ilustrasi
class _MiniOrbitDotsPainter extends CustomPainter {
  final double progress;
  final Color color;

  _MiniOrbitDotsPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 2;

    const dotCount = 3;
    for (int i = 0; i < dotCount; i++) {
      final angle = (progress + i / dotCount) * 2 * math.pi;
      final x = center.dx + radius * math.cos(angle);
      final y = center.dy + radius * math.sin(angle);

      // Glow
      canvas.drawCircle(
        Offset(x, y),
        6,
        Paint()
          ..color = color.withValues(alpha: 0.15)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      // Dot
      canvas.drawCircle(
        Offset(x, y),
        3.5,
        Paint()..color = color.withValues(alpha: 0.85),
      );
    }
  }

  @override
  bool shouldRepaint(_MiniOrbitDotsPainter old) =>
      old.progress != progress || old.color != color;
}

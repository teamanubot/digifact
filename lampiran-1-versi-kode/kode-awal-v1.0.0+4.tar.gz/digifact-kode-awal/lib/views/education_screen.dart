import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'home_screen.dart' show AppColors, AppRadius;

// =============================================================
// EDUCATION SCREEN – Literasi Digital
// =============================================================
class EducationScreen extends StatelessWidget {
  const EducationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tips = [
      {
        'step': '01',
        'title': 'Cermati Alamat URL Situs',
        'desc':
            'Informasi dari situs resmi media massa nasional atau lembaga kredibel umumnya terpercaya. Waspadai domain tidak lazim (.blogspot, .wordpress, atau nama aneh).',
        'icon': Icons.language_rounded,
        'color': AppColors.neonCyan,
      },
      {
        'step': '02',
        'title': 'Periksa Beberapa Sumber',
        'desc':
            'Jika berita benar, media arus utama lain juga memberitakannya. Bandingkan di situs tepercaya atau cek di Mafindo (turnbackhoax.id) dan cekfakta.com.',
        'icon': Icons.compare_arrows_rounded,
        'color': const Color(0xFF818CF8),
      },
      {
        'step': '03',
        'title': 'Waspadai Judul Provokatif',
        'desc':
            'Hoaks sering menggunakan judul bombastis dan sensasional untuk memicu emosi. Kalimatnya cenderung subjektif, menuding pihak tertentu, dan tidak netral.',
        'icon': Icons.warning_amber_rounded,
        'color': const Color(0xFFFFAA00),
      },
      {
        'step': '04',
        'title': 'Periksa Keaslian Foto & Video',
        'desc':
            'Hoaks sering menggunakan media lama yang dipotong atau dimanipulasi. Gunakan Google Reverse Image Search untuk memeriksa asal-usul foto.',
        'icon': Icons.image_search_rounded,
        'color': AppColors.neonGreen,
      },
      {
        'step': '05',
        'title': 'Perhatikan Tanggal & Konteks',
        'desc':
            'Banyak hoaks adalah berita lama yang didaur ulang. Kejadian nyata di masa lalu disebarkan kembali dengan konteks berbeda seolah terjadi hari ini.',
        'icon': Icons.calendar_today_rounded,
        'color': const Color(0xFF94A3B8),
      },
    ];

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navyDeep,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(AppRadius.sm),
              border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'Literasi Digital',
          style: GoogleFonts.dmSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: AppColors.borderSubtle.withValues(alpha: 0.5),
          ),
        ),
      ),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Hero Banner ──────────────────────────────
                  _buildHeroBanner(),
                  const SizedBox(height: 28),

                  // ── Stats Row ────────────────────────────────
                  _buildStatsRow(),
                  const SizedBox(height: 28),

                  // ── Steps header ─────────────────────────────
                  Text(
                    'Panduan 5 Langkah Cek Fakta',
                    style: GoogleFonts.dmSans(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Ikuti langkah-langkah ini sebelum menyebarkan informasi.',
                    style: GoogleFonts.dmSans(
                      fontSize: 12.5,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 18),

                  // ── Step cards ───────────────────────────────
                  ...tips.asMap().entries.map(
                    (entry) => _buildStepCard(entry.value, entry.key, tips.length),
                  ),

                  const SizedBox(height: 24),

                  // ── Quote block ──────────────────────────────
                  _buildQuoteBlock(),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0D2550), Color(0xFF0A1F44)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.neonCyan.withValues(alpha: 0.15)),
        boxShadow: [
          BoxShadow(
            color: AppColors.neonCyan.withValues(alpha: 0.06),
            blurRadius: 24,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.neonCyan.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                  border: Border.all(color: AppColors.neonCyan.withValues(alpha: 0.2)),
                ),
                child: const Icon(Icons.psychology_rounded, color: AppColors.neonCyan, size: 22),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PANDUAN LITERASI',
                    style: GoogleFonts.dmSans(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: AppColors.neonCyan,
                      letterSpacing: 1.5,
                    ),
                  ),
                  Text(
                    'Anti-Hoaks 101',
                    style: GoogleFonts.dmSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 18),
          Text(
            'Saring\nSebelum\nSharing.',
            style: GoogleFonts.dmSans(
              fontSize: 32,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: -1.0,
              height: 1.15,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Sebelum menyebarkan berita, luangkan 60 detik untuk memverifikasi kebenarannya. Gunakan panduan di bawah ini untuk melatih kepekaan logika Anda terhadap informasi digital.',
            style: GoogleFonts.dmSans(
              fontSize: 13,
              color: AppColors.textSecondary,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    final stats = [
      {'val': '60%', 'label': 'Konten di media\nsosial adalah hoaks', 'color': AppColors.neonRed},
      {'val': '6×', 'label': 'Hoaks menyebar lebih\ncepat dari fakta', 'color': const Color(0xFFFFAA00)},
      {'val': '1 min', 'label': 'Waktu verifikasi\nyang Anda butuhkan', 'color': AppColors.neonGreen},
    ];

    return Row(
      children: stats.map((s) {
        final color = s['color'] as Color;
        return Expanded(
          child: Container(
            margin: EdgeInsets.only(
              left: stats.indexOf(s) == 0 ? 0 : 7,
              right: stats.indexOf(s) == stats.length - 1 ? 0 : 7,
            ),
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: color.withValues(alpha: 0.15)),
            ),
            child: Column(
              children: [
                Text(
                  s['val'] as String,
                  style: GoogleFonts.dmSans(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  s['label'] as String,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.dmSans(
                    fontSize: 10,
                    color: AppColors.textSecondary,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildStepCard(
    Map<String, dynamic> tip,
    int index,
    int total,
  ) {
    final color = tip['color'] as Color;
    final isLast = index == total - 1;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Timeline connector kiri
        Column(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.10),
                shape: BoxShape.circle,
                border: Border.all(color: color.withValues(alpha: 0.25)),
              ),
              child: Center(
                child: Text(
                  tip['step'] as String,
                  style: GoogleFonts.dmSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
              ),
            ),
            if (!isLast)
              Container(
                width: 1.5,
                height: 70,
                color: AppColors.borderSubtle,
              ),
          ],
        ),
        const SizedBox(width: 16),

        // Konten card
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: isLast ? 0 : 16),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppColors.navyCard,
                borderRadius: BorderRadius.circular(AppRadius.lg),
                border: Border.all(color: AppColors.borderSubtle),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(9),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(AppRadius.xs),
                      border: Border.all(color: color.withValues(alpha: 0.18)),
                    ),
                    child: Icon(tip['icon'] as IconData, color: color, size: 20),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tip['title'] as String,
                          style: GoogleFonts.dmSans(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          tip['desc'] as String,
                          style: GoogleFonts.dmSans(
                            fontSize: 12.5,
                            color: AppColors.textSecondary,
                            height: 1.55,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuoteBlock() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        children: [
          Icon(
            Icons.format_quote_rounded,
            color: AppColors.neonCyan.withValues(alpha: 0.4),
            size: 32,
          ),
          const SizedBox(height: 12),
          Text(
            '"Kebenaran tidak akan pernah merugikan tujuan yang adil."',
            textAlign: TextAlign.center,
            style: GoogleFonts.dmSans(
              fontSize: 14.5,
              fontStyle: FontStyle.italic,
              color: Colors.white,
              height: 1.6,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            '— Mahatma Gandhi',
            style: GoogleFonts.dmSans(
              fontSize: 12,
              color: AppColors.neonCyan,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

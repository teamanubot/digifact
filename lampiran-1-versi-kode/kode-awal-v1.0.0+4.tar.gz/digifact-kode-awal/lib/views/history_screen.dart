import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/detection_result.dart';
import '../services/storage_service.dart';
import 'home_screen.dart' show AppColors, AppRadius;
import 'result_screen.dart';

// =============================================================
// HISTORY SCREEN
// =============================================================
class HistoryScreen extends StatefulWidget {
  final StorageService storageService;

  const HistoryScreen({super.key, required this.storageService});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen>
    with SingleTickerProviderStateMixin {
  List<DetectionResult> _history = [];
  late AnimationController _entryController;

  @override
  void initState() {
    super.initState();
    _loadHistory();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..forward();
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  void _loadHistory() {
    setState(() => _history = widget.storageService.getHistory());
  }

  Future<void> _deleteItem(String id) async {
    HapticFeedback.mediumImpact();
    await widget.storageService.deleteResult(id);
    _loadHistory();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.delete_outline_rounded, color: AppColors.neonRed, size: 16),
              const SizedBox(width: 10),
              Text(
                'Riwayat berhasil dihapus',
                style: GoogleFonts.dmSans(color: Colors.white, fontSize: 13),
              ),
            ],
          ),
        ),
      );
    }
  }

  Future<void> _clearAllHistory() async {
    HapticFeedback.heavyImpact();
    await widget.storageService.clearHistory();
    _loadHistory();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.delete_sweep_rounded, color: AppColors.neonRed, size: 16),
              const SizedBox(width: 10),
              Text(
                'Semua riwayat telah dibersihkan',
                style: GoogleFonts.dmSans(color: Colors.white, fontSize: 13),
              ),
            ],
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: _buildAppBar(),
      body: _history.isEmpty ? _buildEmptyState() : _buildHistoryList(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.navyDeep,
      elevation: 0,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(AppRadius.sm),
            border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
          ),
          child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
        ),
        onPressed: () => Navigator.of(context).pop(),
      ),
      title: Column(
        children: [
          Text(
            'Riwayat Pengecekan',
            style: GoogleFonts.dmSans(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          if (_history.isNotEmpty)
            Text(
              '${_history.length} pencarian tersimpan',
              style: GoogleFonts.dmSans(
                fontSize: 11,
                color: AppColors.textSecondary,
              ),
            ),
        ],
      ),
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          color: AppColors.borderSubtle.withValues(alpha: 0.5),
        ),
      ),
      actions: [
        if (_history.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.delete_sweep_rounded, color: AppColors.neonRed, size: 22),
            onPressed: _showClearDialog,
            tooltip: 'Hapus semua',
          ),
        const SizedBox(width: 4),
      ],
    );
  }

  void _showClearDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: AppColors.navyMid,
            borderRadius: BorderRadius.circular(AppRadius.xl),
            border: Border.all(color: AppColors.neonRed.withValues(alpha: 0.25)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.neonRed.withValues(alpha: 0.08),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.neonRed.withValues(alpha: 0.2)),
                ),
                child: const Icon(Icons.delete_forever_rounded, color: AppColors.neonRed, size: 26),
              ),
              const SizedBox(height: 16),
              Text(
                'Hapus Semua Riwayat?',
                style: GoogleFonts.dmSans(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Tindakan ini akan menghapus seluruh data pencarian berita yang tersimpan secara lokal dan tidak dapat dikembalikan.',
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  color: AppColors.textSecondary,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        backgroundColor: Colors.white.withValues(alpha: 0.04),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppRadius.md),
                          side: BorderSide(color: Colors.white.withValues(alpha: 0.1)),
                        ),
                      ),
                      child: Text(
                        'Batal',
                        style: GoogleFonts.dmSans(
                          fontWeight: FontWeight.w600,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _clearAllHistory();
                      },
                      style: TextButton.styleFrom(
                        backgroundColor: AppColors.neonRed.withValues(alpha: 0.12),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppRadius.md),
                          side: BorderSide(color: AppColors.neonRed.withValues(alpha: 0.35)),
                        ),
                      ),
                      child: Text(
                        'Hapus',
                        style: GoogleFonts.dmSans(
                          fontWeight: FontWeight.w700,
                          color: AppColors.neonRed,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: FadeTransition(
        opacity: _entryController,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: AppColors.navyCard,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.borderSubtle),
              ),
              child: const Icon(
                Icons.history_toggle_off_rounded,
                size: 48,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 22),
            Text(
              'Belum Ada Riwayat',
              style: GoogleFonts.dmSans(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 50),
              child: Text(
                'Hasil deteksi berita akan otomatis tersimpan setelah Anda melakukan analisis.',
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  color: AppColors.textSecondary,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryList() {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      itemCount: _history.length,
      itemBuilder: (_, index) {
        final item = _history[index];
        final isFakta = item.prediksiAkhir == 'Fakta';
        final isHoaks = item.prediksiAkhir == 'Hoaks';
        final statusColor = isFakta
            ? AppColors.neonGreen
            : isHoaks
                ? AppColors.neonRed
                : const Color(0xFFFFAA00);

        final textSnippet = item.teksAsli.length > 90
            ? '${item.teksAsli.substring(0, 90).replaceAll('\n', ' ')}...'
            : item.teksAsli.replaceAll('\n', ' ');

        return Dismissible(
          key: Key(item.id),
          direction: DismissDirection.endToStart,
          onDismissed: (_) => _deleteItem(item.id),
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              color: AppColors.neonRed.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(AppRadius.lg),
              border: Border.all(color: AppColors.neonRed.withValues(alpha: 0.25)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.delete_outline_rounded, color: AppColors.neonRed, size: 24),
                const SizedBox(height: 4),
                Text(
                  'Hapus',
                  style: GoogleFonts.dmSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: AppColors.neonRed,
                  ),
                ),
              ],
            ),
          ),
          child: Container(
            margin: const EdgeInsets.only(bottom: 14),
            decoration: BoxDecoration(
              color: AppColors.navyCard,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              border: Border.all(color: AppColors.borderSubtle),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.lg),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ResultScreen(
                          result: item,
                          storageService: widget.storageService,
                          isSaved: true,
                        ),
                      ),
                    );
                    _loadHistory();
                  },
                  splashColor: statusColor.withValues(alpha: 0.05),
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Baris atas: tanggal + badge
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.access_time_rounded, size: 12, color: AppColors.textSecondary),
                                const SizedBox(width: 5),
                                Text(
                                  DateFormat('dd MMM yyyy · HH:mm').format(item.tanggalDeteksi),
                                  style: GoogleFonts.dmSans(
                                    fontSize: 11,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: statusColor.withValues(alpha: 0.10),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: statusColor.withValues(alpha: 0.25)),
                              ),
                              child: Text(
                                item.prediksiAkhir,
                                style: GoogleFonts.dmSans(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700,
                                  color: statusColor,
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        // Cuplikan teks
                        Text(
                          textSnippet,
                          style: GoogleFonts.dmSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                            height: 1.45,
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Progress bar duo
                        Row(
                          children: [
                            Expanded(
                              child: _buildMiniBar(
                                'Fakta',
                                item.probabilitasFakta,
                                AppColors.neonGreen,
                              ),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: _buildMiniBar(
                                'Hoaks',
                                item.probabilitasHoaks,
                                AppColors.neonRed,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildMiniBar(String label, double value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: GoogleFonts.dmSans(fontSize: 10.5, color: AppColors.textSecondary)),
            Text(
              '${(value * 100).toStringAsFixed(1)}%',
              style: GoogleFonts.dmSans(fontSize: 11, fontWeight: FontWeight.w700, color: color),
            ),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: value,
            backgroundColor: AppColors.navyElevated,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 5,
          ),
        ),
      ],
    );
  }
}

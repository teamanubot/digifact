import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/detection_result.dart';
import '../services/storage_service.dart';
import 'home_screen.dart' show AppColors, AppRadius;

// =============================================================
// RESULT SCREEN – Design Sistem Premium
// =============================================================
class ResultScreen extends StatefulWidget {
  final DetectionResult result;
  final StorageService storageService;
  final bool isSaved;

  const ResultScreen({
    super.key,
    required this.result,
    required this.storageService,
    this.isSaved = false,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  late bool _isSavedLocally;

  // Animasi gauge
  late AnimationController _gaugeController;
  late Animation<double> _gaugeAnimation;

  // Animasi entry
  late AnimationController _entryController;
  late Animation<double> _entryFade;
  late Animation<Offset> _entrySlide;

  // Animasi pulse badge
  late AnimationController _badgePulse;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _isSavedLocally = widget.isSaved;

    // Gauge animasi masuk – dari 0 ke nilai aktual
    _gaugeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    final double targetScore = _getConfidenceScore();
    _gaugeAnimation = Tween<double>(begin: 0, end: targetScore).animate(
      CurvedAnimation(parent: _gaugeController, curve: Curves.easeOutCubic),
    );

    // Entry fade + slide
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _entryFade = CurvedAnimation(parent: _entryController, curve: Curves.easeOut);
    _entrySlide = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryController, curve: Curves.easeOut));

    // Badge pulse
    _badgePulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    // Mulai semua animasi
    _entryController.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _gaugeController.forward();
    });

    // Haptic feedback berdasarkan hasil
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) {
        if (widget.result.prediksiAkhir == 'Fakta') {
          HapticFeedback.lightImpact();
        } else if (widget.result.prediksiAkhir == 'Hoaks') {
          HapticFeedback.heavyImpact();
        }
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _gaugeController.dispose();
    _entryController.dispose();
    _badgePulse.dispose();
    super.dispose();
  }

  double _getConfidenceScore() {
    if (widget.result.prediksiAkhir == 'Fakta') {
      return widget.result.probabilitasFakta;
    } else if (widget.result.prediksiAkhir == 'Hoaks') {
      return widget.result.probabilitasHoaks;
    }
    return 0.5;
  }

  // Properti warna berdasarkan prediksi
  Color get _statusColor {
    if (widget.result.prediksiAkhir == 'Fakta') return AppColors.neonGreen;
    if (widget.result.prediksiAkhir == 'Hoaks') return AppColors.neonRed;
    return const Color(0xFFFFAA00);
  }

  IconData get _statusIcon {
    if (widget.result.prediksiAkhir == 'Fakta') return Icons.verified_rounded;
    if (widget.result.prediksiAkhir == 'Hoaks') return Icons.gpp_bad_rounded;
    return Icons.help_outline_rounded;
  }

  String get _headerLabel {
    if (widget.result.prediksiAkhir == 'Fakta') return 'INFORMASI FAKTA';
    if (widget.result.prediksiAkhir == 'Hoaks') return 'INDIKASI HOAKS';
    return 'PERLU VERIFIKASI';
  }

  String get _subtitle {
    if (widget.result.prediksiAkhir == 'Fakta') {
      return 'Sesuai dengan struktur jurnalisme valid dan sumber berita yang dapat diverifikasi.';
    }
    if (widget.result.prediksiAkhir == 'Hoaks') {
      return 'Memiliki kemiripan tinggi dengan pola penyebaran informasi yang tidak valid.';
    }
    return 'Tingkat keyakinan model rendah. Disarankan verifikasi manual dari sumber terpercaya.';
  }

  List<Color> get _gaugeGradient {
    if (widget.result.prediksiAkhir == 'Fakta') {
      return [const Color(0xFF00FF88), AppColors.neonGreen];
    }
    if (widget.result.prediksiAkhir == 'Hoaks') {
      return [const Color(0xFFFF6B6B), AppColors.neonRed];
    }
    return [const Color(0xFFFFD700), const Color(0xFFFFAA00)];
  }

  Future<void> _toggleSaveStatus() async {
    HapticFeedback.selectionClick();
    if (_isSavedLocally) {
      await widget.storageService.deleteResult(widget.result.id);
      setState(() => _isSavedLocally = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.bookmark_remove_outlined, color: AppColors.neonRed, size: 16),
                const SizedBox(width: 10),
                Text('Dihapus dari riwayat', style: GoogleFonts.dmSans(color: Colors.white)),
              ],
            ),
          ),
        );
      }
    } else {
      await widget.storageService.saveResult(widget.result);
      setState(() => _isSavedLocally = true);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.bookmark_added_rounded, color: AppColors.neonGreen, size: 16),
                const SizedBox(width: 10),
                Text('Berhasil disimpan ke riwayat', style: GoogleFonts.dmSans(color: Colors.white)),
              ],
            ),
          ),
        );
      }
    }
  }

  void _shareResult() {
    final status = widget.result.prediksiAkhir;
    final probFakta = (widget.result.probabilitasFakta * 100).toStringAsFixed(1);
    final probHoaks = (widget.result.probabilitasHoaks * 100).toStringAsFixed(1);
    final text =
        '🕵️ *DigiFact – Deteksi Berita AI*\n\n'
        '🏷️ Klasifikasi: *$status*\n'
        '✅ Probabilitas Fakta: $probFakta%\n'
        '❌ Probabilitas Hoaks: $probHoaks%\n\n'
        '🤖 *Analisis AI:*\n${widget.result.analisisDetail}\n\n'
        '—\nDeteksi berita menggunakan *DigiFact* sekarang!';
    Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.copy_rounded, color: AppColors.neonCyan, size: 16),
            const SizedBox(width: 10),
            Text('Laporan disalin ke clipboard!', style: GoogleFonts.dmSans(color: Colors.white)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          // Glow radial berdasarkan status
          _buildRadialGlow(),

          FadeTransition(
            opacity: _entryFade,
            child: SlideTransition(
              position: _entrySlide,
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 100, 20, 40),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 1. Hero verdict card
                          _buildVerdictCard(),
                          const SizedBox(height: 22),

                          // 2. Confidence circular gauge
                          _buildGaugeCard(),
                          const SizedBox(height: 22),

                          // 3. Teks sumber
                          _buildSourceCard(),
                          const SizedBox(height: 22),

                          // 4. Interpretasi AI
                          _buildAiAnalysisCard(),
                          const SizedBox(height: 22),

                          // 5. XAI – SHAP & LIME
                          _buildXaiSectionHeader(),
                          const SizedBox(height: 14),
                          _buildXaiTabs(),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── APP BAR ──────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.navyDeep.withValues(alpha: 0.6),
              border: Border(
                bottom: BorderSide(color: AppColors.borderSubtle.withValues(alpha: 0.5)),
              ),
            ),
          ),
        ),
      ),
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(AppRadius.sm),
            border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
          ),
          child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 16),
        ),
        onPressed: () => Navigator.of(context).pop(),
      ),
      title: Text(
        'Hasil Analisis AI',
        style: GoogleFonts.dmSans(
          fontSize: 17,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          icon: AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: child),
            child: Icon(
              _isSavedLocally ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
              key: ValueKey(_isSavedLocally),
              color: _isSavedLocally ? _statusColor : Colors.white,
              size: 22,
            ),
          ),
          onPressed: _toggleSaveStatus,
        ),
        IconButton(
          icon: const Icon(Icons.ios_share_rounded, color: Colors.white, size: 20),
          onPressed: _shareResult,
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ── RADIAL GLOW ──────────────────────────────────────────────
  Widget _buildRadialGlow() {
    return Positioned(
      top: 20,
      left: MediaQuery.of(context).size.width / 2 - 180,
      child: Container(
        width: 360,
        height: 360,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              _statusColor.withValues(alpha: 0.12),
              _statusColor.withValues(alpha: 0),
            ],
          ),
        ),
      ),
    );
  }

  // ── VERDICT CARD ─────────────────────────────────────────────
  Widget _buildVerdictCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.xl),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
          decoration: BoxDecoration(
            color: _statusColor.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(AppRadius.xl),
            border: Border.all(
              color: _statusColor.withValues(alpha: 0.25),
              width: 1.5,
            ),
          ),
          child: Column(
            children: [
              // Icon dengan pulse ring
              AnimatedBuilder(
                animation: _badgePulse,
                builder: (_, child) {
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      // Outer pulse ring
                      Container(
                        width: 80 + 8 * _badgePulse.value,
                        height: 80 + 8 * _badgePulse.value,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _statusColor.withValues(
                            alpha: 0.06 * (1 - _badgePulse.value),
                          ),
                        ),
                      ),
                      // Inner icon container
                      Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _statusColor.withValues(alpha: 0.10),
                          border: Border.all(
                            color: _statusColor.withValues(alpha: 0.30),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _statusColor.withValues(alpha: 0.25 * _badgePulse.value),
                              blurRadius: 20,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: Icon(_statusIcon, color: _statusColor, size: 32),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),

              // Label FAKTA / HOAKS
              Text(
                _headerLabel,
                style: GoogleFonts.dmSans(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: _statusColor,
                  letterSpacing: 2.0,
                ),
              ),
              const SizedBox(height: 10),

              // Divider tipis
              Container(
                width: 60,
                height: 1.5,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      _statusColor.withValues(alpha: 0.5),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),

              Text(
                _subtitle,
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(
                  fontSize: 13,
                  color: AppColors.textSecondary,
                  height: 1.55,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── CIRCULAR GAUGE CARD ──────────────────────────────────────
  Widget _buildGaugeCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.radar_rounded, color: AppColors.neonCyan, size: 16),
              const SizedBox(width: 8),
              Text(
                'Confidence Score',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),

          // Animated Circular Gauge
          AnimatedBuilder(
            animation: _gaugeAnimation,
            builder: (_, _) {
              return Center(
                child: SizedBox(
                  width: 200,
                  height: 200,
                  child: CustomPaint(
                    painter: _AdvancedGaugePainter(
                      value: _gaugeAnimation.value,
                      gradientColors: _gaugeGradient,
                      statusColor: _statusColor,
                      trackColor: AppColors.navyElevated,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${(_gaugeAnimation.value * 100).toStringAsFixed(1)}%',
                          style: GoogleFonts.dmSans(
                            fontSize: 36,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            letterSpacing: -1.0,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          widget.result.prediksiAkhir.toUpperCase(),
                          style: GoogleFonts.dmSans(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: _statusColor,
                            letterSpacing: 2.0,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: _statusColor.withValues(alpha: 0.10),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            _getConfidenceLabelText(_gaugeAnimation.value),
                            style: GoogleFonts.dmSans(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: _statusColor.withValues(alpha: 0.85),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 28),

          // Dua bar indikator bawah
          Row(
            children: [
              Expanded(
                child: _buildProbBar(
                  label: 'Probabilitas Fakta',
                  value: widget.result.probabilitasFakta,
                  color: AppColors.neonGreen,
                  icon: Icons.check_circle_outline_rounded,
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: _buildProbBar(
                  label: 'Probabilitas Hoaks',
                  value: widget.result.probabilitasHoaks,
                  color: AppColors.neonRed,
                  icon: Icons.cancel_outlined,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getConfidenceLabelText(double val) {
    if (val >= 0.85) return 'Sangat Yakin';
    if (val >= 0.70) return 'Cukup Yakin';
    if (val >= 0.55) return 'Sedikit Yakin';
    return 'Tidak Pasti';
  }

  Widget _buildProbBar({
    required String label,
    required double value,
    required Color color,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 5),
            Expanded(
              child: Text(
                label,
                style: GoogleFonts.dmSans(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w500,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: value,
                  backgroundColor: AppColors.navyElevated,
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                  minHeight: 6,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '${(value * 100).toStringAsFixed(1)}%',
              style: GoogleFonts.dmSans(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ── SOURCE TEXT CARD ─────────────────────────────────────────
  Widget _buildSourceCard() {
    final isExpanded = ValueNotifier<bool>(false);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.article_outlined, color: AppColors.neonCyan, size: 16),
              const SizedBox(width: 8),
              Text(
                'Teks Sumber',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.navyDeep.withValues(alpha: 0.8),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.borderSubtle.withValues(alpha: 0.5)),
            ),
            child: ValueListenableBuilder<bool>(
              valueListenable: isExpanded,
              builder: (context, expanded, _) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.result.teksAsli,
                      maxLines: expanded ? null : 4,
                      overflow: expanded ? TextOverflow.visible : TextOverflow.ellipsis,
                      style: GoogleFonts.dmSans(
                        fontSize: 13,
                        color: AppColors.textSecondary,
                        height: 1.6,
                      ),
                    ),
                    if (!expanded && widget.result.teksAsli.length > 200) ...[
                      const SizedBox(height: 10),
                      GestureDetector(
                        onTap: () => isExpanded.value = true,
                        child: Text(
                          'Tampilkan selengkapnya...',
                          style: GoogleFonts.dmSans(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppColors.neonCyan,
                          ),
                        ),
                      ),
                    ],
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ── AI ANALYSIS CARD ─────────────────────────────────────────
  Widget _buildAiAnalysisCard() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.neonCyan.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(AppRadius.xs),
                  border: Border.all(color: AppColors.neonCyan.withValues(alpha: 0.2)),
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: AppColors.neonCyan, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                'Interpretasi Logika AI',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.neonCyan.withValues(alpha: 0.04),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.neonCyan.withValues(alpha: 0.10)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.format_quote_rounded,
                  color: AppColors.neonCyan.withValues(alpha: 0.4),
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    widget.result.analisisDetail,
                    style: GoogleFonts.dmSans(
                      fontSize: 13.5,
                      color: const Color(0xFFCDD5E0),
                      height: 1.65,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── XAI SECTION ──────────────────────────────────────────────
  Widget _buildXaiSectionHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Kontribusi Kata Kunci',
          style: GoogleFonts.dmSans(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Analisis kata kunci yang memengaruhi keputusan AI dalam menentukan kebenaran berita.',
          style: GoogleFonts.dmSans(
            fontSize: 12.5,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.navyCard,
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(color: AppColors.borderSubtle),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.info_outline_rounded, color: AppColors.neonCyan, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'Cara Membaca Analisis:',
                    style: GoogleFonts.dmSans(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'AI kami memecah berita dan menilai pengaruh setiap kata secara detail:',
                style: GoogleFonts.dmSans(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: const BoxDecoration(
                      color: AppColors.neonGreen,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Hijau: Kata yang meyakinkan AI bahwa berita ini adalah FAKTA.',
                      style: GoogleFonts.dmSans(fontSize: 11.5, color: Colors.white70),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: const BoxDecoration(
                      color: AppColors.neonRed,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Merah: Kata yang membuat AI mencurigai berita ini sebagai HOAKS.',
                      style: GoogleFonts.dmSans(fontSize: 11.5, color: Colors.white70),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Semakin panjang indikator persentase (%), semakin kuat pengaruh kata tersebut terhadap keputusan AI.',
                style: GoogleFonts.dmSans(
                  fontSize: 11,
                  fontStyle: FontStyle.italic,
                  color: AppColors.textMuted,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildXaiTabs() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.navyCard,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Container(
              height: 52,
              decoration: BoxDecoration(
                color: AppColors.navy.withValues(alpha: 0.6),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: AppColors.borderSubtle.withValues(alpha: 0.5)),
              ),
              child: AnimatedBuilder(
                animation: _tabController.animation!,
                builder: (context, _) {
                  final progress = _tabController.animation!.value;
                  return Stack(
                    children: [
                      // Indikator geser (Sliding Indicator)
                      AnimatedAlign(
                        duration: const Duration(milliseconds: 100),
                        alignment: Alignment(progress * 2.0 - 1.0, 0.0),
                        child: FractionallySizedBox(
                          widthFactor: 0.5,
                          child: Container(
                            margin: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [AppColors.neonCyan, AppColors.neonBlue],
                              ),
                              borderRadius: BorderRadius.circular(26),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.neonCyan.withValues(alpha: 0.35),
                                  blurRadius: 10,
                                  spreadRadius: -2,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      // Tombol Segment
                      Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () {
                                HapticFeedback.selectionClick();
                                _tabController.animateTo(0);
                              },
                              child: Center(
                                child: Text(
                                  'Kata Kunci Utama\n(SHAP)',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2,
                                    color: progress < 0.5 ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () {
                                HapticFeedback.selectionClick();
                                _tabController.animateTo(1);
                              },
                              child: Center(
                                child: Text(
                                  'Kata Kunci Spesifik\n(LIME)',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2,
                                    color: progress >= 0.5 ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
          SizedBox(
            height: 300,
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildXaiList(widget.result.penjelasanShap),
                _buildXaiList(widget.result.penjelasanLime),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildXaiList(List<WordWeight> words) {
    if (words.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.data_array_rounded, color: AppColors.textMuted, size: 30),
            const SizedBox(height: 10),
            Text(
              'Tidak ada data kata kunci.',
              style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.textSecondary),
            ),
          ],
        ),
      );
    }

    double sumVal = 0.0;
    for (var w in words) {
      sumVal += w.bobot.abs();
    }
    if (sumVal == 0.0) sumVal = 1.0;

    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      itemCount: words.length,
      itemBuilder: (_, i) {
        final item = words[i];
        final isHoaxDriver = item.bobot > 0;
        final barColor = isHoaxDriver ? AppColors.neonRed : AppColors.neonGreen;
        final contribution = item.bobot.abs() / sumVal;
        final percent = (contribution * 100).toStringAsFixed(0);

        String strengthText;
        if (contribution >= 0.40) {
          strengthText = 'Sangat Kuat ($percent%)';
        } else if (contribution >= 0.20) {
          strengthText = 'Kuat ($percent%)';
        } else if (contribution >= 0.10) {
          strengthText = 'Sedang ($percent%)';
        } else {
          strengthText = 'Lemah ($percent%)';
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '"${item.kata}"',
                    style: GoogleFonts.dmSans(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: barColor.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      isHoaxDriver ? 'Cenderung Hoaks' : 'Cenderung Fakta',
                      style: GoogleFonts.dmSans(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        color: barColor,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 10,
                      decoration: BoxDecoration(
                        color: AppColors.navyElevated,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: contribution.clamp(0.05, 1.0),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [barColor.withValues(alpha: 0.6), barColor],
                            ),
                            borderRadius: BorderRadius.circular(5),
                            boxShadow: [
                              BoxShadow(
                                color: barColor.withValues(alpha: 0.3),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    strengthText,
                    style: GoogleFonts.dmSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: barColor.withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

// =============================================================
// CUSTOM PAINTER – Advanced Circular Gauge
// =============================================================
class _AdvancedGaugePainter extends CustomPainter {
  final double value;
  final List<Color> gradientColors;
  final Color statusColor;
  final Color trackColor;

  _AdvancedGaugePainter({
    required this.value,
    required this.gradientColors,
    required this.statusColor,
    required this.trackColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final outerRadius = math.min(size.width / 2, size.height / 2) - 4;
    const strokeW = 16.0;
    final radius = outerRadius - strokeW / 2;

    // Track (latar belakang arc)
    final trackPaint = Paint()
      ..color = trackColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeW
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2,
      2 * math.pi,
      false,
      trackPaint,
    );

    // Tick marks halus
    final tickPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.06)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    for (int i = 0; i < 20; i++) {
      final angle = -math.pi / 2 + (i / 20) * 2 * math.pi;
      final start = Offset(
        center.dx + (radius - 9) * math.cos(angle),
        center.dy + (radius - 9) * math.sin(angle),
      );
      final end = Offset(
        center.dx + (radius + 9) * math.cos(angle),
        center.dy + (radius + 9) * math.sin(angle),
      );
      canvas.drawLine(start, end, tickPaint);
    }

    if (value <= 0) return;

    final sweepAngle = 2 * math.pi * value;
    final rect = Rect.fromCircle(center: center, radius: radius);

    // Active arc gradient
    final activePaint = Paint()
      ..shader = SweepGradient(
        colors: [
          ...gradientColors,
          gradientColors.last,
        ],
        startAngle: 0,
        endAngle: 2 * math.pi,
      ).createShader(rect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeW
      ..strokeCap = StrokeCap.round;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(-math.pi / 2);
    canvas.translate(-center.dx, -center.dy);
    canvas.drawArc(rect, 0, sweepAngle, false, activePaint);
    canvas.restore();

    // Glow tip dot
    final tipAngle = -math.pi / 2 + sweepAngle;
    final tipX = center.dx + radius * math.cos(tipAngle);
    final tipY = center.dy + radius * math.sin(tipAngle);

    final glowPaint = Paint()
      ..color = statusColor.withValues(alpha: 0.35)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawCircle(Offset(tipX, tipY), 10, glowPaint);

    final tipPaint = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(tipX, tipY), 6, tipPaint);

    final tipInnerPaint = Paint()..color = statusColor;
    canvas.drawCircle(Offset(tipX, tipY), 4, tipInnerPaint);
  }

  @override
  bool shouldRepaint(_AdvancedGaugePainter old) =>
      old.value != value || old.statusColor != statusColor;
}

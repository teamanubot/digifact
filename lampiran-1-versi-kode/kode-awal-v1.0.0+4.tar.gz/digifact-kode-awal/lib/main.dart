import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'services/api_service.dart';
import 'services/storage_service.dart';
import 'views/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Status bar transparan agar background menyatu
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF050D1A),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Kunci orientasi ke portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  final storageService = await StorageService.init();
  await storageService.checkAndResetOnboardingExpiry();
  final apiService = ApiService();

  runApp(MyApp(
    apiService: apiService,
    storageService: storageService,
  ));
}

class MyApp extends StatelessWidget {
  final ApiService apiService;
  final StorageService storageService;

  const MyApp({
    super.key,
    required this.apiService,
    required this.storageService,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DigiFact',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        // Sistem warna berbasis Navy Blue #0A1F44
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFF33FF33),      // Neon Green – Fakta
          secondary: const Color(0xFF00D4FF),     // Cyan – Aksen UI
          error: const Color(0xFFFF3333),         // Neon Red – Hoaks
          surface: const Color(0xFF0D1B35),       // Card surface
          onSurface: Colors.white,
        ),
        scaffoldBackgroundColor: const Color(0xFF0A1F44),
        // Tipografi DM Sans premium
        textTheme: GoogleFonts.dmSansTextTheme().copyWith(
          displayLarge: GoogleFonts.dmSans(
            fontSize: 36,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: -1.0,
          ),
          headlineMedium: GoogleFonts.dmSans(
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: -0.5,
          ),
          titleLarge: GoogleFonts.dmSans(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
          bodyLarge: GoogleFonts.dmSans(
            fontSize: 15,
            fontWeight: FontWeight.w400,
            color: const Color(0xFFCDD5E0),
          ),
          bodyMedium: GoogleFonts.dmSans(
            fontSize: 13,
            fontWeight: FontWeight.w400,
            color: const Color(0xFF708090),
          ),
        ),
        // Snackbar tema
        snackBarTheme: SnackBarThemeData(
          backgroundColor: const Color(0xFF0D1B35),
          contentTextStyle:
              GoogleFonts.dmSans(color: Colors.white, fontSize: 13),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: Colors.white.withValues(alpha: 0.08)),
          ),
        ),
      ),
      // SplashScreen sebagai entry point pertama
      home: SplashScreen(
        apiService: apiService,
        storageService: storageService,
      ),
    );
  }
}

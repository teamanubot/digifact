class WordWeight {
  final String kata;
  final double bobot;

  WordWeight({required this.kata, required this.bobot});

  factory WordWeight.fromJson(Map<String, dynamic> json) {
    return WordWeight(
      kata: json['kata'] ?? '',
      bobot: (json['bobot'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'kata': kata,
      'bobot': bobot,
    };
  }
}

class DetectionResult {
  final String id;
  final String teksAsli;
  final double probabilitasFakta;
  final double probabilitasHoaks;
  final String prediksiAkhir;
  final List<WordWeight> penjelasanShap;
  final List<WordWeight> penjelasanLime;
  final String analisisDetail;
  final DateTime tanggalDeteksi;

  DetectionResult({
    required this.id,
    required this.teksAsli,
    required this.probabilitasFakta,
    required this.probabilitasHoaks,
    required this.prediksiAkhir,
    required this.penjelasanShap,
    required this.penjelasanLime,
    required this.analisisDetail,
    required this.tanggalDeteksi,
  });

  factory DetectionResult.fromJson(Map<String, dynamic> json) {
    var shapList = (json['penjelasan_shap'] as List?)
            ?.map((e) => WordWeight.fromJson(e))
            .toList() ??
        [];
    var limeList = (json['penjelasan_lime'] as List?)
            ?.map((e) => WordWeight.fromJson(e))
            .toList() ??
        [];

    return DetectionResult(
      id: json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
      teksAsli: json['teks_asli'] ?? '',
      probabilitasFakta: (json['probabilitas_fakta'] as num).toDouble(),
      probabilitasHoaks: (json['probabilitas_hoaks'] as num).toDouble(),
      prediksiAkhir: json['prediksi_akhir'] ?? '',
      penjelasanShap: shapList,
      penjelasanLime: limeList,
      analisisDetail: json['analisis_detail'] ?? '',
      tanggalDeteksi: json['tanggal_deteksi'] != null
          ? DateTime.parse(json['tanggal_deteksi'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'teks_asli': teksAsli,
      'probabilitas_fakta': probabilitasFakta,
      'probabilitas_hoaks': probabilitasHoaks,
      'prediksi_akhir': prediksiAkhir,
      'penjelasan_shap': penjelasanShap.map((e) => e.toJson()).toList(),
      'penjelasan_lime': penjelasanLime.map((e) => e.toJson()).toList(),
      'analisis_detail': analisisDetail,
      'tanggal_deteksi': tanggalDeteksi.toIso8601String(),
    };
  }
}

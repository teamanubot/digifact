import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/detection_result.dart';

class StorageService {
  static const String _keyHistory = 'digifact_history';
  static const String _keyOnboardingDone = 'digifact_onboarding_done';
  static const String _keyLastOpened = 'digifact_last_opened';
  final SharedPreferences _prefs;

  StorageService(this._prefs);

  static Future<StorageService> init() async {
    final prefs = await SharedPreferences.getInstance();
    return StorageService(prefs);
  }

  // ── Onboarding ───────────────────────────────────────────────
  /// Kembalikan true jika pengguna sudah pernah melihat onboarding
  bool get hasSeenOnboarding => _prefs.getBool(_keyOnboardingDone) ?? false;

  /// Tandai onboarding sebagai selesai
  Future<void> markOnboardingDone() async {
    await _prefs.setBool(_keyOnboardingDone, true);
  }

  /// Reset status onboarding agar tampil kembali pada peluncuran berikutnya
  Future<void> resetOnboarding() async {
    await _prefs.remove(_keyOnboardingDone);
  }

  /// Mendapatkan waktu terakhir aplikasi dibuka
  DateTime? get lastOpenedTime {
    final timeStr = _prefs.getString(_keyLastOpened);
    if (timeStr == null) return null;
    return DateTime.tryParse(timeStr);
  }

  /// Memperbarui waktu terakhir aplikasi dibuka dengan waktu sekarang
  Future<void> updateLastOpenedTime() async {
    await _prefs.setString(_keyLastOpened, DateTime.now().toIso8601String());
  }

  /// Mengecek apakah aplikasi sudah tidak dibuka selama 7 hari atau lebih.
  /// Jika ya, status onboarding akan direset kembali menjadi belum selesai.
  Future<void> checkAndResetOnboardingExpiry() async {
    final lastOpened = lastOpenedTime;
    final now = DateTime.now();
    if (lastOpened != null) {
      final difference = now.difference(lastOpened);
      if (difference.inDays >= 7) {
        await resetOnboarding();
      }
    }
    // Selalu perbarui waktu pembukaan terakhir ke waktu saat ini
    await updateLastOpenedTime();
  }

  // ── History ───────────────────────────────────────────────────
  /// Mengambil daftar riwayat deteksi berita
  List<DetectionResult> getHistory() {
    final listJson = _prefs.getStringList(_keyHistory);
    if (listJson == null) return [];
    try {
      return listJson
          .map((item) => DetectionResult.fromJson(json.decode(item)))
          .toList()
        ..sort((a, b) => b.tanggalDeteksi.compareTo(a.tanggalDeteksi));
    } catch (_) {
      return [];
    }
  }

  /// Menyimpan hasil deteksi baru
  Future<void> saveResult(DetectionResult result) async {
    final currentHistory = getHistory();
    currentHistory.removeWhere((item) => item.id == result.id);
    currentHistory.insert(0, result);
    if (currentHistory.length > 50) currentHistory.removeLast();
    final listJson =
        currentHistory.map((item) => json.encode(item.toJson())).toList();
    await _prefs.setStringList(_keyHistory, listJson);
  }

  /// Menghapus satu hasil riwayat berdasarkan ID
  Future<void> deleteResult(String id) async {
    final currentHistory = getHistory();
    currentHistory.removeWhere((item) => item.id == id);
    final listJson =
        currentHistory.map((item) => json.encode(item.toJson())).toList();
    await _prefs.setStringList(_keyHistory, listJson);
  }

  /// Menghapus semua riwayat
  Future<void> clearHistory() async {
    await _prefs.remove(_keyHistory);
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/detection_result.dart';

class ApiService {
  // Endpoint ditanam secara permanen menggunakan API produksi
  static String get _endpoint {
    return 'https://api.rmun.tech';
  }

  final String _baseUrl = _endpoint;

  String get baseUrl => _baseUrl;

  // Fungsi untuk mengecek apakah server aktif
  Future<bool> checkServerStatus() async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/')).timeout(
        const Duration(seconds: 4),
      );
      if (response.statusCode == 200 || response.statusCode == 405) {
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  // Fungsi mendeteksi berita hoax atau fakta
  Future<DetectionResult> detectHoax(String textOrUrl) async {
    final uri = Uri.parse('$_baseUrl/api/deteksi');
    
    try {
      final response = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: json.encode({'teks_berita': textOrUrl}),
      ).timeout(const Duration(seconds: 30)); 

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        return DetectionResult.fromJson(decodedData);
      } else {
        final errorMsg = _tryExtractErrorMessage(response.body);
        throw Exception(errorMsg);
      }
    } catch (e) {
      if (e is http.ClientException) {
        throw Exception('Gagal menghubungi server FastAPI di $_baseUrl. Pastikan server Anda berjalan.');
      }
      throw Exception(e.toString().replaceAll('Exception: ', ''));
    }
  }

  String _tryExtractErrorMessage(String body) {
    try {
      final data = json.decode(body);
      if (data is Map && data.containsKey('detail')) {
        return data['detail'].toString();
      }
    } catch (_) {}
    return 'Terjadi kesalahan pada server (Status: tidak diketahui)';
  }
}

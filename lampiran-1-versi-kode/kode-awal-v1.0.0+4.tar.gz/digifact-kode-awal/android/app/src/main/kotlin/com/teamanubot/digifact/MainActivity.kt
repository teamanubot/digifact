package com.teamanubot.digifact

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

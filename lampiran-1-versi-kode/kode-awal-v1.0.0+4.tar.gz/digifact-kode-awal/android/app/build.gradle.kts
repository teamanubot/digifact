import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val keystorePropertiesFile = rootProject.file("key.properties")
val keystoreProperties = Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "com.teamanubot.digifact"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String?
            keyPassword = keystoreProperties["keyPassword"] as String?
            storeFile = keystoreProperties["storeFile"]?.let { file(it) }
            storePassword = keystoreProperties["storePassword"] as String?
        }
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.teamanubot.digifact"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    applicationVariants.all {
        val variant = this
        variant.outputs.all {
            val output = this as? com.android.build.gradle.internal.api.ApkVariantOutputImpl
            output?.outputFileName = "DigiFact-v${variant.versionName}.apk"
        }
    }
}

tasks.matching { it.name == "assembleRelease" }.all {
    finalizedBy("copyAndRenameApk")
}

tasks.register("copyAndRenameApk") {
    doLast {
        val buildDir = layout.buildDirectory.get().asFile
        val srcFile = File(buildDir, "outputs/apk/release/DigiFact-v1.0.0.apk")
        val destFile1 = File(buildDir, "outputs/flutter-apk/DigiFact-v1.0.0.apk")
        val destFile2 = file("../../DigiFact-v1.0.0.apk")
        if (srcFile.exists()) {
            destFile1.parentFile.mkdirs()
            srcFile.copyTo(destFile1, overwrite = true)
            srcFile.copyTo(destFile2, overwrite = true)
            println("=== SUCCESS: APK copied to ${destFile1.absolutePath} ===")
            println("=== SUCCESS: APK copied to ${destFile2.absolutePath} ===")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}

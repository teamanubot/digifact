import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Smoke test silen', () {
    expect(true, true);
  });
}
